namespace CpuBenchmarkWorkbench;

/// <summary>
/// Displays program information and the bundled MIT license.
/// </summary>
public sealed class AboutForm : Form
{
    private static readonly string AppVersion = Application.ProductVersion ?? "28.0.0";

    private const string MitLicenseText = "MIT License\r\n\r\n" +
        "Copyright (c) 2026 CPU Benchmark Workbench contributors\r\n\r\n" +
        "Permission is hereby granted, free of charge, to any person obtaining a copy " +
        "of this software and associated documentation files (the \"Software\"), to deal " +
        "in the Software without restriction, including without limitation the rights " +
        "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell " +
        "copies of the Software, and to permit persons to whom the Software is " +
        "furnished to do so, subject to the following conditions:\r\n\r\n" +
        "The above copyright notice and this permission notice shall be included in all " +
        "copies or substantial portions of the Software.\r\n\r\n" +
        "THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR " +
        "IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, " +
        "FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE " +
        "AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER " +
        "LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, " +
        "OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE " +
        "SOFTWARE.";

    public AboutForm()
    {
        Text = "About CPU Benchmark Workbench";
        AppVisuals.TryApplyWindowIcon(this);
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(780, 620);
        ClientSize = new Size(860, 680);
        Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(14)
        };
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        Controls.Add(layout);

        var title = new Label
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Text = "CPU Benchmark Workbench",
            Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold),
            ForeColor = Color.FromArgb(24, 31, 54),
            Margin = new Padding(0, 0, 0, 8)
        };
        layout.Controls.Add(title, 0, 0);

        var summary = new Label
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            MaximumSize = new Size(800, 0),
            Text = "A Windows desktop benchmark tool focused on broad CPU comparison. It includes scalar, branch-heavy, memory, cache, SIMD, AVX-family, AES, and burn-in-style workloads when the runtime detects support. The program is intended to be useful across home PCs, gaming systems, workstations, and servers.",
            ForeColor = Color.FromArgb(60, 66, 88),
            Margin = new Padding(0, 0, 0, 12)
        };
        layout.Controls.Add(summary, 0, 1);

        var tabs = new TabControl { Dock = DockStyle.Fill };
        layout.Controls.Add(tabs, 0, 2);

        tabs.TabPages.Add(CreateTextPage(
            "About",
            $"Program: CPU Benchmark Workbench\r\n" +
            $"Version: {AppVersion}\r\n\r\n" +
            "Highlights in this build:\r\n" +
            "- smart sweep using 1 thread plus quarter-step scaling points\r\n" +
            "- broader CPU capability matching\r\n" +
            "- AVX2/FMA benchmark\r\n" +
            "- AVX-512 benchmark\r\n" +
            "- AES blocks benchmark\r\n" +
            "- cache walker and branch chaos tests\r\n" +
            "- placement modes: Auto, Adaptive, Compact, Spread, NUMA Balanced, with benchmark-aware Adaptive behavior\r\n" +
            "- worker-local first-touch allocation for better NUMA behavior\r\n" +
            "- adaptive placement to keep smaller runs local and larger runs balanced\r\n" +
            "- companion CSV/log/system-report export for richer analysis\r\n" +
            "- fullscreen graph button with Close and Esc support\r\n" +
            "- saved per-session thread-scaling PNG graphs beside CSV exports\r\n" +
            "- built-in help guide\r\n" +
            "- built-in About + MIT license\r\n" +
            "- burn-in run mode\r\n" +
            "- final overall PC score from 0 to 100,000 anchored to the validated v23 reference run\r\n" +
            "- best-fit CPU use-case opinion based on benchmark-family scoring"));
        tabs.TabPages.Add(CreateTextPage("MIT License", MitLicenseText));
    }

    private static TabPage CreateTextPage(string title, string text)
    {
        var page = new TabPage(title);
        var box = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BorderStyle = BorderStyle.None,
            BackColor = Color.White,
            Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point),
            Text = text
        };
        page.Controls.Add(box);
        return page;
    }
}
