using System.Collections.Concurrent;
using System.Diagnostics;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics;
using System.Runtime.Intrinsics.X86;

namespace CpuBenchmarkWorkbench;

/// <summary>
/// Builds the feature-aware catalog of benchmark definitions.
///
/// The catalog deliberately exposes only tests that make sense for the current machine,
/// such as AVX2/FMA, AVX-512, and AES when the runtime reports support.
/// </summary>
public static class BenchmarkCatalog
{
    public static IReadOnlyList<BenchmarkDefinition> CreateAll(CpuCapabilityReport report)
    {
        var list = new List<BenchmarkDefinition>
        {
            new IntegerMixBenchmark(),
            new BitTwisterBenchmark(),
            new FloatingPointBenchmark(),
            new FloatingPointPeakBenchmark(),
            new BranchChaosBenchmark(),
            new CacheWalkerBenchmark(),
            new SimdVectorBenchmark(),
            new MemoryStreamBenchmark(),
            new MemoryStreamSustainedBenchmark(),
            new MatrixMultiplyBenchmark(),
            new PrimeScanBenchmark(),
            new MandelbrotBenchmark()
        };

        int simdInsertIndex = list.FindIndex(b => b is MemoryStreamBenchmark);
        if (simdInsertIndex < 0)
            simdInsertIndex = list.Count;

        if (report.HasAvx2 && report.HasFma)
        {
            list.Insert(simdInsertIndex, new Avx2FmaBenchmark());
            list.Insert(simdInsertIndex + 1, new Avx2FmaPeakBenchmark());
            simdInsertIndex += 2;
        }

        if (report.HasAnyAvx512)
        {
            list.Insert(simdInsertIndex, new Avx512WideBenchmark());
            list.Insert(simdInsertIndex + 1, new Avx512WidePeakBenchmark());
            simdInsertIndex += 2;
        }

        if (report.HasAes)
            list.Insert(simdInsertIndex, new AesBlocksBenchmark());

        return list;
    }
}

/// <summary>
/// Runs benchmark workers and turns their raw work counters into timed results.
/// </summary>
public static class BenchmarkEngine
{
    public static Task<BenchmarkResult> RunAsync(
        BenchmarkDefinition definition,
        BenchmarkRunOptions options,
        Action<string>? log,
        CancellationToken cancellationToken)
    {
        return Task.Run(() => Run(definition, options, log, cancellationToken), cancellationToken);
    }

    private static BenchmarkResult Run(
        BenchmarkDefinition definition,
        BenchmarkRunOptions options,
        Action<string>? log,
        CancellationToken cancellationToken)
    {
        if (options.Threads < 1)
            throw new ArgumentOutOfRangeException(nameof(options.Threads));

        var startedAt = DateTime.Now;
        double targetSeconds = options.DurationOverrideSeconds ?? options.Preset.TargetSeconds();
        var placementPlan = ThreadPlacementHelper.BuildPlan(SystemInfoProvider.GetReport(), options.Threads, options.PlacementMode, definition.PlacementBias);

        // Each worker slot collects its own totals after the task finishes. This
        // is intentionally separate from the benchmark worker object so the
        // engine can create the worker on the target thread itself. Doing that
        // improves first-touch memory locality on NUMA systems.
        var completions = Enumerable.Range(0, options.Threads)
            .Select(_ => new WorkerCompletion())
            .ToArray();

        using var readyGate = new CountdownEvent(options.Threads);
        using var startGate = new ManualResetEventSlim(false);
        var exceptions = new ConcurrentQueue<Exception>();

        var tasks = new Task[options.Threads];
        for (int i = 0; i < options.Threads; i++)
        {
            int localIndex = i;
            tasks[i] = Task.Factory.StartNew(() =>
            {
                bool readySignaled = false;
                try
                {
                    var target = placementPlan.TryGetTarget(localIndex);
                    completions[localIndex].PlacementSummary = ThreadPlacementHelper.ApplyCurrentThreadTarget(target);

                    // Warm the code path on the worker thread first. We use a
                    // throwaway worker so the measured counters stay clean.
                    if (options.Warmup)
                    {
                        var warmupWorker = definition.CreateWorker(localIndex, BenchmarkPreset.Quick);
                        for (int warm = 0; warm < 2; warm++)
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            warmupWorker.RunBatch();
                        }
                    }

                    // Worker creation happens on the worker thread, not the UI
                    // thread. That gives worker-owned arrays and state a better
                    // chance to start life on the same NUMA node that will run
                    // the workload.
                    var worker = definition.CreateWorker(localIndex, options.Preset);

                    readyGate.Signal();
                    readySignaled = true;
                    startGate.Wait(cancellationToken);

                    var sw = Stopwatch.StartNew();
                    while (!cancellationToken.IsCancellationRequested && sw.Elapsed.TotalSeconds < targetSeconds)
                        worker.RunBatch();

                    completions[localIndex].WorkCompleted = worker.WorkCompleted;
                    completions[localIndex].Checksum = worker.Checksum;
                }
                catch (OperationCanceledException)
                {
                }
                catch (Exception ex)
                {
                    exceptions.Enqueue(ex);
                }
                finally
                {
                    if (!readySignaled)
                        readyGate.Signal();
                }
            }, cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        log?.Invoke($"Starting: {definition.Name} | Threads: {options.Threads} | Preset: {options.Preset.DisplayName()} | Target: {targetSeconds:N1}s");
        log?.Invoke($"Requested placement: {options.PlacementMode.DisplayName()} | Effective placement: {placementPlan.ResultLabel}");
        log?.Invoke($"Benchmark placement bias: {definition.PlacementBias.DisplayName()}");
        log?.Invoke($"Placement detail: {placementPlan.Description}");

        if (!readyGate.Wait(TimeSpan.FromSeconds(30)))
            throw new TimeoutException("Worker threads did not finish preparing in time.");

        log?.Invoke("Placement sample after preparation: " +
            string.Join(", ", completions.Take(Math.Min(4, completions.Length)).Select((completion, index) => $"w{index}->{completion.PlacementSummary}")));

        var stopwatch = Stopwatch.StartNew();
        startGate.Set();
        Task.WaitAll(tasks);
        stopwatch.Stop();

        if (!exceptions.IsEmpty)
            throw new AggregateException(exceptions);

        double totalWork = 0.0;
        double checksum = 0.0;
        foreach (var completion in completions)
        {
            totalWork += completion.WorkCompleted;
            checksum += completion.Checksum;
        }

        return new BenchmarkResult
        {
            StartedAt = startedAt,
            Benchmark = definition.Name,
            Threads = options.Threads,
            Preset = options.Preset.DisplayName(),
            Placement = placementPlan.ResultLabel,
            DurationSeconds = stopwatch.Elapsed.TotalSeconds,
            ScorePerSecond = stopwatch.Elapsed.TotalSeconds > 0 ? totalWork / stopwatch.Elapsed.TotalSeconds : 0.0,
            MetricKind = definition.MetricKind,
            Checksum = checksum,
            Notes = definition.Notes
        };
    }

    private sealed class WorkerCompletion
    {
        public double WorkCompleted { get; set; }
        public double Checksum { get; set; }
        public string PlacementSummary { get; set; } = string.Empty;
    }
}

internal static class BenchmarkSizing
{
    public static int ByPreset(BenchmarkPreset preset, int quick, int standard, int heavy, int extreme) => preset switch
    {
        BenchmarkPreset.Quick => quick,
        BenchmarkPreset.Standard => standard,
        BenchmarkPreset.Heavy => heavy,
        BenchmarkPreset.Extreme => extreme,
        _ => standard
    };
}

internal static class PeakMathGuard
{
    /// <summary>
    /// Clamps scalar peak-test state back into a finite range. This keeps the
    /// peak variants educational and comparable instead of letting them drift to
    /// NaN/Infinity after enough hot-loop iterations.
    /// </summary>
    public static double ClampFinite(double value, double fallback, double limit)
    {
        if (!double.IsFinite(value))
            return fallback;

        if (value > limit)
            return limit;
        if (value < -limit)
            return -limit;
        return value;
    }

    /// <summary>
    /// Clamps a scalar back into a finite range and then gently recenters it
    /// around a stable non-zero baseline. This is useful for "peak" kernels
    /// where we want a meaningful checksum instead of a value that merely avoids
    /// NaN by collapsing toward zero.
    /// </summary>
    public static double ClampAndRecenterFinite(double value, double center, double limit, double keepFraction)
    {
        value = ClampFinite(value, center, limit);
        return center + ((value - center) * keepFraction);
    }

    /// <summary>
    /// Clamps a vector lane buffer back into a finite range before it is packed
    /// into a Vector256/Vector512 value again.
    /// </summary>
    public static void ClampFinite(Span<float> lanes, float limit, float baseValue, float step)
    {
        for (int i = 0; i < lanes.Length; i++)
        {
            float value = lanes[i];
            if (!float.IsFinite(value))
                value = baseValue + (i * step);
            else if (value > limit)
                value = limit;
            else if (value < -limit)
                value = -limit;

            lanes[i] = value;
        }
    }
}

internal sealed class IntegerMixBenchmark : BenchmarkDefinition
{
    public IntegerMixBenchmark() : base(
        "Integer Mix",
        "Scalar / ALU",
        "Integer-heavy arithmetic with 64-bit xor-shift style state churn.",
        MetricKind.IntegerOps,
        "Good for ALU throughput and simple thread scaling.",
        "This is a scalar integer benchmark. It keeps a small amount of hot state in registers and repeatedly mutates it with rotates, shifts, adds, multiplies, and xor patterns. It is useful when you want a baseline for ordinary integer execution without relying on special vector extensions. On gaming PCs it gives a good quick feel for general per-core snappiness. On servers and workstations it helps show how well many threads scale when the test is not bottlenecked by main memory.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private ulong _x;
        private ulong _y;
        private double _ops;

        public Worker(int workerIndex)
        {
            _x = 0x9E3779B97F4A7C15UL ^ (ulong)(workerIndex + 1);
            _y = 0xBF58476D1CE4E5B9UL + (ulong)(workerIndex * 31 + 7);
        }

        public double WorkCompleted => _ops;
        public double Checksum => _x + _y;

        public void RunBatch()
        {
            const int iterations = 300_000;
            ulong x = _x;
            ulong y = _y;
            for (int i = 0; i < iterations; i++)
            {
                x ^= x << 13;
                x ^= x >> 7;
                x ^= x << 17;
                y += 0x9E3779B97F4A7C15UL;
                y = (y * 0xBF58476D1CE4E5B9UL) ^ (x >> 3);
                x += y ^ (x << 9);
            }
            _x = x;
            _y = y;
            _ops += iterations * 12.0;
        }
    }
}

internal sealed class BitTwisterBenchmark : BenchmarkDefinition
{
    public BitTwisterBenchmark() : base(
        "Bit Twister",
        "Scalar / Bits",
        "Integer-heavy rotate, xor, popcount-style mixing over local state.",
        MetricKind.IntegerOps,
        "Useful for integer pipelines, bit manipulation, and older versus newer CPU comparisons outside pure SIMD math.",
        "This benchmark stresses bit operations more than general arithmetic. It performs rotates, xor mixing, shifts, multiplies, and popcount-friendly data churn over a local state array. It is useful when you care about tasks such as compression-style bit handling, hashing-like transforms, and branch-light integer work. It is also handy for comparing architectures where vector support differs but the scalar front end and bit-manipulation features are still important.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly ulong[] _state;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 8_192, 16_384, 32_768, 65_536);
            _state = new ulong[length];
            ulong seed = 0x9E3779B97F4A7C15UL ^ (ulong)(workerIndex + 1);
            for (int i = 0; i < _state.Length; i++)
            {
                seed ^= seed << 13;
                seed ^= seed >> 7;
                seed ^= seed << 17;
                _state[i] = seed + (ulong)i * 0xD6E8FEB86659FD93UL;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            ulong sum = 0UL;
            for (int i = 0; i < _state.Length; i++)
            {
                ulong x = _state[i];
                x ^= BitOperations.RotateLeft(x, 13);
                x += 0x9E3779B97F4A7C15UL;
                x ^= BitOperations.RotateRight(x, 7);
                x *= 0xBF58476D1CE4E5B9UL;
                x ^= x >> 29;
                x = BitOperations.RotateLeft(x, 31) ^ (x >> 11);
                _state[i] = x;
                sum ^= x;
                sum += (ulong)BitOperations.PopCount(x);
            }

            _checksum += sum;
            _work += _state.Length * 16.0;
        }
    }
}

internal sealed class FloatingPointBenchmark : BenchmarkDefinition
{
    public FloatingPointBenchmark() : base(
        "Floating Point Mix",
        "Scalar / FP",
        "Double-precision arithmetic chains for scalar floating-point throughput.",
        MetricKind.FloatingOps,
        "Useful for general FP throughput without SIMD specialization.",
        "This test stays in scalar floating point so it is a good complement to the SIMD and AVX-family tests. It chains dependent double-precision operations, which means the CPU cannot completely hide latencies by pure width alone. It is useful when comparing older CPUs, server chips, or machines where you want to see how the scalar floating-point pipelines behave under steady load.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private double _a;
        private double _b;
        private double _c;
        private double _d;
        private double _flops;

        public Worker(int workerIndex)
        {
            _a = 1.0 + workerIndex;
            _b = 0.5 + workerIndex * 0.013;
            _c = 2.0 + workerIndex * 0.017;
            _d = 3.0 + workerIndex * 0.019;
        }

        public double WorkCompleted => _flops;
        public double Checksum => _a + _b + _c + _d;

        public void RunBatch()
        {
            const int iterations = 300_000;
            double a = _a, b = _b, c = _c, d = _d;
            for (int i = 0; i < iterations; i++)
            {
                // Earlier revisions let the state drift to NaN on long runs.
                // This version uses a stable, bounded recurrence so the checksum
                // remains meaningful while still exercising scalar FP pipelines.
                double nextA = a * 0.9999991 + b * 0.000201 - d * 0.000017 + 0.125;
                double nextB = b * 0.9999989 + c * 0.000173 + a * 0.000021 + 0.0625;
                double nextC = c * 0.9999993 + a * 0.000149 - b * 0.000031 + 0.03125;
                double nextD = d * 0.9999987 + (a - c) * 0.000083 + b * 0.000019 + 0.015625;
                a = nextA;
                b = nextB;
                c = nextC;
                d = nextD;

                if ((i & 2047) == 0)
                {
                    a *= 0.5;
                    b *= 0.5;
                    c *= 0.5;
                    d *= 0.5;
                }
            }
            _a = a; _b = b; _c = c; _d = d;
            _flops += iterations * 14.0;
        }
    }
}

internal sealed class FloatingPointPeakBenchmark : BenchmarkDefinition
{
    public FloatingPointPeakBenchmark() : base(
        "Floating Point Mix (Peak)",
        "Scalar / FP Peak",
        "Higher-throughput scalar double-precision arithmetic with non-zero checksum recentering.",
        MetricKind.FloatingOps,
        "Useful when you want a more aggressive scalar floating-point score while still keeping the state finite.",
        "This benchmark is the higher-throughput partner to Floating Point Mix. It keeps more independent scalar state in flight so the CPU can expose more instruction-level parallelism. The state is gently recentred from time to time around stable non-zero baselines, which makes it a better peak-style scalar test while still keeping the checksum meaningful and finite for long runs.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private double _a;
        private double _b;
        private double _c;
        private double _d;
        private double _e;
        private double _f;
        private double _g;
        private double _h;
        private double _flops;

        public Worker(int workerIndex)
        {
            _a = 1.0 + workerIndex * 0.01;
            _b = 2.0 + workerIndex * 0.02;
            _c = 3.0 + workerIndex * 0.03;
            _d = 4.0 + workerIndex * 0.04;
            _e = 5.0 + workerIndex * 0.05;
            _f = 6.0 + workerIndex * 0.06;
            _g = 7.0 + workerIndex * 0.07;
            _h = 8.0 + workerIndex * 0.08;
        }

        public double WorkCompleted => _flops;
        public double Checksum => _a + _b + _c + _d + _e + _f + _g + _h;

        public void RunBatch()
        {
            const int iterations = 325_000;
            const double clampLimit = 4096.0;
            const double keepFraction = 0.1875;
            double a = _a, b = _b, c = _c, d = _d, e = _e, f = _f, g = _g, h = _h;
            for (int i = 0; i < iterations; i++)
            {
                // Compared with the validated scalar FP test, this variant keeps
                // more independent lanes of scalar work in flight. In v23 we keep
                // that peak-friendly structure, but the periodic cleanup now
                // recenters the state around non-zero baselines instead of merely
                // quarter-scaling toward zero. That preserves a meaningful
                // checksum while still preventing NaN/Infinity drift.
                a = a * 1.00000019 + b * 0.000271 - d * 0.000031 + 0.00041;
                b = b * 0.99999983 + c * 0.000193 + a * 0.000021 + 0.00029;
                c = c * 1.00000011 + d * 0.000227 - b * 0.000027 + 0.00037;
                d = d * 0.99999979 + a * 0.000141 + c * 0.000019 + 0.00023;
                e = e * 1.00000017 + f * 0.000233 - h * 0.000025 + 0.00043;
                f = f * 0.99999981 + g * 0.000189 + e * 0.000023 + 0.00031;
                g = g * 1.00000009 + h * 0.000211 - f * 0.000029 + 0.00035;
                h = h * 0.99999977 + e * 0.000153 + g * 0.000017 + 0.00019;

                if ((i & 2047) == 2047)
                {
                    a = PeakMathGuard.ClampAndRecenterFinite(a, 1.0, clampLimit, keepFraction);
                    b = PeakMathGuard.ClampAndRecenterFinite(b, 2.0, clampLimit, keepFraction);
                    c = PeakMathGuard.ClampAndRecenterFinite(c, 3.0, clampLimit, keepFraction);
                    d = PeakMathGuard.ClampAndRecenterFinite(d, 4.0, clampLimit, keepFraction);
                    e = PeakMathGuard.ClampAndRecenterFinite(e, 5.0, clampLimit, keepFraction);
                    f = PeakMathGuard.ClampAndRecenterFinite(f, 6.0, clampLimit, keepFraction);
                    g = PeakMathGuard.ClampAndRecenterFinite(g, 7.0, clampLimit, keepFraction);
                    h = PeakMathGuard.ClampAndRecenterFinite(h, 8.0, clampLimit, keepFraction);
                }
            }

            _a = PeakMathGuard.ClampAndRecenterFinite(a, 1.0, clampLimit, keepFraction);
            _b = PeakMathGuard.ClampAndRecenterFinite(b, 2.0, clampLimit, keepFraction);
            _c = PeakMathGuard.ClampAndRecenterFinite(c, 3.0, clampLimit, keepFraction);
            _d = PeakMathGuard.ClampAndRecenterFinite(d, 4.0, clampLimit, keepFraction);
            _e = PeakMathGuard.ClampAndRecenterFinite(e, 5.0, clampLimit, keepFraction);
            _f = PeakMathGuard.ClampAndRecenterFinite(f, 6.0, clampLimit, keepFraction);
            _g = PeakMathGuard.ClampAndRecenterFinite(g, 7.0, clampLimit, keepFraction);
            _h = PeakMathGuard.ClampAndRecenterFinite(h, 8.0, clampLimit, keepFraction);
            _flops += iterations * 32.0;
        }
    }
}

internal sealed class BranchChaosBenchmark : BenchmarkDefinition
{
    public BranchChaosBenchmark() : base(
        "Branch Chaos",
        "Control Flow",
        "Irregular branch-heavy integer work across a changing control pattern.",
        MetricKind.Numbers,
        "Useful for branch predictor behavior and mixed instruction flow.",
        "This benchmark intentionally creates hard-to-predict branches over a local integer array. That makes it useful for testing branch predictors, front-end recovery behavior, and code with irregular control flow. It is a good partner for Prime Scan because both are branchy, but this one is less mathematical and more about unpredictable decision paths.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int[] _state;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 32_768, 65_536, 131_072, 262_144);
            _state = new int[length];
            uint seed = unchecked(0x12345678u + ((uint)workerIndex * 7919u));
            for (int i = 0; i < _state.Length; i++)
            {
                seed = 1664525u * seed + 1013904223u;
                _state[i] = unchecked((int)seed);
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            long sum = 0;
            for (int i = 0; i < _state.Length; i++)
            {
                int x = _state[i];
                if ((x & 1) == 0)
                    x = (x << 1) ^ 0x5A5A5A5A;
                else if ((x & 2) == 0)
                    x = (x >> 1) + 0x13579BDF;
                else if ((x & 4) == 0)
                    x = unchecked((int)BitOperations.RotateLeft((uint)x, 7)) ^ 0x2468ACE;
                else
                    x = unchecked(x * 1664525 + 1013904223);

                if ((x & 8) != 0)
                    x ^= unchecked((int)BitOperations.RotateRight((uint)x, 11));
                else
                    x += (x >> 5);

                _state[i] = x;
                sum += x;
            }

            _checksum += sum;
            _work += _state.Length;
        }
    }
}

internal sealed class CacheWalkerBenchmark : BenchmarkDefinition
{
    public CacheWalkerBenchmark() : base(
        "Cache Walker",
        "Memory / Cache",
        "Pointer-chasing style random access over a larger working set.",
        MetricKind.Accesses,
        "Useful for cache hierarchy, latency, and data-locality comparisons.",
        "This benchmark walks memory through an indirection table instead of a simple linear copy. That makes it much less friendly to caches and prefetchers than Memory Stream. It is useful when you want to compare CPUs or platforms for latency-sensitive work, irregular data structures, or cache-miss-heavy server-side logic. It is especially helpful next to Memory Stream because the two together show bandwidth versus latency behavior.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int[] _next;
        private readonly long[] _values;
        private int _index;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 1 << 18, 1 << 20, 1 << 21, 1 << 22);
            _next = new int[length];
            _values = new long[length];

            for (int i = 0; i < length; i++)
            {
                _next[i] = i;
                _values[i] = i * 17L + workerIndex;
            }

            uint seed = unchecked(((uint)workerIndex + 1u) * 2654435761u);
            for (int i = length - 1; i > 0; i--)
            {
                seed = 1664525u * seed + 1013904223u;
                int j = (int)(seed % (uint)(i + 1));
                (_next[i], _next[j]) = (_next[j], _next[i]);
            }

            for (int i = 0; i < length - 1; i++)
                _next[_next[i]] = _next[i + 1];
            _next[_next[length - 1]] = _next[0];
            _index = _next[0];
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            int idx = _index;
            long sum = 0;
            const int iterations = 300_000;
            for (int i = 0; i < iterations; i++)
            {
                idx = _next[idx];
                long value = _values[idx];
                value ^= idx;
                value += (value << 3);
                _values[idx] = value;
                sum += value;
            }

            _index = idx;
            _checksum += sum;
            _work += iterations;
        }
    }
}

internal sealed class SimdVectorBenchmark : BenchmarkDefinition
{
    public override BenchmarkPlacementBias PlacementBias => BenchmarkPlacementBias.PortableSimd;

    public SimdVectorBenchmark() : base(
        "SIMD Vector Math",
        "SIMD / Portable",
        "Vectorized single-precision math using System.Numerics.Vector.",
        MetricKind.FloatingOps,
        "Shows how well the runtime's portable SIMD plus thread scaling work together.",
        "This benchmark uses the portable Vector<T> API instead of a fixed-width ISA-specific path. That means it adapts across different CPUs and is a good general SIMD reference even on machines that do not expose AVX2 or AVX-512. It is often the fairest cross-generation vector test in the whole app because it reflects what many high-level .NET workloads actually get from the runtime.",
        "Available whenever the runtime can execute the benchmark. It still runs on older systems, but results are strongest on hardware-accelerated SIMD paths.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly float[] _a;
        private readonly float[] _b;
        private readonly float[] _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 65_536, 131_072, 262_144, 524_288);
            _a = new float[length];
            _b = new float[length];
            _c = new float[length];
            for (int i = 0; i < length; i++)
            {
                _a[i] = 1.0f + workerIndex + (i % 97) * 0.01f;
                _b[i] = 0.5f + (i % 53) * 0.02f;
                _c[i] = 0.25f + (i % 29) * 0.03f;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            int vectorWidth = Vector<float>.Count;
            int i = 0;
            Vector<float> gain = new(1.00011f);
            Vector<float> blend = new(0.00017f);
            Vector<float> acc = Vector<float>.Zero;
            for (; i <= _a.Length - vectorWidth; i += vectorWidth)
            {
                var va = new Vector<float>(_a, i);
                var vb = new Vector<float>(_b, i);
                var vc = new Vector<float>(_c, i);
                va = va * gain + vb;
                vb = vb - vc * blend;
                vc = va + vb * new Vector<float>(0.5f);
                va.CopyTo(_a, i);
                vb.CopyTo(_b, i);
                vc.CopyTo(_c, i);
                acc += va + vb + vc;
            }

            float sum = 0f;
            for (int lane = 0; lane < Vector<float>.Count; lane++)
                sum += acc[lane];

            for (; i < _a.Length; i++)
            {
                _a[i] = _a[i] * 1.00011f + _b[i];
                _b[i] = _b[i] - _c[i] * 0.00017f;
                _c[i] = _a[i] + _b[i] * 0.5f;
                sum += _a[i] + _b[i] + _c[i];
            }

            _checksum += sum;
            _work += _a.Length * 9.0;
        }
    }
}

internal sealed class Avx2FmaBenchmark : BenchmarkDefinition
{
    public Avx2FmaBenchmark() : base(
        "AVX2 / FMA Float32",
        "SIMD / AVX2",
        "ISA-specific 256-bit fused multiply-add style float math.",
        MetricKind.FloatingOps,
        "Useful for modern desktop, workstation, and server CPUs that expose AVX2 plus FMA.",
        "This benchmark is more ISA-specific than the general SIMD Vector test. It uses 256-bit AVX registers together with FMA operations when the runtime exposes them. That makes it a strong indicator of how modern vector-capable CPUs handle dense float workloads such as media transforms, physics kernels, and some numerical code. Compare it against the generic SIMD result to see whether the machine gains a lot from wide explicit vector instructions.",
        "Shown only when AVX2 and FMA are detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector256<float> _a;
        private Vector256<float> _b;
        private Vector256<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            if (!Avx2.IsSupported || !Fma.IsSupported)
                throw new PlatformNotSupportedException("AVX2/FMA benchmark requires AVX2 and FMA support.");

            _a = Vector256.Create(1.0f + workerIndex, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f);
            _b = Vector256.Create(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.25f);
            _c = Vector256.Create(0.125f, 0.25f, 0.375f, 0.5f, 0.625f, 0.75f, 0.875f, 1.0f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var decayA = Vector256.Create(0.99991f);
            var decayB = Vector256.Create(0.99989f);
            var cross1 = Vector256.Create(0.00031f);
            var cross2 = Vector256.Create(0.00017f);
            var drift = Vector256.Create(0.00001f);
            var half = Vector256.Create(0.5f);
            const int iterations = 250_000;

            for (int i = 0; i < iterations; i++)
            {
                // Keep the state bounded so the validation checksum stays finite
                // across long runs and many worker threads. We still execute a
                // dense AVX2/FMA-heavy update each iteration; we simply stop the
                // state from exploding to infinity.
                var nextA = Fma.MultiplyAdd(a, decayA, Avx.Multiply(Avx.Subtract(b, c), cross1));
                var nextB = Fma.MultiplyAdd(b, decayB, Avx.Multiply(Avx.Subtract(c, a), cross2));
                var nextC = Fma.MultiplyAdd(c, decayA, Avx.Multiply(Avx.Subtract(a, b), cross1));
                a = Avx.Add(nextA, drift);
                b = Avx.Subtract(nextB, drift);
                c = Fma.MultiplyAdd(nextC, decayB, Avx.Multiply(a, cross2));

                if ((i & 255) == 0)
                {
                    a = Avx.Multiply(a, half);
                    b = Avx.Multiply(b, half);
                    c = Avx.Multiply(c, half);
                }
            }

            Span<float> lanesA = stackalloc float[Vector256<float>.Count];
            Span<float> lanesB = stackalloc float[Vector256<float>.Count];
            Span<float> lanesC = stackalloc float[Vector256<float>.Count];
            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            double sum = 0.0;
            for (int lane = 0; lane < Vector256<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = a;
            _b = b;
            _c = c;
            _checksum += sum;
            _work += iterations * Vector256<float>.Count * 16.0;
        }
    }
}

internal sealed class Avx2FmaPeakBenchmark : BenchmarkDefinition
{
    public Avx2FmaPeakBenchmark() : base(
        "AVX2 / FMA Float32 (Peak)",
        "SIMD / AVX2 Peak",
        "Higher-throughput 256-bit fused multiply-add style float math with lighter stabilization.",
        MetricKind.FloatingOps,
        "Useful when you want a more aggressive AVX2/FMA score in addition to the validated variant.",
        "This benchmark is the peak-throughput partner to the validated AVX2/FMA test. It uses a denser hot loop with fewer safety instructions so it can expose more of the machine's best-case 256-bit float throughput. The state is still renormalized occasionally so long runs remain finite, but this variant is intentionally tuned closer to peak score chasing than to conservative validation.",
        "Shown only when AVX2 and FMA are detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector256<float> _a;
        private Vector256<float> _b;
        private Vector256<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            if (!Avx2.IsSupported || !Fma.IsSupported)
                throw new PlatformNotSupportedException("AVX2/FMA peak benchmark requires AVX2 and FMA support.");

            _a = Vector256.Create(1.0f + workerIndex, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f);
            _b = Vector256.Create(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.25f, 2.5f);
            _c = Vector256.Create(0.125f, 0.25f, 0.375f, 0.5f, 0.625f, 0.75f, 0.875f, 1.0f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var mulA = Vector256.Create(1.000031f);
            var mulB = Vector256.Create(0.999971f);
            var mulC = Vector256.Create(1.000019f);
            var small1 = Vector256.Create(0.00061f);
            var small2 = Vector256.Create(0.00037f);
            var quarter = Vector256.Create(0.25f);
            Span<float> lanesA = stackalloc float[Vector256<float>.Count];
            Span<float> lanesB = stackalloc float[Vector256<float>.Count];
            Span<float> lanesC = stackalloc float[Vector256<float>.Count];
            const int iterations = 260_000;

            for (int i = 0; i < iterations; i++)
            {
                var nextA = Fma.MultiplyAdd(a, mulA, b);
                var nextB = Fma.MultiplyAdd(b, mulB, c);
                var nextC = Fma.MultiplyAdd(c, mulC, a);
                a = Avx.Subtract(nextA, Avx.Multiply(c, small1));
                b = Avx.Add(nextB, Avx.Multiply(a, small2));
                c = Avx.Subtract(nextC, Avx.Multiply(b, small1));

                if ((i & 2047) == 2047)
                {
                    a = Avx.Multiply(a, quarter);
                    b = Avx.Multiply(b, quarter);
                    c = Avx.Multiply(c, quarter);

                    a.CopyTo(lanesA);
                    b.CopyTo(lanesB);
                    c.CopyTo(lanesC);
                    PeakMathGuard.ClampFinite(lanesA, 4096f, 1.0f, 0.125f);
                    PeakMathGuard.ClampFinite(lanesB, 4096f, 0.75f, 0.125f);
                    PeakMathGuard.ClampFinite(lanesC, 4096f, 0.125f, 0.125f);
                    a = Vector256.Create(lanesA[0], lanesA[1], lanesA[2], lanesA[3], lanesA[4], lanesA[5], lanesA[6], lanesA[7]);
                    b = Vector256.Create(lanesB[0], lanesB[1], lanesB[2], lanesB[3], lanesB[4], lanesB[5], lanesB[6], lanesB[7]);
                    c = Vector256.Create(lanesC[0], lanesC[1], lanesC[2], lanesC[3], lanesC[4], lanesC[5], lanesC[6], lanesC[7]);
                }
            }

            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            PeakMathGuard.ClampFinite(lanesA, 4096f, 1.0f, 0.125f);
            PeakMathGuard.ClampFinite(lanesB, 4096f, 0.75f, 0.125f);
            PeakMathGuard.ClampFinite(lanesC, 4096f, 0.125f, 0.125f);

            double sum = 0.0;
            for (int lane = 0; lane < Vector256<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = Vector256.Create(lanesA[0], lanesA[1], lanesA[2], lanesA[3], lanesA[4], lanesA[5], lanesA[6], lanesA[7]);
            _b = Vector256.Create(lanesB[0], lanesB[1], lanesB[2], lanesB[3], lanesB[4], lanesB[5], lanesB[6], lanesB[7]);
            _c = Vector256.Create(lanesC[0], lanesC[1], lanesC[2], lanesC[3], lanesC[4], lanesC[5], lanesC[6], lanesC[7]);
            _checksum += sum;
            _work += iterations * Vector256<float>.Count * 14.0;
        }
    }
}

internal sealed class Avx512WideBenchmark : BenchmarkDefinition
{
    public Avx512WideBenchmark() : base(
        "AVX-512 Wide Float32",
        "SIMD / AVX-512",
        "Wide 512-bit float vector math for CPUs that expose AVX-512 through the runtime.",
        MetricKind.FloatingOps,
        "Useful for high-end workstation and server chips with AVX-512 capability.",
        "This benchmark focuses on very wide 512-bit vector lanes. It is intended for CPUs where the runtime reports AVX-512 support. Results here can be much higher than portable SIMD, but behavior also depends on frequency limits, power budget, cooling, and how aggressively the CPU downclocks under AVX-512 load. That makes it a very good test for burn-in comparisons and for seeing whether a server or workstation really benefits from its wide-vector feature set.",
        "Shown only when an AVX-512 family capability is detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector512<float> _a;
        private Vector512<float> _b;
        private Vector512<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            _a = Vector512.Create(
                1.0f + workerIndex, 2.0f, 3.0f, 4.0f,
                5.0f, 6.0f, 7.0f, 8.0f,
                9.0f, 10.0f, 11.0f, 12.0f,
                13.0f, 14.0f, 15.0f, 16.0f);
            _b = Vector512.Create(
                0.5f, 0.75f, 1.0f, 1.25f,
                1.5f, 1.75f, 2.0f, 2.25f,
                2.5f, 2.75f, 3.0f, 3.25f,
                3.5f, 3.75f, 4.0f, 4.25f);
            _c = Vector512.Create(0.125f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var decayA = Vector512.Create(0.99993f);
            var decayB = Vector512.Create(0.99991f);
            var cross = Vector512.Create(0.00019f);
            var drift = Vector512.Create(0.00001f);
            var half = Vector512.Create(0.5f);
            const int iterations = 220_000;

            for (int i = 0; i < iterations; i++)
            {
                var nextA = (a * decayA) + ((b - c) * cross);
                var nextB = (b * decayB) + ((c - a) * cross);
                var nextC = (c * decayA) + ((a - b) * cross);
                a = nextA + drift;
                b = nextB - drift;
                c = (nextC * decayB) + (a * cross);

                if ((i & 255) == 0)
                {
                    a *= half;
                    b *= half;
                    c *= half;
                }
            }

            Span<float> lanesA = stackalloc float[Vector512<float>.Count];
            Span<float> lanesB = stackalloc float[Vector512<float>.Count];
            Span<float> lanesC = stackalloc float[Vector512<float>.Count];
            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            double sum = 0.0;
            for (int lane = 0; lane < Vector512<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = a;
            _b = b;
            _c = c;
            _checksum += sum;
            _work += iterations * Vector512<float>.Count * 12.0;
        }
    }
}

internal sealed class Avx512WidePeakBenchmark : BenchmarkDefinition
{
    public Avx512WidePeakBenchmark() : base(
        "AVX-512 Wide Float32 (Peak)",
        "SIMD / AVX-512 Peak",
        "Higher-throughput 512-bit float vector math with lighter stabilization.",
        MetricKind.FloatingOps,
        "Useful when you want a more aggressive AVX-512 score in addition to the validated variant.",
        "This benchmark is the peak-throughput partner to the validated AVX-512 test. It is tuned to keep the hot loop denser so the machine can show more of its best-case wide-vector behavior, while occasional renormalization still keeps long runs finite. Compare it against the validated AVX-512 result to judge how much overhead stricter numerical control adds on your system.",
        "Shown only when an AVX-512 family capability is detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector512<float> _a;
        private Vector512<float> _b;
        private Vector512<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            _a = Vector512.Create(
                1.0f + workerIndex, 2.0f, 3.0f, 4.0f,
                5.0f, 6.0f, 7.0f, 8.0f,
                9.0f, 10.0f, 11.0f, 12.0f,
                13.0f, 14.0f, 15.0f, 16.0f);
            _b = Vector512.Create(
                0.75f, 1.0f, 1.25f, 1.5f,
                1.75f, 2.0f, 2.25f, 2.5f,
                2.75f, 3.0f, 3.25f, 3.5f,
                3.75f, 4.0f, 4.25f, 4.5f);
            _c = Vector512.Create(0.125f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var mulA = Vector512.Create(1.000019f);
            var mulB = Vector512.Create(0.999983f);
            var mulC = Vector512.Create(1.000011f);
            var small1 = Vector512.Create(0.00041f);
            var small2 = Vector512.Create(0.00023f);
            var quarter = Vector512.Create(0.25f);
            Span<float> lanesA = stackalloc float[Vector512<float>.Count];
            Span<float> lanesB = stackalloc float[Vector512<float>.Count];
            Span<float> lanesC = stackalloc float[Vector512<float>.Count];
            const int iterations = 235_000;

            for (int i = 0; i < iterations; i++)
            {
                var nextA = (a * mulA) + b;
                var nextB = (b * mulB) + c;
                var nextC = (c * mulC) + a;
                a = nextA - (c * small1);
                b = nextB + (a * small2);
                c = nextC - (b * small1);

                if ((i & 2047) == 2047)
                {
                    a *= quarter;
                    b *= quarter;
                    c *= quarter;

                    a.CopyTo(lanesA);
                    b.CopyTo(lanesB);
                    c.CopyTo(lanesC);
                    PeakMathGuard.ClampFinite(lanesA, 4096f, 1.0f, 0.125f);
                    PeakMathGuard.ClampFinite(lanesB, 4096f, 0.75f, 0.125f);
                    PeakMathGuard.ClampFinite(lanesC, 4096f, 0.125f, 0.125f);
                    a = Vector512.Create(
                        lanesA[0], lanesA[1], lanesA[2], lanesA[3], lanesA[4], lanesA[5], lanesA[6], lanesA[7],
                        lanesA[8], lanesA[9], lanesA[10], lanesA[11], lanesA[12], lanesA[13], lanesA[14], lanesA[15]);
                    b = Vector512.Create(
                        lanesB[0], lanesB[1], lanesB[2], lanesB[3], lanesB[4], lanesB[5], lanesB[6], lanesB[7],
                        lanesB[8], lanesB[9], lanesB[10], lanesB[11], lanesB[12], lanesB[13], lanesB[14], lanesB[15]);
                    c = Vector512.Create(
                        lanesC[0], lanesC[1], lanesC[2], lanesC[3], lanesC[4], lanesC[5], lanesC[6], lanesC[7],
                        lanesC[8], lanesC[9], lanesC[10], lanesC[11], lanesC[12], lanesC[13], lanesC[14], lanesC[15]);
                }
            }

            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            PeakMathGuard.ClampFinite(lanesA, 4096f, 1.0f, 0.125f);
            PeakMathGuard.ClampFinite(lanesB, 4096f, 0.75f, 0.125f);
            PeakMathGuard.ClampFinite(lanesC, 4096f, 0.125f, 0.125f);

            double sum = 0.0;
            for (int lane = 0; lane < Vector512<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = Vector512.Create(
                lanesA[0], lanesA[1], lanesA[2], lanesA[3], lanesA[4], lanesA[5], lanesA[6], lanesA[7],
                lanesA[8], lanesA[9], lanesA[10], lanesA[11], lanesA[12], lanesA[13], lanesA[14], lanesA[15]);
            _b = Vector512.Create(
                lanesB[0], lanesB[1], lanesB[2], lanesB[3], lanesB[4], lanesB[5], lanesB[6], lanesB[7],
                lanesB[8], lanesB[9], lanesB[10], lanesB[11], lanesB[12], lanesB[13], lanesB[14], lanesB[15]);
            _c = Vector512.Create(
                lanesC[0], lanesC[1], lanesC[2], lanesC[3], lanesC[4], lanesC[5], lanesC[6], lanesC[7],
                lanesC[8], lanesC[9], lanesC[10], lanesC[11], lanesC[12], lanesC[13], lanesC[14], lanesC[15]);
            _checksum += sum;
            _work += iterations * Vector512<float>.Count * 10.0;
        }
    }
}

internal sealed class AesBlocksBenchmark : BenchmarkDefinition
{
    public AesBlocksBenchmark() : base(
        "AES Blocks",
        "Crypto / AES-NI",
        "Repeated AES round-style block transforms using hardware AES instructions when exposed.",
        MetricKind.Blocks,
        "Useful for systems where AES acceleration matters for storage, networking, or security workloads.",
        "This benchmark targets hardware AES instructions rather than general-purpose arithmetic. It repeatedly transforms many 128-bit blocks with AES round operations, which makes it a useful indicator for encryption-heavy workloads, secure storage, VPNs, packet handling, and similar tasks. It is not meant to be a full cryptographic library benchmark, but it does clearly show whether the CPU's AES path is strong.",
        "Shown only when AES support is detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector128<byte>[] _blocks;
        private readonly Vector128<byte>[] _roundKeys;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            if (!Aes.IsSupported || !Sse2.IsSupported)
                throw new PlatformNotSupportedException("AES benchmark requires AES and SSE2 support.");

            int length = BenchmarkSizing.ByPreset(preset, 512, 1024, 2048, 4096);
            _blocks = new Vector128<byte>[length];
            _roundKeys = new[]
            {
                Vector128.Create((byte)(1 + workerIndex)),
                Vector128.Create((byte)0x11),
                Vector128.Create((byte)0x22),
                Vector128.Create((byte)0x33),
                Vector128.Create((byte)0x44),
                Vector128.Create((byte)0x55),
                Vector128.Create((byte)0x66),
                Vector128.Create((byte)0x77),
                Vector128.Create((byte)0x88),
                Vector128.Create((byte)0x99)
            };

            for (int i = 0; i < _blocks.Length; i++)
                _blocks[i] = Vector128.Create((byte)((i + workerIndex) & 0xFF));
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            double sum = 0.0;
            Span<ulong> lanes = stackalloc ulong[2];
            for (int i = 0; i < _blocks.Length; i++)
            {
                Vector128<byte> state = _blocks[i];
                for (int r = 0; r < _roundKeys.Length - 1; r++)
                    state = Aes.Encrypt(state, _roundKeys[r]);
                state = Aes.EncryptLast(state, _roundKeys[^1]);
                _blocks[i] = state;
                state.AsUInt64().CopyTo(lanes);
                sum += lanes[0];
            }

            _checksum += sum;
            _work += _blocks.Length;
        }
    }
}

internal sealed class MemoryStreamBenchmark : BenchmarkDefinition
{
    public override BenchmarkPlacementBias PlacementBias => BenchmarkPlacementBias.BandwidthSensitive;

    public MemoryStreamBenchmark() : base(
        "Memory Stream",
        "Memory / Bandwidth",
        "Peak-friendly sequential copy and line-spaced write pressure across local worker buffers.",
        MetricKind.Bytes,
        "Useful for raw memory bandwidth comparisons and for spotting when large machines stop scaling on friendly access patterns.",
        "This is the peak-style memory bandwidth test. It copies one worker-owned buffer into another and then performs a light line-spaced mutation for checksum and write pressure. It is intentionally simpler than the sustained variant so it can show the machine's best-case cache-friendly bandwidth behavior. On large NUMA systems it helps answer the question, 'how much friendly streaming bandwidth can this box deliver when the access pattern is simple?'",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly byte[] _src;
        private readonly byte[] _dst;
        private readonly int _lineStride = 64;
        private double _bytes;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 4 * 1024 * 1024, 8 * 1024 * 1024, 16 * 1024 * 1024, 32 * 1024 * 1024);
            _src = new byte[length];
            _dst = new byte[length];
            for (int i = 0; i < _src.Length; i++)
                _src[i] = (byte)((i + workerIndex) & 0xFF);

            // First-touch both arrays on the worker thread so the runtime has
            // the best chance to place them close to the CPU or NUMA node that
            // will actually run this worker. We keep the benchmark logic simple
            // after that so the score remains comparable to earlier peak-style
            // revisions that the user found informative.
            for (int i = 0; i < _dst.Length; i += _lineStride)
                _dst[i] = (byte)((workerIndex + i) & 0xFF);
        }

        public double WorkCompleted => _bytes;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            Buffer.BlockCopy(_src, 0, _dst, 0, _src.Length);
            double localChecksum = 0.0;
            for (int i = 0; i < _dst.Length; i += _lineStride)
            {
                _dst[i] ^= (byte)(i & 0xFF);
                localChecksum += _dst[i];
            }

            _checksum += localChecksum;
            _bytes += _src.Length * 2.0;
        }
    }
}

internal sealed class MemoryStreamSustainedBenchmark : BenchmarkDefinition
{
    public override BenchmarkPlacementBias PlacementBias => BenchmarkPlacementBias.BandwidthSensitive;

    public MemoryStreamSustainedBenchmark() : base(
        "Memory Stream (Sustained)",
        "Memory / Bandwidth Sustained",
        "Sustained sequential rewrite pressure that swaps source and destination buffers every batch.",
        MetricKind.Bytes,
        "Useful for seeing how a machine behaves when each batch reads what the previous batch just wrote instead of repeatedly copying one immutable source.",
        "This is the sustained partner to Memory Stream. It first-touches both buffers locally and then performs a single streaming pass that copies, lightly mutates, and checksums each cache line before swapping the roles of source and destination for the next batch. That makes it less peak-friendly but more representative of workloads that continuously move and rewrite large regions of memory over time.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private byte[] _src;
        private byte[] _dst;
        private readonly int _lineStride = 64;
        private ulong _lineXorSeed;
        private double _bytes;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 4 * 1024 * 1024, 8 * 1024 * 1024, 16 * 1024 * 1024, 32 * 1024 * 1024);
            _src = new byte[length];
            _dst = new byte[length];
            _lineXorSeed = 0x9E3779B97F4A7C15UL ^ (ulong)(workerIndex + 1);
            for (int i = 0; i < _src.Length; i++)
                _src[i] = (byte)((i + workerIndex) & 0xFF);

            // First-touch every future destination cache line on the worker
            // thread so large NUMA boxes have a fair chance to keep sustained
            // bandwidth local before Adaptive placement spreads the workers out.
            for (int i = 0; i < _dst.Length; i += _lineStride)
                _dst[i] = (byte)((workerIndex + i) & 0xFF);
        }

        public double WorkCompleted => _bytes;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            // v23 replaces the old two-pass sustained path (bulk copy, then
            // sparse mutation) with a single streaming pass. Each cache line is
            // copied, lightly mutated, and checksummed before moving on. That
            // better reflects a rewrite-heavy sustained workload and avoids the
            // extra second walk that hurt full-machine scaling on large systems.
            Span<ulong> srcWords = MemoryMarshal.Cast<byte, ulong>(_src.AsSpan());
            Span<ulong> dstWords = MemoryMarshal.Cast<byte, ulong>(_dst.AsSpan());
            int wordsPerLine = _lineStride / sizeof(ulong);
            ulong localChecksum = 0UL;
            ulong lineXorSeed = _lineXorSeed;

            for (int i = 0; i < srcWords.Length; i += wordsPerLine)
            {
                for (int lane = 0; lane < wordsPerLine; lane++)
                    dstWords[i + lane] = srcWords[i + lane];

                // Mutate the first word of each cache line so the next batch
                // really does read what the previous batch wrote.
                dstWords[i] ^= lineXorSeed;
                localChecksum += dstWords[i] ^ dstWords[i + wordsPerLine - 1];
                lineXorSeed = BitOperations.RotateLeft(lineXorSeed + 0x9E3779B185EBCA87UL, 7);
            }

            _lineXorSeed = lineXorSeed;
            (_src, _dst) = (_dst, _src);
            _checksum += localChecksum;
            _bytes += _src.Length * 2.0;
        }
    }
}

internal sealed class MatrixMultiplyBenchmark : BenchmarkDefinition
{
    public MatrixMultiplyBenchmark() : base(
        "Matrix Multiply",
        "Math / Dense",
        "Dense matrix multiplication using local worker matrices.",
        MetricKind.FloatingOps,
        "Useful for sustained compute with heavy cache reuse.",
        "This benchmark performs classic dense matrix multiplication. It is a good approximation for steady numerical throughput with a lot of arithmetic reuse. It is usually one of the most useful tests for comparing powerful workstations and servers because it reflects how well cores, caches, and memory cooperate during sustained numerical work. It also responds well to longer burn-in sessions.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int _n;
        private readonly double[] _a;
        private readonly double[] _b;
        private readonly double[] _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            _n = BenchmarkSizing.ByPreset(preset, 72, 96, 128, 160);
            _a = new double[_n * _n];
            _b = new double[_n * _n];
            _c = new double[_n * _n];
            for (int i = 0; i < _a.Length; i++)
            {
                _a[i] = ((i + workerIndex) % 17) * 0.5;
                _b[i] = ((i + workerIndex * 3) % 23) * 0.25;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            Array.Clear(_c, 0, _c.Length);
            for (int i = 0; i < _n; i++)
            {
                int inBase = i * _n;
                for (int k = 0; k < _n; k++)
                {
                    double aik = _a[inBase + k];
                    int knBase = k * _n;
                    for (int j = 0; j < _n; j++)
                        _c[inBase + j] += aik * _b[knBase + j];
                }
            }

            double sum = 0.0;
            for (int i = 0; i < _c.Length; i += Math.Max(1, _n / 3))
                sum += _c[i];
            _checksum += sum;
            _work += 2.0 * _n * _n * _n;
        }
    }
}

internal sealed class PrimeScanBenchmark : BenchmarkDefinition
{
    public PrimeScanBenchmark() : base(
        "Prime Scan",
        "Control Flow / Integer",
        "Trial division across rising odd integers.",
        MetricKind.Numbers,
        "Good for branch-heavy integer work and cache-light scaling tests.",
        "Prime Scan is a classic branch-heavy integer workload. It repeatedly tests odd integers for primality by trial division up to square root. That gives it many control-flow turns and less predictable work per candidate than the straight-line arithmetic tests. It is a good way to see how a machine behaves when each thread does a lot of small integer decisions rather than dense vector math.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private int _current;
        private double _numbers;
        private double _checksum;

        public Worker(int workerIndex)
        {
            _current = 100_000 + workerIndex * 10_000;
            if ((_current & 1) == 0)
                _current++;
        }

        public double WorkCompleted => _numbers;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            const int count = 4_000;
            int checkedCount = 0;
            int found = 0;
            while (checkedCount < count)
            {
                if (IsPrime(_current))
                {
                    found++;
                    _checksum += _current;
                }
                _current += 2;
                checkedCount++;
            }
            _numbers += count;
            _checksum += found;
        }

        private static bool IsPrime(int value)
        {
            if (value < 2) return false;
            if ((value & 1) == 0) return value == 2;
            int limit = (int)Math.Sqrt(value);
            for (int i = 3; i <= limit; i += 2)
            {
                if (value % i == 0)
                    return false;
            }
            return true;
        }
    }
}

internal sealed class MandelbrotBenchmark : BenchmarkDefinition
{
    public MandelbrotBenchmark() : base(
        "Mandelbrot",
        "Mixed / FP+Branch",
        "Escape-time fractal compute over a local tile.",
        MetricKind.Pixels,
        "Good for floating-point plus branch behavior on independent pixels.",
        "Mandelbrot mixes floating-point arithmetic with conditional escape checks over lots of independent pixels. That makes it useful as a mixed real-world-style compute benchmark. It is less synthetic than raw ALU or AES tests and often gives a good feel for how a CPU handles independent work items that still contain branch decisions. It is especially interesting when comparing many-core machines against mainstream desktops.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int _width;
        private readonly int _height;
        private readonly int _maxIterations;
        private readonly int _workerIndex;
        private double _pixels;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            _workerIndex = workerIndex;
            _width = BenchmarkSizing.ByPreset(preset, 256, 384, 512, 768);
            _height = _width;
            _maxIterations = BenchmarkSizing.ByPreset(preset, 128, 192, 256, 384);
        }

        public double WorkCompleted => _pixels;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            double sum = 0.0;
            double xOffset = (_workerIndex % 8) * 0.001;
            double yOffset = (_workerIndex % 5) * 0.001;
            for (int y = 0; y < _height; y++)
            {
                double cy = -1.2 + 2.4 * y / (_height - 1) + yOffset;
                for (int x = 0; x < _width; x++)
                {
                    double cx = -2.2 + 3.0 * x / (_width - 1) + xOffset;
                    double zx = 0.0;
                    double zy = 0.0;
                    int iter = 0;
                    while (zx * zx + zy * zy <= 4.0 && iter < _maxIterations)
                    {
                        double nextX = zx * zx - zy * zy + cx;
                        zy = 2.0 * zx * zy + cy;
                        zx = nextX;
                        iter++;
                    }
                    sum += iter;
                }
            }
            _pixels += (double)_width * _height;
            _checksum += sum;
        }
    }
}
