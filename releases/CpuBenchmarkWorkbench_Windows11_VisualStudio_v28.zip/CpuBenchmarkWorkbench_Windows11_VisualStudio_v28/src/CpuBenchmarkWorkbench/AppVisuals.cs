using System.Drawing;

namespace CpuBenchmarkWorkbench;

/// <summary>
/// Loads shared visual assets for the application.
///
/// Keeping icon handling in one place makes it easier for new contributors to see
/// where branding lives and how to replace it without hunting through multiple forms.
/// </summary>
internal static class AppVisuals
{
    private const string PrimaryIconFileName = "cpu-benchmark-workbench-icon-primary.ico";

    /// <summary>
    /// Applies the shared application icon to a form when possible.
    ///
    /// The helper first tries the copied asset inside the output folder. If that is not
    /// available, it falls back to the executable icon so the window still looks correct.
    /// </summary>
    public static void TryApplyWindowIcon(Form form)
    {
        try
        {
            var icon = LoadPrimaryIcon();
            if (icon is not null)
                form.Icon = icon;
        }
        catch
        {
            // Branding should never be able to break the benchmark tool.
        }
    }

    /// <summary>
    /// Loads the preferred icon from the output folder or, failing that, from the built executable.
    /// </summary>
    private static Icon? LoadPrimaryIcon()
    {
        string assetPath = Path.Combine(AppContext.BaseDirectory, "Assets", PrimaryIconFileName);
        if (File.Exists(assetPath))
            return new Icon(assetPath);

        string exePath = Application.ExecutablePath;
        if (!string.IsNullOrWhiteSpace(exePath) && File.Exists(exePath))
            return Icon.ExtractAssociatedIcon(exePath);

        return null;
    }
}
