using System.Text;

namespace CpuBenchmarkWorkbench;

/// <summary>
/// Final score snapshot for one completed run or burn-in session.
///
/// The overall score is anchored to a real reference run captured during the
/// v23 validation cycle. A machine that reproduces that reference profile lands
/// around 2,000 points. A machine that is about 50x faster across the covered
/// benchmark profile would land at 100,000 points.
///
/// We use a weighted geometric mean rather than a plain arithmetic sum so one
/// extreme metric cannot drown out the rest of the machine profile.
/// </summary>
public sealed class BenchmarkScoreSnapshot
{
    public string SessionId { get; init; } = string.Empty;
    public int OverallScore { get; init; }
    public double RelativeToReference { get; init; }
    public double CoveragePercent { get; init; }
    public string BestFitTitle { get; init; } = string.Empty;
    public string Opinion { get; init; } = string.Empty;
    public string StrengthSummary { get; init; } = string.Empty;
    public IReadOnlyList<BenchmarkCategoryScore> CategoryScores { get; init; } = Array.Empty<BenchmarkCategoryScore>();
    public IReadOnlyList<string> BenchmarksUsed { get; init; } = Array.Empty<string>();
    public IReadOnlyList<string> MissingBenchmarks { get; init; } = Array.Empty<string>();

    public string ScoreHeadline => $"Overall PC score: {OverallScore:N0} / 100,000";
    public string RelativeHeadline => $"Reference anchor: {RelativeToReference:N2}x | coverage: {CoveragePercent:N0}%";

    public string ToMultilineReport()
    {
        var sb = new StringBuilder();
        sb.AppendLine("CPU Benchmark Workbench - Overall Score Report");
        sb.AppendLine($"Generated: {DateTime.Now:F}");
        if (!string.IsNullOrWhiteSpace(SessionId))
            sb.AppendLine($"Session: {SessionId}");
        sb.AppendLine();
        sb.AppendLine(ScoreHeadline);
        sb.AppendLine(RelativeHeadline);
        sb.AppendLine($"Best fit: {BestFitTitle}");
        sb.AppendLine($"Opinion: {Opinion}");
        if (!string.IsNullOrWhiteSpace(StrengthSummary))
            sb.AppendLine($"Strength summary: {StrengthSummary}");
        sb.AppendLine();
        sb.AppendLine("Category breakdown:");
        foreach (var category in CategoryScores)
            sb.AppendLine($"- {category.Name}: {category.RelativeToReference:N2}x reference ({category.Summary})");

        sb.AppendLine();
        sb.AppendLine("Benchmarks used in this score:");
        foreach (var name in BenchmarksUsed)
            sb.AppendLine($"- {name}");

        if (MissingBenchmarks.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Benchmarks missing from this run:");
            foreach (var name in MissingBenchmarks)
                sb.AppendLine($"- {name}");
        }

        sb.AppendLine();
        sb.AppendLine("Scoring note:");
        sb.AppendLine("- 2,000 points is the v23 reference workstation profile used to anchor this scale.");
        sb.AppendLine("- 100,000 points would require a machine that is about 50x faster across the covered benchmark profile.");
        sb.AppendLine("- Partial benchmark selections still produce a score, but lower coverage means the result should be treated as more provisional.");
        return sb.ToString();
    }
}

public sealed class BenchmarkCategoryScore
{
    public string Name { get; init; } = string.Empty;
    public double RelativeToReference { get; init; }
    public string Summary { get; init; } = string.Empty;
}

public static class BenchmarkScoringEngine
{
    /// <summary>
    /// Weight each benchmark by how much it should matter to the whole-machine
    /// score. The weights sum to 1.0.
    /// </summary>
    private static readonly Dictionary<string, double> BenchmarkWeights = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Integer Mix"] = 0.08,
        ["Bit Twister"] = 0.05,
        ["Floating Point Mix"] = 0.06,
        ["Floating Point Mix (Peak)"] = 0.04,
        ["Branch Chaos"] = 0.05,
        ["Cache Walker"] = 0.05,
        ["SIMD Vector Math"] = 0.08,
        ["AVX2 / FMA Float32"] = 0.08,
        ["AVX2 / FMA Float32 (Peak)"] = 0.05,
        ["AVX-512 Wide Float32"] = 0.08,
        ["AVX-512 Wide Float32 (Peak)"] = 0.05,
        ["AES Blocks"] = 0.04,
        ["Memory Stream"] = 0.06,
        ["Memory Stream (Sustained)"] = 0.10,
        ["Matrix Multiply"] = 0.08,
        ["Prime Scan"] = 0.03,
        ["Mandelbrot"] = 0.02
    };

    /// <summary>
    /// Best observed results from the validated reference run that motivated the
    /// v24 scoring scale. Matching this profile should land close to 2,000.
    /// 50x this profile maps to 100,000 by construction.
    /// </summary>
    private static readonly Dictionary<string, double> ReferenceBestScores = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Integer Mix"] = 51407237564.0959,
        ["Bit Twister"] = 29426034759.0466,
        ["Floating Point Mix"] = 39808435415.5512,
        ["Floating Point Mix (Peak)"] = 49843691538.2629,
        ["Branch Chaos"] = 1349808651.2408,
        ["Cache Walker"] = 1721508000.4085,
        ["SIMD Vector Math"] = 39398459432.5741,
        ["AVX2 / FMA Float32"] = 142567689251.0795,
        ["AVX2 / FMA Float32 (Peak)"] = 145417489763.7721,
        ["AVX-512 Wide Float32"] = 118461809595.5251,
        ["AVX-512 Wide Float32 (Peak)"] = 108908046153.3735,
        ["AES Blocks"] = 597747542.1972,
        ["Memory Stream"] = 22640981473.0324,
        ["Memory Stream (Sustained)"] = 31024171511.6658,
        ["Matrix Multiply"] = 10981698549.2462,
        ["Prime Scan"] = 44639328.1376,
        ["Mandelbrot"] = 91605544.8694
    };

    private static readonly CategoryDefinition[] Categories =
    [
        new CategoryDefinition(
            "General Throughput",
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Integer Mix"] = 0.30,
                ["Bit Twister"] = 0.25,
                ["Branch Chaos"] = 0.25,
                ["Prime Scan"] = 0.20
            },
            "scalar integer work, code-heavy tools, and mixed general-purpose CPU duty"),
        new CategoryDefinition(
            "Scientific / Simulation",
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Floating Point Mix"] = 0.10,
                ["Floating Point Mix (Peak)"] = 0.05,
                ["SIMD Vector Math"] = 0.15,
                ["AVX2 / FMA Float32"] = 0.20,
                ["AVX2 / FMA Float32 (Peak)"] = 0.10,
                ["AVX-512 Wide Float32"] = 0.20,
                ["AVX-512 Wide Float32 (Peak)"] = 0.10,
                ["Matrix Multiply"] = 0.10
            },
            "numerical analysis, simulation, dense vector math, and compute-heavy workstation tasks"),
        new CategoryDefinition(
            "Memory / Data Movement",
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Cache Walker"] = 0.25,
                ["Memory Stream"] = 0.35,
                ["Memory Stream (Sustained)"] = 0.40
            },
            "streaming transforms, large data movement, and memory-sensitive analytics"),
        new CategoryDefinition(
            "Encryption / Secure Data",
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["AES Blocks"] = 1.0
            },
            "encryption-heavy storage, VPN, backup, and secure transport work"),
        new CategoryDefinition(
            "Visual / Creator Math",
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["Mandelbrot"] = 0.45,
                ["Matrix Multiply"] = 0.30,
                ["SIMD Vector Math"] = 0.25
            },
            "fractal-style rendering, creator-side image math, and visually heavy CPU compute"),
    ];

    public static BenchmarkScoreSnapshot Evaluate(IEnumerable<BenchmarkResult> allResults, string? sessionId = null)
    {
        var filtered = allResults
            .Where(x => x.ScorePerSecond > 0.0)
            .Where(x => string.IsNullOrWhiteSpace(sessionId) || string.Equals(x.SessionId, sessionId, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (filtered.Count == 0)
        {
            return new BenchmarkScoreSnapshot
            {
                SessionId = sessionId ?? string.Empty,
                OverallScore = 0,
                RelativeToReference = 0.0,
                CoveragePercent = 0.0,
                BestFitTitle = "No score yet",
                Opinion = "Run at least one benchmark to generate an anchored overall score.",
                StrengthSummary = "No benchmark data available."
            };
        }

        var bestScores = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        foreach (var result in filtered)
        {
            if (!bestScores.TryGetValue(result.Benchmark, out double currentBest) || result.ScorePerSecond > currentBest)
                bestScores[result.Benchmark] = result.ScorePerSecond;
        }

        double weightedLogSum = 0.0;
        double usedWeight = 0.0;
        var benchmarksUsed = new List<string>();

        foreach (var pair in ReferenceBestScores)
        {
            if (!BenchmarkWeights.TryGetValue(pair.Key, out double weight))
                continue;

            if (!bestScores.TryGetValue(pair.Key, out double observed) || observed <= 0.0 || pair.Value <= 0.0)
                continue;

            double ratio = Math.Max(observed / pair.Value, 1e-9);
            weightedLogSum += weight * Math.Log(ratio);
            usedWeight += weight;
            benchmarksUsed.Add(pair.Key);
        }

        double totalWeight = BenchmarkWeights.Values.Sum();
        double coveragePercent = totalWeight > 0.0 ? (usedWeight / totalWeight) * 100.0 : 0.0;
        double relativeToReference = usedWeight > 0.0 ? Math.Exp(weightedLogSum / usedWeight) : 0.0;
        int overallScore = (int)Math.Round(Math.Clamp(2000.0 * relativeToReference, 0.0, 100000.0), MidpointRounding.AwayFromZero);

        var missingBenchmarks = ReferenceBestScores.Keys
            .Where(name => !benchmarksUsed.Contains(name, StringComparer.OrdinalIgnoreCase))
            .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
            .ToArray();

        var categoryScores = EvaluateCategories(bestScores);
        var strongestCategory = categoryScores.OrderByDescending(x => x.RelativeToReference).FirstOrDefault();
        var weakestCategory = categoryScores.OrderBy(x => x.RelativeToReference).FirstOrDefault();

        string bestFitTitle = strongestCategory?.Name ?? "General Throughput";
        string opinion = BuildOpinion(bestFitTitle, strongestCategory?.RelativeToReference ?? relativeToReference, weakestCategory?.Name, weakestCategory?.RelativeToReference ?? relativeToReference, coveragePercent);
        string strengthSummary = BuildStrengthSummary(strongestCategory, weakestCategory);

        return new BenchmarkScoreSnapshot
        {
            SessionId = sessionId ?? filtered.Last().SessionId ?? string.Empty,
            OverallScore = overallScore,
            RelativeToReference = relativeToReference,
            CoveragePercent = coveragePercent,
            BestFitTitle = bestFitTitle,
            Opinion = opinion,
            StrengthSummary = strengthSummary,
            CategoryScores = categoryScores,
            BenchmarksUsed = benchmarksUsed.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToArray(),
            MissingBenchmarks = missingBenchmarks
        };
    }

    private static IReadOnlyList<BenchmarkCategoryScore> EvaluateCategories(Dictionary<string, double> bestScores)
    {
        var results = new List<BenchmarkCategoryScore>(Categories.Length);

        foreach (var category in Categories)
        {
            double weightedSum = 0.0;
            double usedWeight = 0.0;
            foreach (var pair in category.BenchmarkWeights)
            {
                if (!bestScores.TryGetValue(pair.Key, out double observed))
                    continue;
                if (!ReferenceBestScores.TryGetValue(pair.Key, out double baseline) || baseline <= 0.0)
                    continue;

                weightedSum += pair.Value * (observed / baseline);
                usedWeight += pair.Value;
            }

            double ratio = usedWeight > 0.0 ? weightedSum / usedWeight : 0.0;
            string summary = ratio switch
            {
                >= 1.20 => $"well above the reference for {category.UseCaseHint}",
                >= 1.05 => $"a little above the reference for {category.UseCaseHint}",
                >= 0.95 => $"roughly in line with the reference for {category.UseCaseHint}",
                >= 0.80 => $"somewhat behind the reference for {category.UseCaseHint}",
                > 0.0 => $"well behind the reference for {category.UseCaseHint}",
                _ => $"not enough data yet for {category.UseCaseHint}"
            };

            results.Add(new BenchmarkCategoryScore
            {
                Name = category.Name,
                RelativeToReference = ratio,
                Summary = summary
            });
        }

        return results;
    }

    private static string BuildOpinion(string bestFitTitle, double bestFitRatio, string? weakestTitle, double weakestRatio, double coveragePercent)
    {
        string bestUseCase = Categories.FirstOrDefault(x => string.Equals(x.Name, bestFitTitle, StringComparison.OrdinalIgnoreCase))?.UseCaseHint
            ?? "balanced CPU work";

        string strengthLead = bestFitRatio switch
        {
            >= 1.20 => $"This machine looks especially strong for {bestUseCase}.",
            >= 1.05 => $"This machine looks modestly stronger than the reference for {bestUseCase}.",
            >= 0.95 => $"This machine tracks the reference most closely in {bestUseCase}.",
            _ => $"Based on this run, the machine still leans most toward {bestUseCase}, but not from a dominant strength."
        };

        string weakNote = weakestRatio switch
        {
            <= 0.0 => string.Empty,
            < 0.80 when !string.IsNullOrWhiteSpace(weakestTitle) => $" The softest area in this run is {weakestTitle}, so workloads dominated by that pattern may scale less impressively.",
            < 0.95 when !string.IsNullOrWhiteSpace(weakestTitle) => $" The weakest relative area is {weakestTitle}, though it is not dramatically behind.",
            _ => string.Empty
        };

        string coverageNote = coveragePercent switch
        {
            < 35.0 => " Coverage is low, so treat the score as a rough provisional estimate rather than a final whole-PC rating.",
            < 75.0 => " Coverage is partial, so the score is useful but still less authoritative than a full suite run.",
            _ => string.Empty
        };

        return strengthLead + weakNote + coverageNote;
    }

    private static string BuildStrengthSummary(BenchmarkCategoryScore? strongestCategory, BenchmarkCategoryScore? weakestCategory)
    {
        if (strongestCategory is null && weakestCategory is null)
            return "No category data available.";

        if (strongestCategory is null)
            return $"Weakest area observed: {weakestCategory!.Name}.";

        if (weakestCategory is null)
            return $"Strongest area observed: {strongestCategory.Name}.";

        return $"Strongest area: {strongestCategory.Name} ({strongestCategory.RelativeToReference:N2}x). Softest area: {weakestCategory.Name} ({weakestCategory.RelativeToReference:N2}x).";
    }

    private sealed class CategoryDefinition
    {
        public CategoryDefinition(string name, Dictionary<string, double> benchmarkWeights, string useCaseHint)
        {
            Name = name;
            BenchmarkWeights = benchmarkWeights;
            UseCaseHint = useCaseHint;
        }

        public string Name { get; }
        public Dictionary<string, double> BenchmarkWeights { get; }
        public string UseCaseHint { get; }
    }
}
