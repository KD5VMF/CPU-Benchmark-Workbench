using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace CpuBenchmarkWorkbench;

public sealed class ScalingGraphSnapshot
{
    public string SessionId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Subtitle { get; init; } = string.Empty;
    public IReadOnlyList<ScalingGraphSeries> Series { get; init; } = Array.Empty<ScalingGraphSeries>();
    public IReadOnlyList<int> ThreadTicks { get; init; } = Array.Empty<int>();
    public double MaxScalingPercent { get; init; }
}

public sealed class ScalingGraphSeries
{
    public string Name { get; init; } = string.Empty;
    public int ColorIndex { get; init; }
    public IReadOnlyList<ScalingGraphPoint> Points { get; init; } = Array.Empty<ScalingGraphPoint>();
}

public readonly record struct ScalingGraphPoint(int Threads, double ScalingPercent);

internal readonly record struct ScalingGraphExport(string FilePath, ScalingGraphSnapshot Snapshot);

internal static class ScalingGraphBuilder
{
    private static readonly string[] PreferredBenchmarks =
    [
        "Integer Mix",
        "AVX-512 Wide Float32",
        "AVX2 / FMA Float32",
        "Memory Stream",
        "Memory Stream (Sustained)",
        "AES Blocks",
        "Matrix Multiply",
        "Prime Scan",
        "Mandelbrot"
    ];

    public static string? GetPreviewSessionId(IEnumerable<BenchmarkResult> results, BenchmarkResult? selectedResult)
    {
        if (selectedResult is not null && !string.IsNullOrWhiteSpace(selectedResult.SessionId))
            return selectedResult.SessionId;

        return results
            .Where(x => !string.IsNullOrWhiteSpace(x.SessionId))
            .OrderByDescending(x => x.StartedAt)
            .Select(x => x.SessionId)
            .FirstOrDefault();
    }

    public static IReadOnlyList<ScalingGraphExport> BuildExports(IEnumerable<BenchmarkResult> results, CpuCapabilityReport report)
    {
        var exports = new List<ScalingGraphExport>();
        var sessions = results
            .Where(x => x.ScorePerSecond > 0.0 && !string.IsNullOrWhiteSpace(x.SessionId))
            .GroupBy(x => x.SessionId, StringComparer.OrdinalIgnoreCase)
            .OrderBy(g => g.Min(x => x.StartedAt))
            .ToList();

        if (sessions.Count == 0)
            return exports;

        string? singleSessionId = sessions.Count == 1 ? sessions[0].Key : null;
        foreach (var session in sessions)
        {
            var snapshot = BuildForSession(results, report, session.Key);
            if (snapshot is null)
                continue;

            string suffix = singleSessionId is not null
                ? "-thread-scaling.png"
                : $"-session-{SanitizeFileName(session.Key)}-thread-scaling.png";

            exports.Add(new ScalingGraphExport(suffix, snapshot));
        }

        return exports;
    }

    public static ScalingGraphSnapshot? BuildForSession(IEnumerable<BenchmarkResult> allResults, CpuCapabilityReport report, string sessionId)
    {
        var sessionResults = allResults
            .Where(x => x.ScorePerSecond > 0.0)
            .Where(x => string.Equals(x.SessionId, sessionId, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Threads)
            .ThenBy(x => x.StartedAt)
            .ToList();

        if (sessionResults.Count == 0)
            return null;

        var presetLabel = sessionResults
            .Select(x => x.Preset)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var placementLabel = sessionResults
            .Select(x => x.Placement)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var scoring = BenchmarkScoringEngine.Evaluate(sessionResults, sessionId);
        var grouped = sessionResults
            .GroupBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Threads).ThenBy(x => x.StartedAt).ToList(), StringComparer.OrdinalIgnoreCase);

        var orderedBenchmarkNames = new List<string>();
        foreach (string name in PreferredBenchmarks)
        {
            if (grouped.ContainsKey(name))
                orderedBenchmarkNames.Add(name);
        }

        foreach (string name in grouped.Keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            if (!orderedBenchmarkNames.Contains(name, StringComparer.OrdinalIgnoreCase))
                orderedBenchmarkNames.Add(name);
        }

        var series = new List<ScalingGraphSeries>();
        foreach (string benchmarkName in orderedBenchmarkNames)
        {
            var benchmarkResults = grouped[benchmarkName];
            double? baseline = benchmarkResults
                .Where(x => x.Threads == 1)
                .OrderByDescending(x => x.ScorePerSecond)
                .Select(x => (double?)x.ScorePerSecond)
                .FirstOrDefault();

            var points = new List<ScalingGraphPoint>();
            foreach (var result in benchmarkResults
                .GroupBy(x => x.Threads)
                .OrderBy(g => g.Key))
            {
                var bestAtThread = result.OrderByDescending(x => x.ScorePerSecond).First();
                double scaling = 0.0;

                if (baseline.HasValue && baseline.Value > 0.0)
                    scaling = (bestAtThread.ScorePerSecond / baseline.Value) * 100.0;
                else if (bestAtThread.Threads == 1)
                    scaling = 100.0;
                else if (bestAtThread.ScalingPercent > 0.0)
                    scaling = bestAtThread.ScalingPercent;

                if (scaling > 0.0)
                    points.Add(new ScalingGraphPoint(bestAtThread.Threads, scaling));
            }

            if (points.Count == 0)
                continue;

            series.Add(new ScalingGraphSeries
            {
                Name = benchmarkName,
                ColorIndex = series.Count,
                Points = points
            });
        }

        if (series.Count == 0)
            return null;

        var threadTicks = series
            .SelectMany(x => x.Points)
            .Select(x => x.Threads)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        double maxScaling = series
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        string subtitle =
            $"Session: {sessionId}   |   System: {Environment.MachineName}   |   Preset: {presetLabel}   |   Placement: {placementLabel}   |   Profile: {report.CapabilitySummary}";

        return new ScalingGraphSnapshot
        {
            SessionId = sessionId,
            Title = $"Key benchmark scaling by thread count ({report.VisibleThreads} visible threads, best fit: {scoring.BestFitTitle})",
            Subtitle = subtitle,
            Series = series,
            ThreadTicks = threadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private static string SanitizeFileName(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "session";

        foreach (char invalid in Path.GetInvalidFileNameChars())
            value = value.Replace(invalid, '-');

        return value.Replace(' ', '-');
    }
}

internal readonly record struct ScalingGraphLayout(Rectangle PlotRect, Rectangle LegendRect, Rectangle InsightRect);

internal static class ScalingGraphRenderer
{
    private static readonly Color[] SeriesColors =
    [
        Color.FromArgb(31, 119, 180),
        Color.FromArgb(255, 127, 14),
        Color.FromArgb(44, 160, 44),
        Color.FromArgb(214, 39, 40),
        Color.FromArgb(148, 103, 189),
        Color.FromArgb(140, 86, 75),
        Color.FromArgb(227, 119, 194),
        Color.FromArgb(127, 127, 127),
        Color.FromArgb(188, 189, 34),
        Color.FromArgb(23, 190, 207)
    ];

    private static readonly IReadOnlyDictionary<string, BenchmarkDefinition> BenchmarkDefinitions =
        new BenchmarkDefinition[]
        {
            new IntegerMixBenchmark(),
            new BitTwisterBenchmark(),
            new FloatingPointBenchmark(),
            new FloatingPointPeakBenchmark(),
            new BranchChaosBenchmark(),
            new CacheWalkerBenchmark(),
            new SimdVectorBenchmark(),
            new Avx2FmaBenchmark(),
            new Avx2FmaPeakBenchmark(),
            new Avx512WideBenchmark(),
            new Avx512WidePeakBenchmark(),
            new AesBlocksBenchmark(),
            new MemoryStreamBenchmark(),
            new MemoryStreamSustainedBenchmark(),
            new MatrixMultiplyBenchmark(),
            new PrimeScanBenchmark(),
            new MandelbrotBenchmark()
        }
        .ToDictionary(x => x.Name, StringComparer.OrdinalIgnoreCase);

    public static Color GetSeriesColor(int seriesIndex)
    {
        if (seriesIndex < 0)
            seriesIndex = 0;

        return SeriesColors[seriesIndex % SeriesColors.Length];
    }

    public static Bitmap CreateBitmap(ScalingGraphSnapshot snapshot, Size size)
    {
        int width = Math.Max(1200, size.Width);
        int height = Math.Max(700, size.Height);

        var bitmap = new Bitmap(width, height);
        using var graphics = Graphics.FromImage(bitmap);
        Draw(graphics, new Rectangle(0, 0, width, height), snapshot);
        return bitmap;
    }

    public static void SavePng(ScalingGraphSnapshot snapshot, string path, Size size)
    {
        using var bitmap = CreateBitmap(snapshot, size);
        bitmap.Save(path, ImageFormat.Png);
    }

    internal static ScalingGraphLayout GetLayout(Rectangle bounds, int seriesCount)
    {
        int leftMargin = bounds.Left + 92;
        int rightMargin = bounds.Right - 30;
        int topMargin = bounds.Top + 110;
        int bottomMargin = bounds.Bottom - 92;
        int sidePanelWidth = 320;

        Rectangle plotRect = new(leftMargin, topMargin, Math.Max(300, rightMargin - leftMargin - sidePanelWidth), Math.Max(260, bottomMargin - topMargin));
        int sidePanelLeft = plotRect.Right + 18;
        int sidePanelWidthActual = Math.Max(220, rightMargin - sidePanelLeft);
        int legendDesiredHeight = 52 + (Math.Max(0, seriesCount) * 28);
        int legendHeight = Math.Min(Math.Max(82, legendDesiredHeight), Math.Max(90, plotRect.Height - 140));
        Rectangle legendRect = new(sidePanelLeft, plotRect.Top + 8, sidePanelWidthActual, legendHeight);
        Rectangle insightRect = new(sidePanelLeft, legendRect.Bottom + 12, sidePanelWidthActual, Math.Max(120, plotRect.Bottom - (legendRect.Bottom + 12)));
        return new ScalingGraphLayout(plotRect, legendRect, insightRect);
    }

    internal static string BuildFocusedAnalysisText(ScalingGraphSnapshot snapshot)
    {
        if (snapshot.Series.Count != 1)
            return $"Show just one benchmark line and this box will switch into benchmark-specific analysis. It will explain the math kernel, what part of the PC that test stresses, what a strong scaling curve looks like for that exact benchmark, what this current run is saying, and what to compare next. Right now {snapshot.Series.Count} lines are visible.";

        var series = snapshot.Series[0];
        var insight = BuildInsight(series);
        return string.Join(Environment.NewLine + Environment.NewLine,
        [
            $"Status: {insight.StatusTitle}",
            series.Name,
            $"Headline:{Environment.NewLine}{insight.Headline}",
            $"Math / kernel details:{Environment.NewLine}{insight.TechnicalKernel}",
            $"Why this benchmark matters:{Environment.NewLine}{insight.WhatItTests}",
            $"What a strong result usually looks like:{Environment.NewLine}{insight.WhatToExpect}",
            $"Current run summary:{Environment.NewLine}{insight.CurrentResult}",
            $"What this says about this PC:{Environment.NewLine}{insight.PcTakeaway}",
            $"Suggested next comparison:{Environment.NewLine}{insight.SuggestedNextStep}"
        ]);
    }

    public static void Draw(Graphics graphics, Rectangle bounds, ScalingGraphSnapshot snapshot)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        graphics.Clear(Color.FromArgb(245, 245, 245));

        using var titleFont = new Font("Segoe UI Semibold", 20F, FontStyle.Bold, GraphicsUnit.Point);
        using var subtitleFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var axisFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var tickFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        using var legendFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

        int titleTop = bounds.Top + 18;
        int subtitleTop = titleTop + 42;
        var layout = GetLayout(bounds, snapshot.Series.Count);
        Rectangle plotRect = layout.PlotRect;
        Rectangle legendRect = layout.LegendRect;
        Rectangle insightRect = layout.InsightRect;
        int leftMargin = plotRect.Left;

        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
        using var subtitleBrush = new SolidBrush(Color.FromArgb(80, 80, 80));
        using var axisBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var gridPen = new Pen(Color.FromArgb(214, 214, 214), 1F);
        using var axisPen = new Pen(Color.FromArgb(60, 60, 60), 1.2F);

        var centerFormat = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        var rightFormat = new StringFormat { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center };

        graphics.DrawString(snapshot.Title, titleFont, titleBrush, new RectangleF(bounds.Left + 20, titleTop, bounds.Width - 40, 34), centerFormat);
        graphics.DrawString(snapshot.Subtitle, subtitleFont, subtitleBrush, new RectangleF(bounds.Left + 28, subtitleTop, bounds.Width - 56, 34), centerFormat);

        graphics.FillRectangle(Brushes.White, plotRect);
        graphics.DrawRectangle(Pens.LightGray, plotRect);

        int yTickCount = 6;
        double yMax = Math.Max(100.0, snapshot.MaxScalingPercent);
        for (int i = 0; i <= yTickCount; i++)
        {
            double value = yMax * i / yTickCount;
            int y = plotRect.Bottom - (int)Math.Round((value / yMax) * plotRect.Height);
            graphics.DrawLine(gridPen, plotRect.Left, y, plotRect.Right, y);
            graphics.DrawString($"{value:N0}", tickFont, axisBrush, new RectangleF(bounds.Left + 10, y - 12, leftMargin - bounds.Left - 18, 24), rightFormat);
        }

        int xCount = snapshot.ThreadTicks.Count;
        if (xCount == 1)
        {
            int x = plotRect.Left + plotRect.Width / 2;
            graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
            graphics.DrawString(snapshot.ThreadTicks[0].ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
        }
        else
        {
            for (int i = 0; i < xCount; i++)
            {
                int tick = snapshot.ThreadTicks[i];
                float ratio = xCount <= 1 ? 0.5F : (float)i / (xCount - 1);
                int x = plotRect.Left + (int)Math.Round(ratio * plotRect.Width);
                graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
                graphics.DrawString(tick.ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
            }
        }

        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Bottom, plotRect.Right, plotRect.Bottom);
        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Top, plotRect.Left, plotRect.Bottom);
        graphics.DrawString("Threads", axisFont, axisBrush, new RectangleF(plotRect.Left, plotRect.Bottom + 40, plotRect.Width, 22), centerFormat);

        graphics.TranslateTransform(bounds.Left + 24, plotRect.Top + (plotRect.Height / 2));
        graphics.RotateTransform(-90F);
        graphics.DrawString("Scaling vs 1-thread baseline (%)", axisFont, axisBrush, new RectangleF(-plotRect.Height / 2, -18, plotRect.Height, 22), centerFormat);
        graphics.ResetTransform();

        var threadIndex = snapshot.ThreadTicks
            .Select((value, index) => (value, index))
            .ToDictionary(x => x.value, x => x.index);

        for (int seriesIndex = 0; seriesIndex < snapshot.Series.Count; seriesIndex++)
        {
            var series = snapshot.Series[seriesIndex];
            Color color = GetSeriesColor(series.ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);

            PointF? previous = null;
            foreach (var point in series.Points.OrderBy(x => x.Threads))
            {
                if (!threadIndex.TryGetValue(point.Threads, out int index))
                    continue;

                float xRatio = xCount <= 1 ? 0.5F : (float)index / (xCount - 1);
                float x = plotRect.Left + (xRatio * plotRect.Width);
                float y = plotRect.Bottom - (float)((point.ScalingPercent / yMax) * plotRect.Height);
                var current = new PointF(x, y);

                if (previous.HasValue)
                    graphics.DrawLine(linePen, previous.Value, current);

                graphics.FillEllipse(pointBrush, x - 5, y - 5, 10, 10);
                previous = current;
            }
        }

        DrawLegend(graphics, legendRect, snapshot.Series, legendFont);
        DrawInsightPanel(graphics, insightRect, snapshot, legendFont);
    }

    private static void DrawLegend(Graphics graphics, Rectangle legendRect, IReadOnlyList<ScalingGraphSeries> series, Font legendFont)
    {
        if (series.Count == 0)
            return;

        using var backgroundBrush = new SolidBrush(Color.FromArgb(246, 246, 246));
        using var borderPen = new Pen(Color.FromArgb(190, 190, 190), 1F);
        using var textBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));

        graphics.FillRectangle(backgroundBrush, legendRect);
        graphics.DrawRectangle(borderPen, legendRect);
        using var legendTitleFont = new Font(legendFont, FontStyle.Bold);
        graphics.DrawString(series.Count == 1 ? "Selected benchmark" : "Benchmarks shown", legendTitleFont, titleBrush, legendRect.Left + 12, legendRect.Top + 12);

        int y = legendRect.Top + 42;
        for (int i = 0; i < series.Count; i++)
        {
            Color color = GetSeriesColor(series[i].ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);
            graphics.DrawLine(linePen, legendRect.Left + 14, y + 7, legendRect.Left + 42, y + 7);
            graphics.FillEllipse(pointBrush, legendRect.Left + 24, y + 2, 10, 10);
            graphics.DrawString(series[i].Name, legendFont, textBrush, new RectangleF(legendRect.Left + 50, y - 2, legendRect.Width - 60, 20));
            y += 28;
            if (y > legendRect.Bottom - 26)
                break;
        }
    }

    private static void DrawInsightPanel(Graphics graphics, Rectangle insightRect, ScalingGraphSnapshot snapshot, Font legendFont)
    {
        if (insightRect.Width < 160 || insightRect.Height < 90)
            return;

        using var backgroundBrush = new SolidBrush(Color.FromArgb(252, 252, 252));
        using var borderPen = new Pen(Color.FromArgb(190, 190, 190), 1F);
        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
        using var bodyBrush = new SolidBrush(Color.FromArgb(60, 60, 60));
        using var sectionBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        using var sectionFont = new Font("Segoe UI", 8.75F, FontStyle.Bold, GraphicsUnit.Point);
        using var bodyFont = new Font("Segoe UI", 8.75F, FontStyle.Regular, GraphicsUnit.Point);
        using var nameFont = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point);
        using var statusFont = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point);

        graphics.FillRectangle(backgroundBrush, insightRect);
        graphics.DrawRectangle(borderPen, insightRect);

        float x = insightRect.Left + 12F;
        float y = insightRect.Top + 12F;
        float width = insightRect.Width - 24F;
        float bottom = insightRect.Bottom - 12F;

        graphics.DrawString("Focused analysis", titleFont, titleBrush, new RectangleF(x, y, width, 18F));
        y += 24F;

        if (snapshot.Series.Count != 1)
        {
            string text = $"Show just one benchmark line and this box will explain that test in plain language, tell you what the shape usually should look like, and comment on the current run. Right now {snapshot.Series.Count} lines are visible.";
            DrawWrappedText(graphics, text, bodyFont, bodyBrush, new RectangleF(x, y, width, bottom - y));
            return;
        }

        var series = snapshot.Series[0];
        var insight = BuildInsight(series);
        Color seriesColor = GetSeriesColor(series.ColorIndex);

        SizeF pillSize = graphics.MeasureString(insight.StatusTitle, statusFont);
        var pillRect = new RectangleF(x, y, Math.Min(width, pillSize.Width + 18F), 22F);
        using (var pillBrush = new SolidBrush(insight.StatusColor))
        using (var pillTextBrush = new SolidBrush(Color.White))
        {
            graphics.FillRectangle(pillBrush, pillRect);
            graphics.DrawString(insight.StatusTitle, statusFont, pillTextBrush, new RectangleF(pillRect.Left + 9F, pillRect.Top + 3F, pillRect.Width - 10F, 16F));
        }

        y += 30F;
        using (var seriesBrush = new SolidBrush(seriesColor))
            graphics.DrawString(series.Name, nameFont, seriesBrush, new RectangleF(x, y, width, 22F));
        y += 24F;

        y += DrawSection(graphics, x, y, width, bottom - y, "Headline:", insight.Headline, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        y += DrawSection(graphics, x, y, width, bottom - y, "Math / kernel:", insight.TechnicalKernel, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        y += DrawSection(graphics, x, y, width, bottom - y, "Current run:", insight.CurrentResult, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        DrawSection(graphics, x, y, width, bottom - y, "PC read:", insight.PcTakeaway, sectionFont, bodyFont, sectionBrush, bodyBrush);
    }

    private static ScalingInsight BuildInsight(ScalingGraphSeries series)
    {
        var points = series.Points
            .OrderBy(x => x.Threads)
            .ToArray();

        if (points.Length == 0)
        {
            return new ScalingInsight(
                "No data",
                Color.FromArgb(71, 85, 105),
                "This series does not have enough plotted data to analyze yet.",
                "Run the benchmark again so the graph has at least one valid scaling point.",
                "A useful scaling line needs a baseline and at least one measured thread count.",
                "For this benchmark there is not enough information yet to describe a healthy curve shape.",
                "There is not enough measured data yet to say what this current run implies about the PC.",
                "Gather at least a 1-thread point plus one higher thread count so the focused analysis can describe the scaling shape.",
                "Once there are more points, compare this benchmark against its closest partner test to see whether the same behavior repeats.");
        }

        var guide = GetBenchmarkGuide(series.Name);
        var analysis = AnalyzeCurve(points);
        var status = EvaluateStatus(guide, analysis);

        string headline = BuildHeadline(guide, analysis, status.StatusTitle);
        string currentResult = BuildCurrentResult(guide, analysis);
        string pcTakeaway = BuildPcTakeaway(guide, analysis);
        string suggestedNextStep = BuildSuggestedNextStep(guide, analysis);

        return new ScalingInsight(
            status.StatusTitle,
            status.StatusColor,
            headline,
            guide.TechnicalKernel,
            guide.WhatItTests,
            guide.WhatToExpect,
            currentResult,
            pcTakeaway,
            suggestedNextStep);
    }

    private static CurveAnalysis AnalyzeCurve(ScalingGraphPoint[] points)
    {
        var peak = points
            .OrderByDescending(x => x.ScalingPercent)
            .ThenBy(x => x.Threads)
            .First();

        var last = points[^1];
        var first = points[0];
        CurveSegment? bestSegment = null;
        CurveSegment? weakestSegment = null;
        bool monotonicRise = true;
        bool anyDropAfterPeak = false;

        for (int i = 1; i < points.Length; i++)
        {
            var previous = points[i - 1];
            var current = points[i];
            double deltaScaling = current.ScalingPercent - previous.ScalingPercent;
            int threadDelta = Math.Max(1, current.Threads - previous.Threads);
            double idealDelta = threadDelta * 100.0;
            double segmentEfficiencyPercent = idealDelta > 0.0 ? (deltaScaling / idealDelta) * 100.0 : 100.0;
            var segment = new CurveSegment(previous.Threads, current.Threads, deltaScaling, segmentEfficiencyPercent);

            if (!bestSegment.HasValue || segment.SegmentEfficiencyPercent > bestSegment.Value.SegmentEfficiencyPercent)
                bestSegment = segment;

            if (!weakestSegment.HasValue || segment.SegmentEfficiencyPercent < weakestSegment.Value.SegmentEfficiencyPercent)
                weakestSegment = segment;

            if (deltaScaling < 0.0)
                monotonicRise = false;

            if (previous.Threads >= peak.Threads && deltaScaling < 0.0)
                anyDropAfterPeak = true;
        }

        double retention = peak.ScalingPercent > 0.0 ? last.ScalingPercent / peak.ScalingPercent : 1.0;
        double retentionPercent = retention * 100.0;
        double fullThreadMultiplier = last.ScalingPercent / 100.0;
        double peakMultiplier = peak.ScalingPercent / 100.0;
        double idealLinearPercent = last.Threads * 100.0;
        double linearEfficiencyPercent = idealLinearPercent > 0.0 ? (last.ScalingPercent / idealLinearPercent) * 100.0 : 100.0;
        int? firstNinetyPercentPeakThreads = points.FirstOrDefault(x => x.ScalingPercent >= peak.ScalingPercent * 0.90).Threads;
        if (firstNinetyPercentPeakThreads == 0)
            firstNinetyPercentPeakThreads = null;

        int? firstNinetyFivePercentPeakThreads = points.FirstOrDefault(x => x.ScalingPercent >= peak.ScalingPercent * 0.95).Threads;
        if (firstNinetyFivePercentPeakThreads == 0)
            firstNinetyFivePercentPeakThreads = null;

        int sweetSpotThreads = firstNinetyFivePercentPeakThreads ?? peak.Threads;
        double dropFromPeakPercent = Math.Max(0.0, 100.0 - retentionPercent);
        bool peakAtEnd = peak.Threads == last.Threads;
        bool peakEarly = peak.Threads <= Math.Max(2, last.Threads / 3);
        bool plateauNearEnd = !peakAtEnd && retentionPercent >= 95.0;
        double lateSegmentEfficiencyPercent = bestSegment.HasValue && weakestSegment.HasValue && points.Length > 1
            ? (points[^1].ScalingPercent - points[^2].ScalingPercent) / (Math.Max(1, points[^1].Threads - points[^2].Threads) * 100.0) * 100.0
            : linearEfficiencyPercent;

        return new CurveAnalysis(
            first,
            peak,
            last,
            retention,
            retentionPercent,
            fullThreadMultiplier,
            peakMultiplier,
            idealLinearPercent,
            linearEfficiencyPercent,
            firstNinetyPercentPeakThreads,
            firstNinetyFivePercentPeakThreads,
            sweetSpotThreads,
            bestSegment,
            weakestSegment,
            monotonicRise,
            anyDropAfterPeak,
            peakAtEnd,
            peakEarly,
            plateauNearEnd,
            dropFromPeakPercent,
            lateSegmentEfficiencyPercent);
    }

    private static BenchmarkGuide GetBenchmarkGuide(string benchmarkName)
    {
        BenchmarkDefinitions.TryGetValue(benchmarkName, out var definition);
        string detailedHelp = definition?.DetailedHelp ?? "This benchmark focuses on one specific CPU behavior and how well it scales as more workers join the run.";
        string notes = definition?.Notes ?? "Use this result as one lens on the machine rather than the whole story.";

        return benchmarkName switch
        {
            "Integer Mix" => new BenchmarkGuide(
                BenchmarkInsightFamily.IntegerBranch,
                "Hot 64-bit register-state churn with xor-shift style mutations, shifts, xor feedback, adds, multiplies, and almost no main-memory traffic. This is very close to classic scalar ALU work where each worker keeps most of its state in registers.",
                detailedHelp + " " + notes,
                "A strong Integer Mix curve usually keeps climbing almost the whole way because the test is light on memory traffic and heavy on per-core scalar execution. On a healthy big CPU, the line should mainly show where shared front-end, turbo, or thread-placement limits begin to matter.",
                "When this benchmark is strong, the PC is showing healthy scalar throughput for general-purpose logic, simulation bookkeeping, parsers, scripting engines, and other branch-light integer work.",
                "When this benchmark peaks early or gives back a lot, it often points to weaker full-machine scaling, thread-placement friction, frequency droop, or some other shared-resource wall in general scalar work.",
                "Compare this with Bit Twister and Branch Chaos. If all three are strong, the machine is broadly good at scalar/control work. If Integer Mix is strong but Branch Chaos is weaker, the hardware likes straight-line work more than unpredictable control flow."),

            "Bit Twister" => new BenchmarkGuide(
                BenchmarkInsightFamily.IntegerBranch,
                "A local-state bit-manipulation kernel built around rotates, xor mixing, shifts, multiply-based scrambling, and popcount-friendly churn. It rewards integer execution width, bit-manipulation instructions, and efficient scalar retirement.",
                detailedHelp + " " + notes,
                "A strong Bit Twister line should resemble a healthy integer-scaling test: good growth through the sweep with only moderate flattening late. Because the kernel stays branch-light, it usually scales better than chaotic control-flow tests.",
                "A strong result here usually means the PC is comfortable with hashing-style transforms, compression-like bit handling, checksumming, and other bit-heavy scalar kernels.",
                "If this one lags behind Integer Mix, the machine may be less impressive in rotate-heavy or bit-manipulation-heavy scalar work than in simpler ALU arithmetic.",
                "Compare this with Integer Mix. If Bit Twister trails badly, simple ALU work may be stronger than complex bit-state churn on this PC."),

            "Floating Point Mix" => new BenchmarkGuide(
                BenchmarkInsightFamily.ScalarFloating,
                "Dependent scalar double-precision recurrences over a few live variables. Because later operations depend on earlier ones, this test exposes scalar floating-point latency and instruction-level scheduling more than raw vector width.",
                detailedHelp + " " + notes,
                "A strong scalar floating-point curve should keep climbing, but not always as aggressively as wide-vector tests. The interesting part is whether the machine can scale scalar FP cleanly without needing SIMD to look good.",
                "A strong result here suggests the PC has solid scalar FP pipelines for engineering code, older numeric software, emulators, and workloads that do not vectorize especially well.",
                "If this line is much flatter than your vector tests, the system may be relying heavily on SIMD width for its best math scores rather than being equally strong in scalar floating-point work.",
                "Compare this with Floating Point Mix (Peak), SIMD Vector Math, and Matrix Multiply to see whether the machine's math strength is mostly scalar, portable SIMD, or dense-vector oriented."),

            "Floating Point Mix (Peak)" => new BenchmarkGuide(
                BenchmarkInsightFamily.ScalarFloating,
                "A peak-oriented scalar double-precision kernel with several independent live states in flight at once. It is still scalar math, but it exposes more instruction-level parallelism than the validated scalar FP path.",
                detailedHelp + " " + notes,
                "A strong peak-scalar FP graph should scale a little more aggressively than the validated scalar FP variant. Ideally it stays clearly ahead of the base scalar FP test without collapsing late in the sweep.",
                "When this benchmark is strong, the PC is extracting more parallel scalar math from each core even without leaning on AVX-family width. That is a good sign for latency-tolerant scalar numeric code.",
                "If this one does not separate much from the base scalar FP test, the machine may not be gaining as much from extra scalar instruction-level parallelism as expected.",
                "Compare this directly with Floating Point Mix. A large gap usually means the CPU can keep more independent scalar FP work in flight."),

            "Branch Chaos" => new BenchmarkGuide(
                BenchmarkInsightFamily.BranchChaos,
                "Irregular branch-heavy integer logic over a changing local array. This kernel intentionally frustrates branch prediction and makes the front end recover from many control-flow changes.",
                detailedHelp + " " + notes,
                "A healthy Branch Chaos graph rarely looks as clean as Integer Mix. Some flattening is normal, but a strong machine still keeps adding work at higher thread counts instead of falling apart as the front end gets stressed.",
                "A strong result suggests good branch prediction, front-end recovery, and control-flow handling for irregular server logic, rule engines, interpreters, and decision-heavy code.",
                "A weak or collapsing result here can mean the PC handles straight-line arithmetic well but struggles more when every worker is constantly taking unpredictable control paths.",
                "Compare this with Prime Scan and Integer Mix. If Branch Chaos is the outlier, the machine is better at predictable math than at messy control flow."),

            "Cache Walker" => new BenchmarkGuide(
                BenchmarkInsightFamily.CachePressure,
                "Pointer-chasing style memory traversal over a larger working set with poor locality. Instead of streaming cleanly, the kernel keeps forcing the cache hierarchy and memory latency path to do real work.",
                detailedHelp + " " + notes,
                "A strong Cache Walker line usually rises early and then becomes uneven once shared caches, memory latency, and cross-core contention start to dominate. Perfectly smooth scaling is not expected here.",
                "When Cache Walker is strong, the PC is handling irregular data structures, cache-miss-heavy code, graph workloads, and pointer-rich server logic more gracefully than average.",
                "If this benchmark falls off hard, the machine may still be great at friendly streaming work but less comfortable with latency-bound or poor-locality workloads.",
                "Compare this with Memory Stream and Memory Stream (Sustained). A big gap between those tests usually means bandwidth is strong but irregular-access latency is the weaker side of the memory subsystem."),

            "SIMD Vector Math" => new BenchmarkGuide(
                BenchmarkInsightFamily.PortableVector,
                "Portable single-precision vector math using System.Numerics.Vector<T>. The runtime chooses the effective width, so this is a very good picture of what many real .NET applications get from portable SIMD rather than hand-written ISA-specific intrinsics.",
                detailedHelp + " " + notes,
                "A strong portable SIMD graph should climb well across the sweep and usually land somewhere below explicit AVX2 or AVX-512 kernels on the same machine. It should still look healthy at scale if the vector path and placement are good.",
                "A strong result here suggests the PC is good at modern managed-code vector workloads, image transforms, DSP-style math, and higher-level numeric code that uses runtime-selected SIMD paths.",
                "If portable SIMD is weak compared with AVX2 or AVX-512, the machine may still be strong in hand-tuned native/vector code while looking less impressive in runtime-portable managed SIMD.",
                "Compare this with AVX2 / FMA Float32 and AVX-512 Wide Float32. That tells you how much extra the machine gains from ISA-specific wide-vector code over portable SIMD."),

            "AVX2 / FMA Float32" => new BenchmarkGuide(
                BenchmarkInsightFamily.VectorCompute,
                "Explicit 256-bit float vectors plus fused multiply-add style math. This is a real wide-vector throughput test, not just a scalar or portable-SIMD approximation, so it exposes how well the CPU sustains AVX2-class math under load.",
                detailedHelp + " " + notes,
                "A strong AVX2/FMA curve should rise cleanly through real-core counts and keep most of its gain at the far right. Some late flattening is normal, but a sharp drop can mean frequency or shared-resource pressure under heavier AVX load.",
                "When this benchmark is strong, the PC is attractive for media transforms, physics kernels, vectorized math, and many workstation or HPC workloads that fit 256-bit SIMD well.",
                "If this one peaks early or drops hard, the machine may be running into AVX-related frequency reduction, thermal pressure, placement overhead, or other full-load vector limits.",
                "Compare this with SIMD Vector Math and AVX2 / FMA Float32 (Peak). That shows both the ISA gain over portable SIMD and the gap between validated versus peak-chasing 256-bit math."),

            "AVX2 / FMA Float32 (Peak)" => new BenchmarkGuide(
                BenchmarkInsightFamily.VectorCompute,
                "A denser peak-oriented 256-bit AVX2/FMA kernel with lighter stabilization. It is meant to show more of the machine's best-case 256-bit float throughput than the validated AVX2 run.",
                detailedHelp + " " + notes,
                "A strong AVX2 peak graph should sit above the validated AVX2 curve while keeping broadly similar scaling shape. A very large late collapse usually means the extra density is exposing real whole-machine limits.",
                "When this benchmark is strong, the PC has convincing headroom for best-case AVX2-class throughput and not just conservative validated vector performance.",
                "If the peak variant barely beats the validated version, the machine may not have much extra 256-bit vector headroom once the hot loop gets denser.",
                "Compare this directly with the validated AVX2 / FMA Float32 result to judge whether the machine has additional peak AVX2 headroom or is already near its real ceiling."),

            "AVX-512 Wide Float32" => new BenchmarkGuide(
                BenchmarkInsightFamily.WideVector,
                "Very wide 512-bit float vectors with explicit wide-lane math. This is where AVX-512 capable systems show whether their wide-vector feature set translates into real throughput once power, cooling, and frequency behavior are involved.",
                detailedHelp + " " + notes,
                "A strong AVX-512 graph should clearly justify the wider lanes without collapsing badly late in the sweep. Wide-vector tests can trigger more aggressive frequency management, so scaling shape matters as much as the raw peak value.",
                "A strong result means the PC is not only AVX-512 capable on paper, but is also sustaining wide-vector work well enough to matter for serious numerical or media-style kernels.",
                "If this curve rises fast and then fades hard, the CPU may technically support AVX-512 while giving back part of the theoretical gain through downclocking, power limits, or heavy all-core pressure.",
                "Compare this with AVX2 / FMA Float32 and Matrix Multiply. That tells you whether 512-bit width is delivering practical benefit or mostly a bursty headline number."),

            "AVX-512 Wide Float32 (Peak)" => new BenchmarkGuide(
                BenchmarkInsightFamily.WideVector,
                "A peak-oriented 512-bit float kernel tuned to show more of the machine's best-case AVX-512 throughput. It pushes wide vectors harder and trims some stabilization overhead compared with the validated wide-vector path.",
                detailedHelp + " " + notes,
                "A strong AVX-512 peak curve should land above the validated AVX-512 result but still retain most of its gain at the higher thread counts. If it falls apart late, the wider hotter loop is exposing a real system limit.",
                "When this benchmark is strong, the PC has genuine best-case AVX-512 headroom and not just minimal correctness support for wide vectors.",
                "If the peak result is only slightly above the validated AVX-512 test, the machine may already be close to its practical wide-vector ceiling under sustained load.",
                "Compare this directly with AVX-512 Wide Float32. The gap tells you how much extra best-case AVX-512 throughput the machine can actually unlock."),

            "AES Blocks" => new BenchmarkGuide(
                BenchmarkInsightFamily.Crypto,
                "Repeated 128-bit AES round-style block transforms using hardware crypto instructions. This is much more about the CPU's dedicated encryption path than about generic arithmetic or memory bandwidth.",
                detailedHelp + " " + notes,
                "A strong AES graph usually scales well unless frequency, instruction throughput, or feeding many workers becomes the limiter. It should not behave exactly like a memory test because the crypto instructions do much of the heavy lifting.",
                "A strong result here suggests the PC is attractive for encryption-heavy storage, VPN, secure networking, packet handling, and security-oriented throughput work.",
                "If AES scaling is disappointing while other math tests are strong, the bottleneck may be crypto-path specific rather than a general weakness of the whole CPU.",
                "Compare this with Integer Mix and Memory Stream. That helps separate raw compute strength from dedicated crypto-path behavior."),

            "Memory Stream" => new BenchmarkGuide(
                BenchmarkInsightFamily.MemoryBandwidth,
                "Peak-friendly sequential copy plus light line-spaced write pressure over worker-local buffers. This is the clean, friendly streaming side of the memory subsystem rather than an irregular-latency stress test.",
                detailedHelp + " " + notes,
                "A strong Memory Stream graph climbs hard at low thread counts and then gradually flattens as the memory fabric fills up. On big multi-node systems, the most interesting question is where the first bandwidth wall appears and how gracefully the curve behaves beyond it.",
                "When this benchmark is strong, the PC has healthy streaming bandwidth for copy-heavy workloads, data movement, ingest pipelines, and memory-friendly numerical passes.",
                "If this one tops out early, the memory channels, NUMA locality, or memory-clock side of the platform may be the real limit even if compute-heavy tests still look strong.",
                "Compare this with Memory Stream (Sustained) and Cache Walker. That separates best-case bandwidth, continuous rewrite pressure, and irregular-access latency behavior."),

            "Memory Stream (Sustained)" => new BenchmarkGuide(
                BenchmarkInsightFamily.MemoryBandwidth,
                "A sustained read-copy-mutate-checksum streaming pass that swaps source and destination roles every batch. This makes the memory path do repeated real work instead of repeatedly copying one quiet source buffer.",
                detailedHelp + " " + notes,
                "A strong sustained-memory graph usually sits below the peak Memory Stream curve but should still scale sensibly. The goal here is not maximum one-pass glory but how well the platform keeps moving and rewriting memory over time.",
                "A strong result suggests the PC handles continuous memory rewrite pressure well, which is valuable for long-running simulations, transform pipelines, and data-processing jobs that keep touching fresh output.",
                "If this sustained variant sags much more than the peak stream test, the platform may have decent headline bandwidth but weaker behavior once the workload keeps rewriting what it just produced.",
                "Compare this directly with Memory Stream. The gap between the two is a very useful clue about peak-friendly bandwidth versus sustained rewrite behavior."),

            "Matrix Multiply" => new BenchmarkGuide(
                BenchmarkInsightFamily.DenseCompute,
                "Classic dense double-precision matrix multiplication over worker-local matrices. This is a heavy arithmetic-reuse kernel where cores, caches, and vector-friendly math all have a chance to matter together.",
                detailedHelp + " " + notes,
                "A strong matrix-multiply curve usually keeps climbing deeper into the sweep than raw memory tests because each byte of data gets reused in many arithmetic operations. It is one of the best whole-PC math reads in the suite.",
                "When Matrix Multiply is strong, the PC is showing good promise for scientific computing, simulation, creator-side numerical work, and other dense compute jobs where arithmetic reuse matters.",
                "If this one flattens unusually early, something is holding back dense sustained math: cache reuse, vector utilization, thread placement, or all-core frequency behavior are common suspects.",
                "Compare this with SIMD / AVX tests. If Matrix Multiply is strong too, the machine is not just good at synthetic vector bursts but also at sustained dense numerical work."),

            "Prime Scan" => new BenchmarkGuide(
                BenchmarkInsightFamily.PrimeInteger,
                "Trial-division primality checking across rising odd integers. The work per candidate changes over time, so the kernel mixes small integer arithmetic with many unpredictable branch decisions.",
                detailedHelp + " " + notes,
                "A healthy Prime Scan curve usually looks more uneven than straight-line arithmetic. The line should still rise, but it often reveals control-flow and per-thread overhead more clearly than vector-heavy tests do.",
                "When this benchmark is strong, the PC is handling branchy integer work well for math-style search, control-heavy analysis, and workloads where every work item costs a different amount.",
                "If Prime Scan trails far behind Integer Mix, the machine is likely much happier with predictable ALU work than with branch-heavy search or irregular integer logic.",
                "Compare this with Integer Mix and Branch Chaos. That tells you whether the limitation is mathematical branching, general control unpredictability, or scalar throughput overall."),

            "Mandelbrot" => new BenchmarkGuide(
                BenchmarkInsightFamily.MixedCompute,
                "Escape-time fractal evaluation over many independent pixels. Each pixel mixes floating-point iteration with branchy escape checks, so this is a genuinely mixed compute-plus-control kernel rather than a pure math loop.",
                detailedHelp + " " + notes,
                "A strong Mandelbrot curve usually lands between clean vector math and branch-chaotic behavior. It should keep climbing, but the mixed nature of the kernel often reveals balance between floating-point throughput and control efficiency.",
                "A strong result means the PC is handling mixed real-world-style kernels well, especially workloads that have many independent work items but still include branch decisions inside each item.",
                "If Mandelbrot scaling is much worse than both FP and integer tests, the machine may be less balanced when compute and control pressure hit at the same time.",
                "Compare this with Floating Point Mix and Branch Chaos. That shows whether the machine is losing ground mostly on the math side, the control-flow side, or the combination of both."),

            _ => new BenchmarkGuide(
                BenchmarkInsightFamily.MixedCompute,
                definition?.Description ?? "Mixed benchmark behavior.",
                detailedHelp + " " + notes,
                "A healthy graph usually rises through most of the sweep and only flattens once shared resources begin to dominate.",
                "A strong result suggests the PC is handling this class of workload cleanly at larger thread counts.",
                "A weaker result suggests the machine is running into a shared-resource wall before the full thread range finishes.",
                "Compare this benchmark with the most similar test in the suite to see whether the same curve shape repeats or only appears here.")
        };
    }

    private static (string StatusTitle, Color StatusColor) EvaluateStatus(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 90.0)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => ("Excellent bandwidth scale", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.Crypto => ("Excellent AES scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.WideVector => ("Excellent wide-vector scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.PortableVector => ("Excellent vector scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.DenseCompute => ("Excellent dense-compute scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.CachePressure => ("Strong cache-path scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.BranchChaos or BenchmarkInsightFamily.PrimeInteger or BenchmarkInsightFamily.IntegerBranch => ("Excellent scalar scaling", Color.FromArgb(34, 139, 94)),
                _ => ("Excellent mixed scaling", Color.FromArgb(34, 139, 94))
            };
        }

        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 75.0)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => ("Strong memory scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.Crypto => ("Strong crypto scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.WideVector => ("Strong wide-vector scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.PortableVector => ("Strong vector scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.DenseCompute => ("Strong dense-compute scaling", Color.FromArgb(34, 139, 94)),
                BenchmarkInsightFamily.BranchChaos or BenchmarkInsightFamily.PrimeInteger or BenchmarkInsightFamily.IntegerBranch => ("Strong scalar/control scaling", Color.FromArgb(34, 139, 94)),
                _ => ("Strong scaling", Color.FromArgb(34, 139, 94))
            };
        }

        if (analysis.PlateauNearEnd)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => ("Bandwidth plateau", Color.FromArgb(180, 83, 9)),
                BenchmarkInsightFamily.CachePressure => ("Latency plateau", Color.FromArgb(180, 83, 9)),
                BenchmarkInsightFamily.WideVector => ("Wide-vector plateau", Color.FromArgb(180, 83, 9)),
                BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.PortableVector => ("Vector plateau", Color.FromArgb(180, 83, 9)),
                BenchmarkInsightFamily.DenseCompute => ("Dense-compute plateau", Color.FromArgb(180, 83, 9)),
                _ => ("Near-peak plateau", Color.FromArgb(180, 83, 9))
            };
        }

        if (analysis.PeakEarly && analysis.RetentionPercent < 70.0)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => ("Bandwidth wall visible", Color.FromArgb(217, 119, 6)),
                BenchmarkInsightFamily.CachePressure => ("Cache / latency wall visible", Color.FromArgb(217, 119, 6)),
                BenchmarkInsightFamily.WideVector => ("Wide-vector taper", Color.FromArgb(217, 119, 6)),
                BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.PortableVector => ("Vector taper", Color.FromArgb(217, 119, 6)),
                BenchmarkInsightFamily.DenseCompute => ("Dense-compute wall", Color.FromArgb(217, 119, 6)),
                BenchmarkInsightFamily.BranchChaos or BenchmarkInsightFamily.PrimeInteger => ("Control-flow pressure visible", Color.FromArgb(217, 119, 6)),
                _ => ("Early wall visible", Color.FromArgb(217, 119, 6))
            };
        }

        if (analysis.AnyDropAfterPeak && analysis.RetentionPercent < 85.0)
            return ("Worth a closer look", Color.FromArgb(220, 38, 38));

        return ("Partial scaling", Color.FromArgb(202, 138, 4));
    }

    private static string BuildHeadline(BenchmarkGuide guide, CurveAnalysis analysis, string statusTitle)
    {
        string sweetSpotText = analysis.SweetSpotThreads == analysis.Last.Threads
            ? $"full-machine use is still earning its keep through {analysis.Last.Threads} threads"
            : $"the earliest near-peak point shows up around {analysis.SweetSpotThreads} threads";

        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 85.0)
            return $"{statusTitle}: this benchmark keeps rewarding more threads, and {sweetSpotText}.";

        if (analysis.PlateauNearEnd)
            return $"{statusTitle}: the machine reaches most of its best result before the end and then holds onto it well, so {sweetSpotText}.";

        if (analysis.PeakEarly && analysis.RetentionPercent < 70.0)
            return $"{statusTitle}: the curve finds its best point early and then gives back a meaningful chunk, so {sweetSpotText}.";

        if (analysis.AnyDropAfterPeak)
            return $"{statusTitle}: the benchmark scales partway, then softens after its best point, so {sweetSpotText}.";

        return $"{statusTitle}: the line is still usable, but the machine is clearly approaching a scaling wall before the thread sweep is finished.";
    }

    private static string BuildCurrentResult(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        string bestWindow = analysis.BestSegment.HasValue
            ? $"The strongest scaling window was {analysis.BestSegment.Value.FromThreads}→{analysis.BestSegment.Value.ToThreads} threads, adding {analysis.BestSegment.Value.DeltaScalingPercent:N0} percentage points and running at about {analysis.BestSegment.Value.SegmentEfficiencyPercent:N0}% of ideal for that slice."
            : string.Empty;

        string weakestWindow = analysis.WeakestSegment.HasValue
            ? $"The weakest window was {analysis.WeakestSegment.Value.FromThreads}→{analysis.WeakestSegment.Value.ToThreads} threads, where the line changed by {analysis.WeakestSegment.Value.DeltaScalingPercent:N0} percentage points, about {analysis.WeakestSegment.Value.SegmentEfficiencyPercent:N0}% of ideal for that segment."
            : string.Empty;

        string shapeRead = analysis.PeakAtEnd
            ? "The line is still making progress at the far right, so the system has not obviously run out of room for this workload yet."
            : analysis.RetentionPercent >= 95.0
                ? "The line peaks before the end but stays very close to the best point, so the machine is mostly plateauing rather than collapsing."
                : analysis.RetentionPercent >= 80.0
                    ? "The line peaks before the end and gives back a noticeable but not disastrous amount, so the machine is meeting some shared-resource pressure at higher load."
                    : "The line peaks before the end and gives back a large amount, so this workload is clearly running into a stronger full-load limit.";

        string saturationText = analysis.FirstNinetyFivePercentPeakThreads.HasValue
            ? $"The run reaches 95% of peak by {analysis.FirstNinetyFivePercentPeakThreads.Value} threads."
            : analysis.FirstNinetyPercentPeakThreads.HasValue
                ? $"The run reaches 90% of peak by {analysis.FirstNinetyPercentPeakThreads.Value} threads."
                : "The run never reached a clear plateau before the final measured point.";

        return $"Peak scaling was {analysis.Peak.ScalingPercent:N0}% at {analysis.Peak.Threads} threads, which is about {analysis.PeakMultiplier:N2}x the 1-thread baseline. The last point at {analysis.Last.Threads} threads is {analysis.Last.ScalingPercent:N0}%, or about {analysis.FullThreadMultiplier:N2}x baseline. That keeps {analysis.RetentionPercent:N0}% of peak and lands at roughly {analysis.LinearEfficiencyPercent:N0}% of perfect linear scaling for the full sweep. {saturationText} {bestWindow} {weakestWindow} {shapeRead}".Trim();
    }

    private static string BuildPcTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        string familyRead = guide.Family switch
        {
            BenchmarkInsightFamily.MemoryBandwidth => BuildMemoryTakeaway(guide, analysis),
            BenchmarkInsightFamily.CachePressure => BuildCacheTakeaway(guide, analysis),
            BenchmarkInsightFamily.Crypto => BuildCryptoTakeaway(guide, analysis),
            BenchmarkInsightFamily.DenseCompute => BuildDenseComputeTakeaway(guide, analysis),
            BenchmarkInsightFamily.VectorCompute => BuildVectorTakeaway(guide, analysis),
            BenchmarkInsightFamily.WideVector => BuildWideVectorTakeaway(guide, analysis),
            BenchmarkInsightFamily.PortableVector => BuildPortableVectorTakeaway(guide, analysis),
            BenchmarkInsightFamily.ScalarFloating => BuildScalarFloatingTakeaway(guide, analysis),
            BenchmarkInsightFamily.IntegerBranch => BuildIntegerTakeaway(guide, analysis),
            BenchmarkInsightFamily.BranchChaos => BuildBranchTakeaway(guide, analysis),
            BenchmarkInsightFamily.PrimeInteger => BuildPrimeTakeaway(guide, analysis),
            _ => BuildMixedTakeaway(guide, analysis)
        };

        string operatingPoint = BuildOperatingPointTakeaway(guide, analysis);
        string warning = BuildWarningTakeaway(guide, analysis);

        return string.Join(" ", new[] { familyRead, operatingPoint, warning }.Where(static x => !string.IsNullOrWhiteSpace(x)));
    }

    private static string BuildMemoryTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 70.0)
            return $"This PC is still converting extra threads into real streaming bandwidth, which is a strong sign for memory channels, NUMA placement, and fabric behavior on friendly sequential data motion. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"This looks like a classic bandwidth-saturation shape: the machine fills the memory path before the sweep ends, then mostly holds that ceiling instead of collapsing. That usually means the memory subsystem is healthy, but already close to fully occupied. {guide.StrengthMeaning}";

        if (analysis.AnyDropAfterPeak)
            return $"This memory result is telling you the top end is not just saturated but giving some bandwidth back. That is more than a simple plateau and can point to cross-node traffic, placement friction, contention, or thermally reduced all-core behavior during data movement. {guide.ConcernMeaning}";

        return $"This machine has usable memory throughput here, but the graph says the fabric reaches a real wall before the whole sweep becomes clearly dominant. Think of it as decent bandwidth with a visible ceiling rather than unlimited top-end scaling. {guide.WhatToExpect}";
    }

    private static string BuildCacheTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 60.0)
            return $"For an irregular cache-latency test, this is a healthy result. The PC is still finding more useful work at higher thread counts even though pointer chasing and poor locality usually expose shared-cache and DRAM-latency pain quickly. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"This shape says the cache and latency path are holding together reasonably well, but the machine has already reached most of what it can do for irregular access before the full sweep ends. That is not unusual for pointer-heavy workloads.";

        if (analysis.AnyDropAfterPeak)
            return $"This curve is acting like a latency-sensitive machine that starts to trip over shared-cache pressure, miss handling, or NUMA distance once the worker count climbs. For irregular data structures, that usually matters more than raw bandwidth headlines. {guide.ConcernMeaning}";

        return $"The PC looks serviceable for cache-hostile work, but this is not the kind of line that says graph traversal, pointer-rich code, or miss-heavy data structures will love all available threads equally. Expect selective sweet spots rather than a perfect full-machine win.";
    }

    private static string BuildCryptoTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 75.0)
            return $"This PC is scaling its dedicated AES path well, which is exactly what you want for encrypted storage, VPN, packet security, or any workload that can ride the hardware crypto instructions hard. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The crypto path gets close to its ceiling and then stays there, which usually means the AES instruction engine is doing fine and the machine is simply approaching a practical whole-system limit rather than failing badly.";

        if (analysis.AnyDropAfterPeak)
            return $"This says the machine has crypto acceleration, but full-machine AES throughput is running into some top-end limit before the sweep finishes cleanly. That could be power, frequency, feed pressure, or broader contention rather than a total AES weakness. {guide.ConcernMeaning}";

        return $"The crypto story here is mixed: there is useful AES throughput on the table, but the graph does not say this PC turns every extra thread into equally good secure-data performance. It is capable, just not perfectly effortless at the top end.";
    }

    private static string BuildDenseComputeTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 75.0)
            return $"This is a strong dense-math signal. The PC is still cashing in more threads for fused arithmetic and regular numeric kernels, which is what you want for matrix-heavy engineering, rendering, and scientific work. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The dense-compute engine gets near its best score and then holds it, which usually means compute throughput is healthy and the machine is mostly brushing up against a practical all-core ceiling rather than failing.";

        if (analysis.AnyDropAfterPeak)
            return $"Dense arithmetic is exposing a whole-machine limit here. When a regular math kernel fades after peaking, the likely suspects are sustained all-core frequency, thermals, power limits, or vector-resource pressure rather than random software noise. {guide.ConcernMeaning}";

        return $"This PC can do the dense math, but the line suggests there is a meaningful upper boundary to how much whole-machine acceleration it gets once every worker joins the run. It looks competent, not effortless.";
    }

    private static string BuildVectorTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 70.0)
            return $"This PC is getting real value from its AVX2-class vector path all the way to the far right, which is a very good sign for 256-bit float kernels, image transforms, and vector-heavy workstation code. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The machine reaches most of its AVX2 throughput before the end of the sweep and then holds it. That usually means the 256-bit vector engine is healthy, but the box is already near its sustainable all-core AVX operating point.";

        if (analysis.AnyDropAfterPeak)
            return $"This is the kind of line that makes you think about AVX-related frequency management. The CPU can clearly do the vector work, but once the thread count is high enough, the sustained whole-machine AVX2 path is giving some of that gain back. {guide.ConcernMeaning}";

        return $"The AVX2 story here is moderate rather than dramatic. There is real vector benefit, but the machine is not telling you that every extra worker keeps 256-bit math equally profitable all the way up.";
    }

    private static string BuildWideVectorTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 65.0)
            return $"This is a convincing wide-vector result. The PC is not merely advertising AVX-512 support; it is still turning that width into useful whole-machine throughput deep into the sweep. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The system reaches a high AVX-512 operating band and then stays close to it. That usually means the wide-vector hardware is real and useful, but the sustainable all-core point arrives before the maximum thread count.";

        if (analysis.AnyDropAfterPeak)
            return $"Wide vectors are probably where the box starts paying a bigger frequency or power tax. The CPU still has AVX-512 capability, but this line says the practical all-core benefit is narrower than the peak headline would suggest. {guide.ConcernMeaning}";

        return $"This machine has meaningful wide-vector ability, but the graph is not shouting unlimited AVX-512 scaling. It looks like a box where wide lanes help, yet the top-end operating envelope still has to be respected.";
    }

    private static string BuildPortableVectorTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 70.0)
            return $"This is a healthy managed-SIMD result. The PC is turning portable vector code into sustained gains, which is exactly what you want when real .NET applications are using Vector<T> rather than bespoke ISA-specific kernels. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The machine reaches most of its portable-SIMD upside before the very end and then holds steady. That is a good sign for real managed workloads, even if the full-machine gain stops compounding late.";

        if (analysis.AnyDropAfterPeak)
            return $"This suggests the PC has decent portable SIMD throughput, but the runtime-friendly vector path is not scaling cleanly all the way to the top end. That can matter a lot if your actual application code uses generic managed vectors instead of handcrafted AVX kernels. {guide.ConcernMeaning}";

        return $"This portable-SIMD result lands in the middle: the machine has useful vector help for managed code, but the line still shows a noticeable wall before the whole sweep looks unquestionably optimal.";
    }

    private static string BuildScalarFloatingTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 75.0)
            return $"This PC is scaling scalar floating-point work well, which is important because it means the machine is not relying only on wide vectors to look good in numeric code. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The scalar FP path gets close to its best level and then stabilizes, which usually means the cores are fundamentally healthy for classic floating-point work even if the very last threads add less than the early ones.";

        if (analysis.AnyDropAfterPeak)
            return $"Scalar floating-point work is exposing a real full-machine limit here. That matters because scalar numeric code is often the quiet baseline behind emulation, engineering tools, and older compute kernels that do not vectorize perfectly. {guide.ConcernMeaning}";

        return $"The scalar FP picture is respectable but not dominant. This looks like a machine that can do the work, yet still has a measurable top-end scaling wall before all available threads become the obvious answer.";
    }

    private static string BuildIntegerTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 80.0)
            return $"This PC is doing the simple hard thing very well: integer ALU work keeps scaling, so the cores, front end, and thread placement are all cooperating nicely for branch-light scalar throughput. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The machine reaches most of its scalar-integer upside before the end and then holds it well. That usually means the everyday execution core is healthy, even if the final thread counts are no longer giving perfect extra return.";

        if (analysis.AnyDropAfterPeak)
            return $"Because this is a mostly register-resident scalar test, a late fade here is a strong hint that the wall is not ordinary DRAM bandwidth. Think shared front-end pressure, turbo loss, placement friction, or some other general whole-machine scalar limit. {guide.ConcernMeaning}";

        return $"This is decent scalar-integer behavior, but it is not the kind of graph that says the PC can blindly throw every thread at branch-light ALU work and expect the same payoff forever. There is a real upper contour to respect.";
    }

    private static string BuildBranchTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 65.0)
            return $"For a branch-heavy test, this is a strong result. The machine is still turning messy control flow into more useful throughput even as the front end has to keep recovering from mispredict-style disruption. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The branch path gets close to its best level and then levels off. That usually means the predictor and front end are doing a respectable job, but irregular control flow has already extracted most of the benefit before the last step of the sweep.";

        if (analysis.AnyDropAfterPeak)
            return $"This line says the PC is materially less comfortable when the workload stops being neat and predictable. If Branch Chaos or similar tests fade harder than straight integer work, the front end is usually the story, not the ALUs alone. {guide.ConcernMeaning}";

        return $"The machine can handle branch-heavy work, but the curve says irregular decision paths become a real scaling tax before the whole thread range turns into a clean win.";
    }

    private static string BuildPrimeTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 70.0)
            return $"This PC is scaling integer-search style work nicely. That usually means trial division, loop control, and data-dependent decision flow are all staying productive even as more workers join the run. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The prime-search style path gets near its ceiling and then holds on. That is a healthy sign for iterative integer search work where the machine has found a practical operating band before the full sweep finishes.";

        if (analysis.AnyDropAfterPeak)
            return $"This benchmark is telling you that iterative search-style integer work does not love the very top of the thread range on this PC. That can come from branch pressure, integer divide cost, or general coordination overhead once the box is packed.";

        return $"The machine is capable in integer-search style work, but the line says the payoff from extra workers becomes more selective toward the top end. There is a usable sweet spot, just not an unlimited one.";
    }

    private static string BuildMixedTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakAtEnd && analysis.LinearEfficiencyPercent >= 75.0)
            return $"This PC is scaling this workload in a healthy all-round way. The machine is still turning extra workers into more useful throughput instead of obviously hitting a hard wall early. {guide.StrengthMeaning}";

        if (analysis.PlateauNearEnd)
            return $"The machine gets close to its best result before the thread sweep ends and then holds that level fairly well. That usually means the box is fundamentally healthy for this workload even if the absolute best point arrives before the maximum thread count.";

        if (analysis.AnyDropAfterPeak)
            return $"This run shows a real top-end tradeoff. The workload can go fast on this PC, but the highest thread counts are now paying visible overhead or shared-resource pressure. {guide.ConcernMeaning}";

        return $"This result is usable, but it also says the machine has a noticeable scaling wall for this workload before the full thread range becomes an automatic win.";
    }

    private static string BuildOperatingPointTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        string sweetSpotLead = guide.Family switch
        {
            BenchmarkInsightFamily.MemoryBandwidth => "For memory-friendly work",
            BenchmarkInsightFamily.CachePressure => "For cache-hostile work",
            BenchmarkInsightFamily.Crypto => "For encryption-heavy throughput",
            BenchmarkInsightFamily.DenseCompute => "For dense math",
            BenchmarkInsightFamily.VectorCompute => "For 256-bit vector work",
            BenchmarkInsightFamily.WideVector => "For 512-bit wide-vector work",
            BenchmarkInsightFamily.PortableVector => "For managed portable SIMD",
            BenchmarkInsightFamily.ScalarFloating => "For scalar floating-point work",
            BenchmarkInsightFamily.IntegerBranch => "For scalar integer work",
            BenchmarkInsightFamily.BranchChaos => "For branch-heavy logic",
            BenchmarkInsightFamily.PrimeInteger => "For search-style integer work",
            _ => "For this workload class"
        };

        return analysis.SweetSpotThreads == analysis.Last.Threads
            ? $"{sweetSpotLead}, the practical operating point is still the full tested range up to {analysis.Last.Threads} threads because the line remains near or at its best there."
            : $"{sweetSpotLead}, the earliest practical sweet spot is about {analysis.SweetSpotThreads} threads because that is the first point within 95% of peak. The absolute top score is still at {analysis.Peak.Threads} threads, so you can choose between earlier efficiency and maximum score.";
    }

    private static string BuildWarningTakeaway(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        if (analysis.PeakEarly && analysis.RetentionPercent < 70.0)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => "Because the drop happens early, it is worth checking memory placement, NUMA locality, and whether the workload is spilling across nodes inefficiently.",
                BenchmarkInsightFamily.CachePressure => "Because the drop happens early, inspect locality, data placement, and whether the working set is crossing cache and NUMA boundaries in a costly way.",
                BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.WideVector => "Because the drop happens early, inspect thermals, package power behavior, and AVX operating frequency under sustained full-machine load.",
                _ => "Because the drop happens relatively early, inspect placement mode, NUMA behavior, thermals, and thread-count caps before assuming the full machine is always best for this test."
            };
        }

        if (analysis.LateSegmentEfficiencyPercent < 25.0 && !analysis.PeakAtEnd)
        {
            return guide.Family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth => "The last segment adds very little, so the memory path is already close to saturated at the top end.",
                BenchmarkInsightFamily.CachePressure => "The last segment adds very little, so more workers are mostly adding latency pressure instead of useful cache-hostile throughput now.",
                BenchmarkInsightFamily.VectorCompute => "The last segment adds very little, so the sustained AVX2 operating point is already close to tapped out at the top end.",
                BenchmarkInsightFamily.WideVector => "The last segment adds very little, so the sustainable AVX-512 operating envelope is already close to fully used.",
                _ => "The last segment adds very little compared with ideal, so the machine is close to tapped out for this workload at the top end."
            };
        }

        return string.Empty;
    }

    private static string BuildSuggestedNextStep(BenchmarkGuide guide, CurveAnalysis analysis)
    {
        string threadAdvice = analysis.PeakAtEnd
            ? $"This curve still justifies testing the full machine, so keep {analysis.Last.Threads}-thread runs in play for this workload class."
            : $"Try a repeat run centered around {analysis.SweetSpotThreads} threads versus {analysis.Last.Threads} threads to see whether the same sweet spot repeats.";

        return guide.CompareAgainst + " " + threadAdvice;
    }

    private enum BenchmarkInsightFamily
    {
        MemoryBandwidth,
        CachePressure,
        Crypto,
        DenseCompute,
        VectorCompute,
        WideVector,
        PortableVector,
        ScalarFloating,
        IntegerBranch,
        BranchChaos,
        PrimeInteger,
        MixedCompute
    }

    private readonly record struct CurveSegment(int FromThreads, int ToThreads, double DeltaScalingPercent, double SegmentEfficiencyPercent);

    private sealed record CurveAnalysis(
        ScalingGraphPoint First,
        ScalingGraphPoint Peak,
        ScalingGraphPoint Last,
        double Retention,
        double RetentionPercent,
        double FullThreadMultiplier,
        double PeakMultiplier,
        double IdealLinearPercent,
        double LinearEfficiencyPercent,
        int? FirstNinetyPercentPeakThreads,
        int? FirstNinetyFivePercentPeakThreads,
        int SweetSpotThreads,
        CurveSegment? BestSegment,
        CurveSegment? WeakestSegment,
        bool MonotonicRise,
        bool AnyDropAfterPeak,
        bool PeakAtEnd,
        bool PeakEarly,
        bool PlateauNearEnd,
        double DropFromPeakPercent,
        double LateSegmentEfficiencyPercent);

    private sealed record BenchmarkGuide(
        BenchmarkInsightFamily Family,
        string TechnicalKernel,
        string WhatItTests,
        string WhatToExpect,
        string StrengthMeaning,
        string ConcernMeaning,
        string CompareAgainst);

    private sealed record ScalingInsight(
        string StatusTitle,
        Color StatusColor,
        string Headline,
        string TechnicalKernel,
        string WhatItTests,
        string WhatToExpect,
        string CurrentResult,
        string PcTakeaway,
        string SuggestedNextStep);

    private static float DrawSection(Graphics graphics, float x, float y, float width, float availableHeight, string heading, string body, Font headingFont, Font bodyFont, Brush headingBrush, Brush bodyBrush)
    {
        if (availableHeight <= 0F)
            return 0F;

        float used = 0F;
        using var headingFormat = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Near, Trimming = StringTrimming.Word };
        var headingRect = new RectangleF(x, y, width, Math.Min(availableHeight, 18F));
        graphics.DrawString(heading, headingFont, headingBrush, headingRect, headingFormat);
        used += 18F;
        used += 4F;

        float bodyHeight = DrawWrappedText(graphics, body, bodyFont, bodyBrush, new RectangleF(x, y + used, width, Math.Max(0F, availableHeight - used)));
        used += bodyHeight;
        return used;
    }

    private static float DrawWrappedText(Graphics graphics, string text, Font font, Brush brush, RectangleF rect)
    {
        if (string.IsNullOrWhiteSpace(text) || rect.Width <= 0F || rect.Height <= 0F)
            return 0F;

        using var format = new StringFormat
        {
            Alignment = StringAlignment.Near,
            LineAlignment = StringAlignment.Near,
            Trimming = StringTrimming.Word
        };

        SizeF measured = graphics.MeasureString(text, font, new SizeF(rect.Width, rect.Height), format);
        float height = Math.Min(rect.Height, measured.Height + 2F);
        graphics.DrawString(text, font, brush, new RectangleF(rect.Left, rect.Top, rect.Width, height), format);
        return height;
    }

}

internal sealed class DoubleBufferedPanel : Panel
{
    public DoubleBufferedPanel()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
    }
}

public sealed class ScalingGraphForm : Form
{
    private readonly ScalingGraphSnapshot _snapshot;
    private readonly DoubleBufferedPanel _graphPanel = new();
    private readonly FlowLayoutPanel _seriesButtonHost = new();
    private readonly Dictionary<string, Button> _seriesButtons = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _visibleSeries = new(StringComparer.OrdinalIgnoreCase);
    private readonly Label _selectionLabel = new();
    private readonly Panel _focusedAnalysisOverlay = new();
    private readonly Label _focusedAnalysisTitleLabel = new();
    private readonly RichTextBox _focusedAnalysisTextBox = new();

    public ScalingGraphForm(ScalingGraphSnapshot snapshot)
    {
        _snapshot = snapshot;
        foreach (var series in snapshot.Series)
            _visibleSeries.Add(series.Name);

        Text = "Thread Scaling Graph";
        AppVisuals.TryApplyWindowIcon(this);
        StartPosition = FormStartPosition.CenterParent;
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1000, 700);
        BackColor = Color.White;
        KeyPreview = true;
        KeyDown += ScalingGraphForm_KeyDown;

        var headerHost = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.FromArgb(35, 41, 59),
            Padding = new Padding(14, 10, 14, 10),
            Margin = new Padding(0)
        };
        headerHost.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var topBar = new Panel
        {
            Dock = DockStyle.Top,
            Height = 36,
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };
        headerHost.Controls.Add(topBar, 0, 0);

        var closeButton = new Button
        {
            Text = "Close",
            Dock = DockStyle.Right,
            Width = 110,
            Height = 34,
            BackColor = Color.FromArgb(229, 77, 66),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0)
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (_, _) => Close();
        topBar.Controls.Add(closeButton);

        var hintLabel = new Label
        {
            Dock = DockStyle.Fill,
            Text = "Fullscreen scaling graph preview. Click a benchmark button to hide or show that line. When only one line is visible, the right side explains that test and your current result. Press Esc or use Close.",
            ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleLeft,
            AutoEllipsis = true
        };
        topBar.Controls.Add(hintLabel);

        var controlsHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 10, 0, 0),
            Padding = new Padding(0)
        };
        headerHost.Controls.Add(controlsHost, 0, 1);

        var showAllButton = CreateCommandButton("Show All", Color.FromArgb(37, 99, 235));
        showAllButton.Click += (_, _) => SetAllSeriesVisibility(true);
        controlsHost.Controls.Add(showAllButton);

        var hideAllButton = CreateCommandButton("Hide All", Color.FromArgb(71, 85, 105));
        hideAllButton.Click += (_, _) => SetAllSeriesVisibility(false);
        controlsHost.Controls.Add(hideAllButton);

        _selectionLabel.AutoSize = true;
        _selectionLabel.ForeColor = Color.White;
        _selectionLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
        _selectionLabel.Margin = new Padding(6, 9, 12, 0);
        controlsHost.Controls.Add(_selectionLabel);

        _seriesButtonHost.AutoSize = true;
        _seriesButtonHost.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        _seriesButtonHost.WrapContents = true;
        _seriesButtonHost.FlowDirection = FlowDirection.LeftToRight;
        _seriesButtonHost.BackColor = Color.Transparent;
        _seriesButtonHost.Margin = new Padding(0);
        _seriesButtonHost.Padding = new Padding(0);
        controlsHost.Controls.Add(_seriesButtonHost);

        BuildSeriesButtons();
        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();

        _graphPanel.Dock = DockStyle.Fill;
        _graphPanel.Paint += (_, e) => DrawGraphPanel(e.Graphics);
        _graphPanel.Resize += (_, _) => UpdateFocusedAnalysisOverlay();
        BuildFocusedAnalysisOverlay();
        Controls.Add(_graphPanel);
        Controls.Add(headerHost);
        UpdateFocusedAnalysisOverlay();
    }

    private static Button CreateCommandButton(string text, Color backColor)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Height = 34,
            Padding = new Padding(12, 4, 12, 4),
            FlatStyle = FlatStyle.Flat,
            BackColor = backColor,
            ForeColor = Color.White,
            Margin = new Padding(0, 0, 8, 8)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void BuildFocusedAnalysisOverlay()
    {
        _focusedAnalysisOverlay.Visible = false;
        _focusedAnalysisOverlay.BackColor = Color.FromArgb(252, 252, 252);
        _focusedAnalysisOverlay.BorderStyle = BorderStyle.FixedSingle;
        _focusedAnalysisOverlay.Padding = new Padding(12);
        _focusedAnalysisOverlay.Anchor = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Bottom;

        _focusedAnalysisTitleLabel.Dock = DockStyle.Top;
        _focusedAnalysisTitleLabel.Height = 20;
        _focusedAnalysisTitleLabel.Text = "Focused analysis";
        _focusedAnalysisTitleLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        _focusedAnalysisTitleLabel.ForeColor = Color.FromArgb(35, 35, 35);

        _focusedAnalysisTextBox.Dock = DockStyle.Fill;
        _focusedAnalysisTextBox.ReadOnly = true;
        _focusedAnalysisTextBox.ScrollBars = RichTextBoxScrollBars.Vertical;
        _focusedAnalysisTextBox.BorderStyle = BorderStyle.None;
        _focusedAnalysisTextBox.BackColor = Color.FromArgb(252, 252, 252);
        _focusedAnalysisTextBox.ForeColor = Color.FromArgb(45, 45, 45);
        _focusedAnalysisTextBox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        _focusedAnalysisTextBox.WordWrap = true;
        _focusedAnalysisTextBox.ShortcutsEnabled = true;
        _focusedAnalysisTextBox.TabStop = false;
        _focusedAnalysisTextBox.DetectUrls = false;
        _focusedAnalysisTextBox.HideSelection = false;

        _focusedAnalysisOverlay.Controls.Add(_focusedAnalysisTextBox);
        _focusedAnalysisOverlay.Controls.Add(_focusedAnalysisTitleLabel);
        _graphPanel.Controls.Add(_focusedAnalysisOverlay);
    }

    private void BuildSeriesButtons()
    {
        _seriesButtonHost.Controls.Clear();
        _seriesButtons.Clear();

        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            var button = new Button
            {
                Text = series.Name,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Height = 34,
                Padding = new Padding(12, 4, 12, 4),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 0, 8, 8),
                UseVisualStyleBackColor = false
            };

            string seriesName = series.Name;
            button.Click += (_, _) => ToggleSeries(seriesName);
            _seriesButtonHost.Controls.Add(button);
            _seriesButtons[seriesName] = button;
        }
    }

    private void ToggleSeries(string seriesName)
    {
        if (_visibleSeries.Contains(seriesName))
            _visibleSeries.Remove(seriesName);
        else
            _visibleSeries.Add(seriesName);

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        UpdateFocusedAnalysisOverlay();
        _graphPanel.Invalidate();
    }

    private void SetAllSeriesVisibility(bool visible)
    {
        _visibleSeries.Clear();
        if (visible)
        {
            foreach (var series in _snapshot.Series)
                _visibleSeries.Add(series.Name);
        }

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        UpdateFocusedAnalysisOverlay();
        _graphPanel.Invalidate();
    }

    private void UpdateSelectionLabel()
    {
        if (_visibleSeries.Count == 1)
        {
            string focusedName = _snapshot.Series
                .FirstOrDefault(series => _visibleSeries.Contains(series.Name))?
                .Name ?? "Focused";

            _selectionLabel.Text = $"Shown: 1 of {_snapshot.Series.Count}  |  Focus: {focusedName}";
            return;
        }

        _selectionLabel.Text = $"Shown: {_visibleSeries.Count} of {_snapshot.Series.Count}";
    }


    private void UpdateFocusedAnalysisOverlay()
    {
        var snapshot = BuildVisibleSnapshot();
        if (snapshot.Series.Count == 0 || _graphPanel.ClientSize.Width <= 0 || _graphPanel.ClientSize.Height <= 0)
        {
            _focusedAnalysisOverlay.Visible = false;
            return;
        }

        var layout = ScalingGraphRenderer.GetLayout(_graphPanel.ClientRectangle, snapshot.Series.Count);
        var insightRect = layout.InsightRect;
        if (insightRect.Width < 160 || insightRect.Height < 90)
        {
            _focusedAnalysisOverlay.Visible = false;
            return;
        }

        _focusedAnalysisOverlay.Visible = true;
        _focusedAnalysisOverlay.Bounds = insightRect;
        SetFocusedAnalysisContent(snapshot);
    }

    private void SetFocusedAnalysisContent(ScalingGraphSnapshot snapshot)
    {
        string text = ScalingGraphRenderer.BuildFocusedAnalysisText(snapshot);
        _focusedAnalysisTextBox.SuspendLayout();
        _focusedAnalysisTextBox.Clear();

        using var regularFont = new Font(_focusedAnalysisTextBox.Font, FontStyle.Regular);
        using var boldFont = new Font(_focusedAnalysisTextBox.Font, FontStyle.Bold);

        string normalized = text.Replace("\r\n", "\n");
        string[] lines = normalized.Split('\n');
        bool useBoldSectionHeaders = snapshot.Series.Count == 1;

        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i];
            bool isSectionHeader = useBoldSectionHeaders && line.EndsWith(":", StringComparison.Ordinal);

            _focusedAnalysisTextBox.SelectionStart = _focusedAnalysisTextBox.TextLength;
            _focusedAnalysisTextBox.SelectionLength = 0;
            _focusedAnalysisTextBox.SelectionFont = isSectionHeader ? boldFont : regularFont;
            _focusedAnalysisTextBox.SelectionColor = _focusedAnalysisTextBox.ForeColor;
            _focusedAnalysisTextBox.AppendText(line);

            if (i < lines.Length - 1)
            {
                _focusedAnalysisTextBox.SelectionStart = _focusedAnalysisTextBox.TextLength;
                _focusedAnalysisTextBox.SelectionLength = 0;
                _focusedAnalysisTextBox.SelectionFont = regularFont;
                _focusedAnalysisTextBox.SelectionColor = _focusedAnalysisTextBox.ForeColor;
                _focusedAnalysisTextBox.AppendText(Environment.NewLine);
            }
        }

        _focusedAnalysisTextBox.SelectionStart = 0;
        _focusedAnalysisTextBox.SelectionLength = 0;
        _focusedAnalysisTextBox.ScrollToCaret();
        _focusedAnalysisTextBox.ResumeLayout();
    }

    private void UpdateSeriesButtonStyles()
    {
        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            if (!_seriesButtons.TryGetValue(series.Name, out var button))
                continue;

            bool isVisible = _visibleSeries.Contains(series.Name);
            Color seriesColor = ScalingGraphRenderer.GetSeriesColor(series.ColorIndex);
            ApplySeriesButtonStyle(button, seriesColor, isVisible);
        }
    }

    private static void ApplySeriesButtonStyle(Button button, Color seriesColor, bool isVisible)
    {
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = seriesColor;

        if (isVisible)
        {
            button.BackColor = seriesColor;
            button.ForeColor = Color.White;
            button.Text = button.Text.StartsWith("✕ ", StringComparison.Ordinal) ? button.Text[2..] : button.Text;
        }
        else
        {
            button.BackColor = Color.FromArgb(245, 247, 250);
            button.ForeColor = Color.FromArgb(55, 65, 81);
            if (!button.Text.StartsWith("✕ ", StringComparison.Ordinal))
                button.Text = "✕ " + button.Text;
        }
    }

    private void DrawGraphPanel(Graphics graphics)
    {
        var snapshot = BuildVisibleSnapshot();
        if (snapshot.Series.Count == 0)
        {
            graphics.Clear(Color.White);
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            using var titleFont = new Font("Segoe UI Semibold", 22F, FontStyle.Bold, GraphicsUnit.Point);
            using var bodyFont = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
            using var bodyBrush = new SolidBrush(Color.FromArgb(90, 90, 90));
            var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };

            graphics.DrawString("No graph lines are currently visible", titleFont, titleBrush, _graphPanel.ClientRectangle, center);
            var subtitleRect = new RectangleF(0, (_graphPanel.ClientRectangle.Height / 2F) + 28F, _graphPanel.ClientRectangle.Width, 40F);
            graphics.DrawString("Use the buttons at the top to turn one or more benchmark series back on.", bodyFont, bodyBrush, subtitleRect, center);
            return;
        }

        ScalingGraphRenderer.Draw(graphics, _graphPanel.ClientRectangle, snapshot);
    }

    private ScalingGraphSnapshot BuildVisibleSnapshot()
    {
        var visibleSeries = _snapshot.Series
            .Where(series => _visibleSeries.Contains(series.Name))
            .ToArray();

        if (visibleSeries.Length == 0)
        {
            return new ScalingGraphSnapshot
            {
                SessionId = _snapshot.SessionId,
                Title = _snapshot.Title,
                Subtitle = _snapshot.Subtitle,
                Series = Array.Empty<ScalingGraphSeries>(),
                ThreadTicks = _snapshot.ThreadTicks,
                MaxScalingPercent = Math.Max(200.0, _snapshot.MaxScalingPercent)
            };
        }

        double maxScaling = visibleSeries
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        return new ScalingGraphSnapshot
        {
            SessionId = _snapshot.SessionId,
            Title = _snapshot.Title,
            Subtitle = _snapshot.Subtitle,
            Series = visibleSeries,
            ThreadTicks = _snapshot.ThreadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private void ScalingGraphForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            e.Handled = true;
            Close();
        }
    }
}
