using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CpuBenchmarkWorkbench;

/// <summary>
/// Application entry point.
///
/// The startup path is intentionally defensive: we enable logging and catch top-level
/// exceptions so builders on different machines get a useful message instead of a silent crash.
/// </summary>
internal static class Program
{
    [STAThread]
    public static void Main()
    {
        StartupDiagnostics.Log("Program entry.");

        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) =>
        {
            StartupDiagnostics.Log(e.Exception, "UI thread exception");
            MessageBox.Show(
                $"The app hit an error and could not continue.\r\n\r\n{e.Exception.Message}\r\n\r\nLog file:\r\n{StartupDiagnostics.LogFilePath}",
                "CPU Benchmark Workbench",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        };

        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            if (e.ExceptionObject is Exception ex)
                StartupDiagnostics.Log(ex, "AppDomain unhandled exception");
            else
                StartupDiagnostics.Log("AppDomain unhandled exception: unknown object.");
        };

        TaskScheduler.UnobservedTaskException += (_, e) =>
        {
            StartupDiagnostics.Log(e.Exception, "Unobserved task exception");
            e.SetObserved();
        };

        try
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
                StartupDiagnostics.Log("High DPI mode enabled.");
            }
            catch (Exception ex)
            {
                StartupDiagnostics.Log(ex, "SetHighDpiMode failed");
            }

            using var form = new MainForm();
            StartupDiagnostics.Log("MainForm created successfully.");
            Application.Run(form);
            StartupDiagnostics.Log("Application.Run exited normally.");
        }
        catch (Exception ex)
        {
            StartupDiagnostics.Log(ex, "Fatal startup exception");
            MessageBox.Show(
                $"The application failed during startup.\r\n\r\n{ex}\r\n\r\nLog file:\r\n{StartupDiagnostics.LogFilePath}",
                "CPU Benchmark Workbench",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
