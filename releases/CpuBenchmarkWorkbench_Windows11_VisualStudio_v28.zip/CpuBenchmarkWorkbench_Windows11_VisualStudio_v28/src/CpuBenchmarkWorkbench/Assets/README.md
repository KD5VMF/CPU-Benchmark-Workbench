# CPU Benchmark Workbench assets

This folder contains the application art used by the WinForms project.

## Default application icon

- `cpu-benchmark-workbench-icon-primary.ico`

The project file points to this icon through the `ApplicationIcon` property so the built
`.exe` gets the proper Windows icon automatically.

## Runtime behavior

The forms also try to load the same icon at runtime. This keeps the title-bar and taskbar
icon consistent even when the project is opened on another machine or copied to a new
folder.

## Other included icon variants

- `cpu-benchmark-workbench-icon-midnight.ico`
- `cpu-benchmark-workbench-icon-minimal.ico`

Those are included so contributors can experiment without having to regenerate art.

## Preview

- `cpu-benchmark-workbench-icon-pack-preview.png`

That image is useful for the GitHub README or release notes.
