using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CpuBenchmarkWorkbench;

/// <summary>
/// Windows thread-placement helper.
///
/// Why this file exists:
/// Large workstations and servers often have more than one NUMA node. During
/// testing we discovered that some memory-sensitive benchmarks scaled well up
/// to roughly half the machine and then fell off sharply. One major reason is
/// first-touch memory locality: if all worker objects and arrays are created on
/// the UI thread, their pages can start life on one NUMA node even when later
/// used by worker threads running elsewhere.
///
/// This helper gives the benchmark engine a best-effort way to place worker
/// threads more deliberately. It is heavily commented because the goal is not
/// only to improve results, but also to help contributors learn how thread
/// placement and NUMA topology interact on Windows.
/// </summary>
public static class ThreadPlacementHelper
{
    /// <summary>
    /// Build a run plan for the requested worker count and placement mode.
    /// Auto returns a descriptive plan without pinning. Adaptive chooses a more
    /// specific policy based on the discovered topology and requested worker
    /// count. The other modes try to map each worker to a specific logical
    /// processor.
    /// </summary>
    public static WorkerPlacementPlan BuildPlan(CpuCapabilityReport report, int workerCount, WorkerPlacementMode requestedMode, BenchmarkPlacementBias bias)
    {
        workerCount = Math.Max(1, workerCount);
        var processors = EnumerateLogicalProcessors();
        int discoveredGroups = processors.GroupBy(p => p.Group).Count();
        int discoveredNodes = processors.Where(p => p.NumaNode.HasValue).Select(p => p.NumaNode!.Value).Distinct().Count();

        if (requestedMode == WorkerPlacementMode.Auto || processors.Count == 0)
        {
            string description = requestedMode == WorkerPlacementMode.Auto
                ? "Auto placement: let Windows schedule worker threads."
                : "Placement helpers could not discover logical processors, so the run will fall back to Auto placement.";

            return new WorkerPlacementPlan(
                requestedMode,
                WorkerPlacementMode.Auto,
                Array.Empty<WorkerPlacementTarget>(),
                description,
                processors.Count,
                discoveredGroups,
                discoveredNodes);
        }

        WorkerPlacementMode effectiveMode = requestedMode;
        string adaptiveReason = string.Empty;
        if (requestedMode == WorkerPlacementMode.Adaptive)
        {
            effectiveMode = ChooseAdaptiveMode(report, processors, workerCount, bias, out adaptiveReason);
        }

        List<LogicalProcessorSlot> ordered = effectiveMode switch
        {
            WorkerPlacementMode.Compact => OrderCompact(processors),
            WorkerPlacementMode.Spread => OrderSpread(processors, workerCount),
            WorkerPlacementMode.NumaBalanced => OrderNumaBalanced(processors, workerCount),
            _ => OrderCompact(processors)
        };

        if (ordered.Count == 0)
        {
            return new WorkerPlacementPlan(
                requestedMode,
                WorkerPlacementMode.Auto,
                Array.Empty<WorkerPlacementTarget>(),
                "No placement targets were produced. Falling back to Auto placement.",
                processors.Count,
                discoveredGroups,
                discoveredNodes);
        }

        var targets = new List<WorkerPlacementTarget>(workerCount);
        for (int i = 0; i < workerCount; i++)
        {
            var slot = ordered[i % ordered.Count];
            targets.Add(new WorkerPlacementTarget(i, slot.Group, slot.ProcessorNumber, slot.NumaNode));
        }

        string targetSummary = BuildTargetSummary(targets);
        string descriptionText;
        if (requestedMode == WorkerPlacementMode.Adaptive)
        {
            descriptionText = $"Adaptive placement chose {effectiveMode.DisplayName()} over {processors.Count} discovered logical processor(s). {adaptiveReason} {targetSummary}";
        }
        else
        {
            descriptionText = $"{effectiveMode.DisplayName()} placement over {processors.Count} discovered logical processor(s). {targetSummary}";
        }

        return new WorkerPlacementPlan(
            requestedMode,
            effectiveMode,
            targets,
            descriptionText,
            processors.Count,
            discoveredGroups,
            discoveredNodes);
    }

    /// <summary>
    /// Adaptive placement exists because one fixed policy is not ideal for all
    /// thread counts. Smaller runs often perform best when they stay compact and
    /// local to one NUMA node. Large runs need all nodes engaged fairly.
    /// </summary>
    private static WorkerPlacementMode ChooseAdaptiveMode(CpuCapabilityReport report, List<LogicalProcessorSlot> processors, int workerCount, BenchmarkPlacementBias bias, out string reason)
    {
        int visibleThreads = Math.Max(1, processors.Count);
        var nodeGroups = processors
            .GroupBy(p => p.NumaNode ?? 0)
            .OrderBy(g => g.Key)
            .ToList();

        int discoveredNodes = nodeGroups.Count;
        bool hasRealNuma = discoveredNodes > 1 || report.NumaNodes > 1;
        int processorsPerNode = nodeGroups.Where(g => g.Count() > 0).Select(g => g.Count()).DefaultIfEmpty(visibleThreads).Min();
        processorsPerNode = Math.Max(1, processorsPerNode);
        int halfNode = Math.Max(1, processorsPerNode / 2);

        if (!hasRealNuma)
        {
            if (workerCount <= Math.Max(1, visibleThreads / 2))
            {
                reason = $"Adaptive kept the run compact because the machine looks like a single NUMA domain and the worker count ({workerCount}) is at or below half of the visible logical CPUs ({visibleThreads}).";
                return WorkerPlacementMode.Compact;
            }

            reason = $"Adaptive used Spread because the machine looks like a single NUMA domain and the worker count ({workerCount}) is large enough that packing every worker tightly can over-crowd nearby logical CPUs.";
            return WorkerPlacementMode.Spread;
        }

        // Memory bandwidth and portable SIMD behaved differently from dense compute
        // on the user's large workstation runs. These hints let Adaptive spread out
        // earlier for the tests that need more aggregate memory bandwidth or wider
        // socket participation to avoid misleading drops at mid-range thread counts.
        if (bias == BenchmarkPlacementBias.BandwidthSensitive)
        {
            if (workerCount >= halfNode)
            {
                reason = $"Adaptive chose NUMA Balanced early because this benchmark is tagged as bandwidth-sensitive and {workerCount} worker(s) already reach at least half of one NUMA node budget ({halfNode}). Earlier cross-node placement usually improves total memory bandwidth on large machines.";
                return WorkerPlacementMode.NumaBalanced;
            }

            if (workerCount > 1)
            {
                reason = $"Adaptive chose Spread because this benchmark is tagged as bandwidth-sensitive and even moderate worker counts benefit from avoiding over-crowding one local area of the machine.";
                return WorkerPlacementMode.Spread;
            }

            reason = $"Adaptive kept the run Compact because this bandwidth-sensitive benchmark only has one worker.";
            return WorkerPlacementMode.Compact;
        }

        if (bias == BenchmarkPlacementBias.PortableSimd)
        {
            if (workerCount >= halfNode)
            {
                reason = $"Adaptive chose NUMA Balanced because this portable SIMD benchmark started dropping badly near half-machine utilization in earlier runs. Using all discovered NUMA nodes earlier helps keep vector workers from fighting over one node's local resources.";
                return WorkerPlacementMode.NumaBalanced;
            }

            if (workerCount >= Math.Max(2, halfNode / 2))
            {
                reason = $"Adaptive chose Spread because this portable SIMD benchmark benefits from a little more room before it reaches half-node scale.";
                return WorkerPlacementMode.Spread;
            }

            reason = $"Adaptive kept the run Compact because this portable SIMD run is still small.";
            return WorkerPlacementMode.Compact;
        }

        if (workerCount <= processorsPerNode)
        {
            reason = $"Adaptive kept the run Compact because {workerCount} worker(s) fit within one discovered NUMA node budget of about {processorsPerNode} logical CPU(s). This preserves locality for smaller and mid-size dense-compute runs.";
            return WorkerPlacementMode.Compact;
        }

        if (workerCount >= Math.Max(processorsPerNode + 1, visibleThreads * 3 / 4))
        {
            reason = $"Adaptive chose NUMA Balanced because the run is large ({workerCount} worker(s) on {visibleThreads} visible logical CPU(s)) and should involve all discovered NUMA nodes more evenly.";
            return WorkerPlacementMode.NumaBalanced;
        }

        reason = $"Adaptive chose Spread for an in-between worker count ({workerCount}) so the run is not packed onto one part of the machine too early but also does not force strict node alternation yet.";
        return WorkerPlacementMode.Spread;
    }

    /// <summary>
    /// Apply the chosen target to the current thread.
    ///
    /// This uses SetThreadGroupAffinity when possible so the helper still works
    /// on systems that expose more than one processor group. If that fails and
    /// the target is in group 0, we fall back to SetThreadAffinityMask.
    /// </summary>
    public static string ApplyCurrentThreadTarget(WorkerPlacementTarget? target)
    {
        if (target is null)
            return "Auto";

        nuint mask = unchecked((nuint)(1UL << target.ProcessorNumber));
        GROUP_AFFINITY affinity = new()
        {
            Mask = mask,
            Group = target.Group,
            Reserved0 = 0,
            Reserved1 = 0,
            Reserved2 = 0
        };

        IntPtr thread = GetCurrentThread();
        try
        {
            if (SetThreadGroupAffinity(thread, affinity, IntPtr.Zero))
                return target.ToHumanString();
        }
        catch (EntryPointNotFoundException)
        {
        }
        catch (DllNotFoundException)
        {
        }

        if (target.Group == 0)
        {
            nuint previous = SetThreadAffinityMask(thread, mask);
            if (previous != 0)
                return target.ToHumanString();
        }

        return target.ToHumanString() + " (advisory only)";
    }

    private static List<LogicalProcessorSlot> OrderCompact(List<LogicalProcessorSlot> processors)
    {
        return processors
            .OrderBy(p => p.NumaNode ?? int.MinValue)
            .ThenBy(p => p.Group)
            .ThenBy(p => p.ProcessorNumber)
            .ToList();
    }

    private static List<LogicalProcessorSlot> OrderSpread(List<LogicalProcessorSlot> processors, int workerCount)
    {
        var compact = OrderCompact(processors);
        if (compact.Count <= 1 || workerCount <= 1)
            return compact;

        var used = new HashSet<(ushort Group, byte Processor)>();
        var result = new List<LogicalProcessorSlot>();
        int initialCount = Math.Min(workerCount, compact.Count);
        for (int i = 0; i < initialCount; i++)
        {
            double fraction = initialCount == 1 ? 0.0 : i / (double)(initialCount - 1);
            int index = (int)Math.Round(fraction * (compact.Count - 1), MidpointRounding.AwayFromZero);
            index = Math.Clamp(index, 0, compact.Count - 1);
            var slot = compact[index];
            if (used.Add((slot.Group, slot.ProcessorNumber)))
                result.Add(slot);
        }

        foreach (var slot in compact)
        {
            if (used.Add((slot.Group, slot.ProcessorNumber)))
                result.Add(slot);
        }

        return result;
    }

    private static List<LogicalProcessorSlot> OrderNumaBalanced(List<LogicalProcessorSlot> processors, int workerCount)
    {
        var groups = processors
            .GroupBy(p => p.NumaNode ?? 0)
            .OrderBy(g => g.Key)
            .Select(g => new Queue<LogicalProcessorSlot>(g.OrderBy(p => p.Group).ThenBy(p => p.ProcessorNumber)))
            .ToList();

        if (groups.Count <= 1)
            return OrderSpread(processors, workerCount);

        var ordered = new List<LogicalProcessorSlot>(processors.Count);
        while (groups.Any(q => q.Count > 0))
        {
            foreach (var queue in groups)
            {
                if (queue.Count > 0)
                    ordered.Add(queue.Dequeue());
            }
        }

        return ordered;
    }

    private static string BuildTargetSummary(List<WorkerPlacementTarget> targets)
    {
        if (targets.Count == 0)
            return "No explicit worker targets.";

        int sampleCount = Math.Min(8, targets.Count);
        string sample = string.Join(", ", targets.Take(sampleCount).Select(t => $"w{t.WorkerIndex}->{t.ToHumanString()}"));
        if (targets.Count > sampleCount)
            sample += ", ...";
        return "Sample targets: " + sample;
    }

    private static List<LogicalProcessorSlot> EnumerateLogicalProcessors()
    {
        var slots = new List<LogicalProcessorSlot>();
        ushort groupCount;
        try
        {
            groupCount = GetActiveProcessorGroupCount();
        }
        catch
        {
            groupCount = 1;
        }

        if (groupCount == 0)
            groupCount = 1;

        for (ushort group = 0; group < groupCount; group++)
        {
            uint count;
            try
            {
                count = GetActiveProcessorCount(group);
            }
            catch
            {
                count = 0;
            }

            for (uint processor = 0; processor < count && processor < 64; processor++)
            {
                slots.Add(new LogicalProcessorSlot
                {
                    Group = group,
                    ProcessorNumber = (byte)processor,
                    NumaNode = null
                });
            }
        }

        try
        {
            if (GetNumaHighestNodeNumber(out uint highestNode))
            {
                for (ushort node = 0; node <= highestNode; node++)
                {
                    if (!GetNumaNodeProcessorMaskEx(node, out GROUP_AFFINITY affinity))
                        continue;

                    for (int bit = 0; bit < 64; bit++)
                    {
                        nuint bitMask = unchecked((nuint)(1UL << bit));
                        if ((affinity.Mask & bitMask) == 0)
                            continue;

                        var slot = slots.FirstOrDefault(p => p.Group == affinity.Group && p.ProcessorNumber == bit);
                        if (slot is not null)
                            slot.NumaNode = node;
                    }
                }
            }
        }
        catch
        {
        }

        return slots;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct GROUP_AFFINITY
    {
        public nuint Mask;
        public ushort Group;
        public ushort Reserved0;
        public ushort Reserved1;
        public ushort Reserved2;
    }

    private sealed class LogicalProcessorSlot
    {
        public ushort Group { get; init; }
        public byte ProcessorNumber { get; init; }
        public int? NumaNode { get; set; }
    }

    [DllImport("kernel32.dll")]
    private static extern ushort GetActiveProcessorGroupCount();

    [DllImport("kernel32.dll")]
    private static extern uint GetActiveProcessorCount(ushort groupNumber);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetNumaHighestNodeNumber(out uint highestNodeNumber);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetNumaNodeProcessorMaskEx(ushort node, out GROUP_AFFINITY processorMask);

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetCurrentThread();

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetThreadGroupAffinity(IntPtr threadHandle, GROUP_AFFINITY groupAffinity, IntPtr previousGroupAffinity);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern nuint SetThreadAffinityMask(IntPtr threadHandle, nuint threadAffinityMask);
}

/// <summary>
/// Immutable plan object produced before a benchmark run starts.
/// The engine uses this to keep the run logic simple and repeatable.
/// </summary>
public sealed class WorkerPlacementPlan
{
    public WorkerPlacementPlan(WorkerPlacementMode requestedMode, WorkerPlacementMode effectiveMode, IReadOnlyList<WorkerPlacementTarget> targets, string description, int discoveredLogicalProcessors, int discoveredProcessorGroups, int discoveredNumaNodes)
    {
        RequestedMode = requestedMode;
        EffectiveMode = effectiveMode;
        Targets = targets;
        Description = description;
        DiscoveredLogicalProcessors = discoveredLogicalProcessors;
        DiscoveredProcessorGroups = discoveredProcessorGroups;
        DiscoveredNumaNodes = discoveredNumaNodes;
    }

    public WorkerPlacementMode RequestedMode { get; }
    public WorkerPlacementMode EffectiveMode { get; }
    public IReadOnlyList<WorkerPlacementTarget> Targets { get; }
    public string Description { get; }
    public int DiscoveredLogicalProcessors { get; }
    public int DiscoveredProcessorGroups { get; }
    public int DiscoveredNumaNodes { get; }

    public string ResultLabel => RequestedMode == EffectiveMode
        ? EffectiveMode.DisplayName()
        : RequestedMode.DisplayName() + " -> " + EffectiveMode.DisplayName();

    public WorkerPlacementTarget? TryGetTarget(int workerIndex)
    {
        if (EffectiveMode == WorkerPlacementMode.Auto || workerIndex < 0 || workerIndex >= Targets.Count)
            return null;
        return Targets[workerIndex];
    }
}

/// <summary>
/// One worker's explicit target.
/// </summary>
public sealed class WorkerPlacementTarget
{
    public WorkerPlacementTarget(int workerIndex, ushort group, byte processorNumber, int? numaNode)
    {
        WorkerIndex = workerIndex;
        Group = group;
        ProcessorNumber = processorNumber;
        NumaNode = numaNode;
    }

    public int WorkerIndex { get; }
    public ushort Group { get; }
    public byte ProcessorNumber { get; }
    public int? NumaNode { get; }

    public string ToHumanString()
    {
        if (NumaNode.HasValue)
            return $"NUMA {NumaNode.Value}, Group {Group}, CPU {ProcessorNumber}";
        return $"Group {Group}, CPU {ProcessorNumber}";
    }
}
