# CPU Benchmark Workbench architecture notes

This document is meant to help people learn from the codebase, not just build it.

## Project layout

- `CpuBenchmarkWorkbench.sln`  
  Visual Studio solution file.

- `src/CpuBenchmarkWorkbench/CpuBenchmarkWorkbench.csproj`  
  Main WinForms project.

- `src/CpuBenchmarkWorkbench/Program.cs`  
  Application entry point and top-level exception handling.

- `src/CpuBenchmarkWorkbench/MainForm.cs`  
  Main window, layout, benchmark execution flow, result grid, CSV export, and UI commands.

- `src/CpuBenchmarkWorkbench/Benchmarks.cs`  
  Benchmark catalog, benchmark engine, and individual benchmark worker implementations.

- `src/CpuBenchmarkWorkbench/Models.cs`  
  Shared models, capability reporting, metric formatting, run options, and system-info helpers.

- `src/CpuBenchmarkWorkbench/ThreadPlacement.cs`  
  Worker placement planning and Windows affinity / NUMA helper code.

- `src/CpuBenchmarkWorkbench/AboutForm.cs`  
  About dialog and MIT license text.

- `src/CpuBenchmarkWorkbench/HelpGuideForm.cs`  
  Built-in help system.

- `src/CpuBenchmarkWorkbench/StartupDiagnostics.cs`  
  Startup logging used when something goes wrong early.

- `src/CpuBenchmarkWorkbench/AppVisuals.cs`  
  Shared icon-loading helper so forms use the same branding.

- `src/CpuBenchmarkWorkbench/Assets/`  
  Icon and image assets.

## How the benchmark flow works

1. The app builds a machine capability report.
2. The benchmark catalog uses that report to decide which tests should appear.
3. The user chooses benchmarks, a preset, and a thread count.
4. The benchmark engine builds a placement plan for the run.
5. Each worker thread applies its placement hint, creates its own worker locally, and optionally warms up before timing starts.
6. Each worker repeatedly performs a batch of work until the target time is reached.
7. The engine totals the work, divides by elapsed time, and formats the result.

## Why Smart Sweep exists

Many machines expose a high thread count. Running every thread value from 1 to the maximum can
turn a quick comparison into a very long session. Smart Sweep samples:

- 1 thread
- 25%
- 50%
- 75%
- 100%

That gives a useful scaling curve with far less waiting.

## Why some benchmarks appear only on some systems

This project uses feature-aware testing. If the runtime or hardware does not expose a capability,
the matching benchmark is hidden instead of being shown and then failing.

Examples:
- AVX2 / FMA benchmark only when AVX2 and FMA are both reported
- AVX-512 benchmark only when an AVX-512 family is reported
- AES benchmark only when AES acceleration is reported

## UI design goals

The UI was built to stay readable across:
- normal desktops
- gaming PCs
- high-DPI laptops
- workstations
- servers with lots of threads

That is why the left sidebar uses cards, auto-sizing layout, and a guarded splitter strategy.

## Asset design goals

The icon is intentionally simple:
- a CPU package for hardware identity
- chart bars for benchmarking
- strong contrast for Windows taskbar visibility

Contributors can swap the icon by replacing the primary `.ico` in `Assets` and keeping the same filename.

## Why worker-local creation matters on NUMA systems

Earlier runs showed that some memory and SIMD tests behaved well until roughly half the machine was active, then dropped sharply. One major reason is first-touch memory locality: if every worker-owned array is created on the UI thread, many pages can begin life on one NUMA node even though later used by threads running elsewhere.

This revision creates benchmark workers on the worker threads themselves and adds explicit placement modes:

- Auto
- Compact
- Spread
- NUMA Balanced

That makes it easier to compare scheduler-default behavior against more deliberate placement on large workstations and servers.


## New in v25

- `src/CpuBenchmarkWorkbench/BenchmarkScoring.cs` holds the anchored overall score model, category scoring, and best-fit CPU opinion logic.
