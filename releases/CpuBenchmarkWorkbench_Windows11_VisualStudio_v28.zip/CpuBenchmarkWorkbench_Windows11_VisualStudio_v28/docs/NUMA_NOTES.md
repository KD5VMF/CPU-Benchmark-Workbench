# NUMA and thread placement notes

This note explains one of the most important lessons from real benchmark runs on large workstations and servers.

## The problem we observed

Some benchmarks scaled very well up to about half of the machine, then flattened or even dropped when more threads were added. That can happen even when the CPU itself is strong.

Common reasons include:

- remote NUMA memory access
- workers landing unevenly across sockets or NUMA nodes
- shared cache pressure
- thread migration during the run
- first-touch memory pages being created on the wrong node

## What this revision changes

This revision does two important things:

1. It adds worker placement modes:
   - Auto
   - Compact
   - Spread
   - NUMA Balanced

2. It creates benchmark workers on their worker threads instead of on the UI thread.

That second change matters because large arrays usually receive their first physical pages where they are first touched. On NUMA systems, creating all worker-owned arrays on one thread can bias the test badly.

## When to try NUMA Balanced

NUMA Balanced is most useful when:

- the machine reports more than one NUMA node
- a test improves well up to about half the threads, then falls off
- memory, cache, or SIMD tests look suspiciously worse than scalar integer tests

## When Auto is still useful

Auto is still the best baseline because it shows how Windows schedules the workload by default. The point of the extra modes is not to replace Auto, but to compare it with more deliberate placement.

## Practical workflow

For a large workstation or server:

1. Run Smart Sweep with Auto
2. Run the same benchmarks again with NUMA Balanced
3. Compare:
   - SIMD Vector Math
   - Memory Stream
   - Cache Walker
   - Matrix Multiply
4. If needed, try Compact or Spread for more experiments

## Reading the results

If NUMA Balanced improves scaling noticeably, the machine was probably being limited more by placement and locality than by raw CPU power.


## What v19 changes

Real test data showed that the v18 NUMA fix improved full-machine results but hurt many mid-thread runs. That means one placement policy was trying to solve two different problems at once.

In v19, a new Adaptive mode chooses placement based on the requested worker count:

- if the run fits within roughly one discovered NUMA node, keep it Compact
- if the run is in the middle, use Spread
- if the run is large enough to need the whole machine, use NUMA Balanced

This is meant to keep the strong high-thread improvements from v18 while recovering the smaller and mid-size thread-count performance that can be lost when threads are spread too early.

The save flow also now writes a companion run log and system report beside the CSV so future comparisons have more context than raw scores alone.


## What v20 changes

V20 keeps the worker-thread first-touch fix from earlier revisions, but adds two more lessons from the user's large workstation data:

1. Adaptive placement now honors a benchmark placement bias. Memory bandwidth and portable SIMD tests can spread earlier or become NUMA Balanced earlier than dense compute tests.
2. Floating-point and AVX-family validation state is now intentionally bounded so the checksum remains finite even during long burn-in sessions.

The main idea is simple: a single placement policy is not ideal for every workload, and a validation checksum is only useful when it stays numerically well-behaved.


## v23 follow-up

Real user runs on a 48-thread, 2-NUMA-node workstation showed that one policy is not ideal for every benchmark. v23 keeps benchmark-aware Adaptive placement and the validated-versus-peak benchmark pairs, then follows up on the remaining problem areas: the peak scalar FP kernel now recenters around non-zero baselines so its checksum stays meaningful, and the sustained memory test now performs a single streaming rewrite pass so full-machine runs do not pay for an avoidable second walk over memory.
