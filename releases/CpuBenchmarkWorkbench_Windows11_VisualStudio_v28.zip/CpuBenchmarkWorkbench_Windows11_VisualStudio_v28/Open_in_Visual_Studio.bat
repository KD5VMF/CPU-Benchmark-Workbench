@echo off
setlocal
set "ROOT=%~dp0"
if exist "%ROOT%CpuBenchmarkWorkbench.sln" (
  start "" "%ROOT%CpuBenchmarkWorkbench.sln"
) else (
  start "" "%ROOT%src\CpuBenchmarkWorkbench\CpuBenchmarkWorkbench.csproj"
)
endlocal
