# CPU Benchmark Workbench

CPU Benchmark Workbench is a Windows 11 / Visual Studio WinForms desktop app for comparing many different CPU behaviors instead of only one score.

## Highlights in v26

- Floating Point Mix (Peak) now recenters around stable non-zero baselines so its checksum stays meaningful instead of merely staying finite.
- Memory Stream (Sustained) now uses a one-pass copy/mutate/checksum loop aimed at improving full-load behavior on large NUMA workstations.
- Main window now starts maximized so the controls and results area are immediately usable on large displays.
- A final overall PC score now appears at the end of each run, from 0 to 100,000.
- The score is anchored to the validated v23 reference run: matching that profile lands around 2,000, while a machine that is about 50x faster across the covered benchmark profile would land at 100,000.
- The app now gives a best-fit CPU use-case opinion based on category scoring, such as scientific/simulation, memory/data movement, encryption, creator-side math, or general throughput.
- A new Fullscreen Graph button opens a large scaling chart for the selected or latest run session, with a Close button and Esc support.
- The fullscreen graph now includes benchmark buttons so each line can be hidden or shown independently.
- CSV export now saves matching per-session thread-scaling PNG graphs so the visual scaling data stays with the saved run.

- clean left/right layout with visible controls
- dynamic benchmark catalog based on detected runtime CPU features
- scalar tests for integer, floating point, branches, primes, and mixed workloads
- memory tests for bandwidth and cache-latency style behavior
- SIMD test using portable `Vector<T>`
- AVX2/FMA benchmark when supported
- AVX-512 benchmark when supported
- AES benchmark when supported
- single-run mode, Smart Sweep mode, and Burn-In mode
- worker placement modes: Auto, Adaptive, Compact, Spread, and NUMA Balanced
- worker-local first-touch allocation to reduce NUMA locality distortions
- adaptive placement to keep smaller and mid-size runs compact while still balancing large runs across NUMA nodes
- companion log, system-report, overall-score, and per-session thread-scaling PNG files saved beside each CSV export
- placement column in results and CSV export
- built-in Help Guide
- built-in About + MIT License dialog
- CSV export and copyable system capability report

## Included benchmark families

- Integer Mix
- Bit Twister
- Floating Point Mix
- Floating Point Mix (Peak)
- Branch Chaos
- Cache Walker
- SIMD Vector Math
- AVX2 / FMA Float32 *(when supported)*
- AVX2 / FMA Float32 (Peak) *(when supported)*
- AVX-512 Wide Float32 *(when supported)*
- AVX-512 Wide Float32 (Peak) *(when supported)*
- AES Blocks *(when supported)*
- Memory Stream
- Memory Stream (Sustained)
- Matrix Multiply
- Prime Scan
- Mandelbrot



## Application icon

This build now includes bundled artwork in `src/CpuBenchmarkWorkbench/Assets/`.

- default Windows application icon: `cpu-benchmark-workbench-icon-primary.ico`
- alternate icon variants are included for contributors
- the project file assigns the icon to the built executable
- forms also load the same icon at runtime for a consistent title-bar/taskbar look

## Burn-In mode

Burn-In repeatedly cycles through the checked benchmarks for the selected number of minutes or until Stop is pressed. It is intended for longer thermal and stability testing.



## Learning the code

This project is intentionally documented to help other builders learn.

Start here:
- `docs/ARCHITECTURE.md` for the code map
- `docs/NUMA_NOTES.md` for placement and NUMA behavior guidance
- `src/CpuBenchmarkWorkbench/AppVisuals.cs` for shared icon handling
- `src/CpuBenchmarkWorkbench/Program.cs` for startup flow
- `src/CpuBenchmarkWorkbench/MainForm.cs` for UI and run orchestration
- `src/CpuBenchmarkWorkbench/Benchmarks.cs` for the actual benchmark workers

## Open in Visual Studio

Open:
- `CpuBenchmarkWorkbench.sln`

Or directly open:
- `src/CpuBenchmarkWorkbench/CpuBenchmarkWorkbench.csproj`

## License

MIT License. See `LICENSE.txt`.


Compatibility note for v26: this build keeps the first-touch and companion logging improvements, keeps benchmark-aware Adaptive placement, keeps both validated and peak benchmark pairs, keeps the v23 Floating Point Mix (Peak) and Memory Stream (Sustained) fixes, starts the main window maximized, keeps the final anchored whole-PC score plus best-fit CPU use-case opinion, and adds fullscreen scaling graph preview plus saved per-session graph PNG exports, plus per-benchmark show/hide buttons in the fullscreen graph view.


## v26 highlights

- Improved the peak scalar floating-point kernel so its checksum remains meaningfully non-zero
- Reworked `Memory Stream (Sustained)` into a one-pass streaming rewrite path for better top-end scaling
- Start the application maximized and keep the benchmark-aware Adaptive placement model
- Add an anchored 0 to 100,000 whole-PC score
- Add a best-fit CPU use-case verdict and companion overall-score report
- Add a Fullscreen Graph button that opens the selected or latest session scaling chart
- Add per-benchmark show/hide buttons inside the fullscreen graph view
- Save per-session thread-scaling PNG graphs beside CSV exports