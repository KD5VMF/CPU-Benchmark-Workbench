using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace CpuBenchmarkWorkbench;

public sealed class ScalingGraphSnapshot
{
    public string SessionId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Subtitle { get; init; } = string.Empty;
    public IReadOnlyList<ScalingGraphSeries> Series { get; init; } = Array.Empty<ScalingGraphSeries>();
    public IReadOnlyList<int> ThreadTicks { get; init; } = Array.Empty<int>();
    public double MaxScalingPercent { get; init; }
}

public sealed class ScalingGraphSeries
{
    public string Name { get; init; } = string.Empty;
    public int ColorIndex { get; init; }
    public IReadOnlyList<ScalingGraphPoint> Points { get; init; } = Array.Empty<ScalingGraphPoint>();
}

public readonly record struct ScalingGraphPoint(int Threads, double ScalingPercent);

internal readonly record struct ScalingGraphExport(string FilePath, ScalingGraphSnapshot Snapshot);

internal static class ScalingGraphBuilder
{
    private static readonly string[] PreferredBenchmarks =
    [
        "Integer Mix",
        "AVX-512 Wide Float32",
        "AVX2 / FMA Float32",
        "Memory Stream",
        "Memory Stream (Sustained)",
        "AES Blocks",
        "Matrix Multiply",
        "Prime Scan",
        "Mandelbrot"
    ];

    public static string? GetPreviewSessionId(IEnumerable<BenchmarkResult> results, BenchmarkResult? selectedResult)
    {
        if (selectedResult is not null && !string.IsNullOrWhiteSpace(selectedResult.SessionId))
            return selectedResult.SessionId;

        return results
            .Where(x => !string.IsNullOrWhiteSpace(x.SessionId))
            .OrderByDescending(x => x.StartedAt)
            .Select(x => x.SessionId)
            .FirstOrDefault();
    }

    public static IReadOnlyList<ScalingGraphExport> BuildExports(IEnumerable<BenchmarkResult> results, CpuCapabilityReport report)
    {
        var exports = new List<ScalingGraphExport>();
        var sessions = results
            .Where(x => x.ScorePerSecond > 0.0 && !string.IsNullOrWhiteSpace(x.SessionId))
            .GroupBy(x => x.SessionId, StringComparer.OrdinalIgnoreCase)
            .OrderBy(g => g.Min(x => x.StartedAt))
            .ToList();

        if (sessions.Count == 0)
            return exports;

        string? singleSessionId = sessions.Count == 1 ? sessions[0].Key : null;
        foreach (var session in sessions)
        {
            var snapshot = BuildForSession(results, report, session.Key);
            if (snapshot is null)
                continue;

            string suffix = singleSessionId is not null
                ? "-thread-scaling.png"
                : $"-session-{SanitizeFileName(session.Key)}-thread-scaling.png";

            exports.Add(new ScalingGraphExport(suffix, snapshot));
        }

        return exports;
    }

    public static ScalingGraphSnapshot? BuildForSession(IEnumerable<BenchmarkResult> allResults, CpuCapabilityReport report, string sessionId)
    {
        var sessionResults = allResults
            .Where(x => x.ScorePerSecond > 0.0)
            .Where(x => string.Equals(x.SessionId, sessionId, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Threads)
            .ThenBy(x => x.StartedAt)
            .ToList();

        if (sessionResults.Count == 0)
            return null;

        var presetLabel = sessionResults
            .Select(x => x.Preset)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var placementLabel = sessionResults
            .Select(x => x.Placement)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var scoring = BenchmarkScoringEngine.Evaluate(sessionResults, sessionId);
        var grouped = sessionResults
            .GroupBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Threads).ThenBy(x => x.StartedAt).ToList(), StringComparer.OrdinalIgnoreCase);

        var orderedBenchmarkNames = new List<string>();
        foreach (string name in PreferredBenchmarks)
        {
            if (grouped.ContainsKey(name))
                orderedBenchmarkNames.Add(name);
        }

        foreach (string name in grouped.Keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            if (!orderedBenchmarkNames.Contains(name, StringComparer.OrdinalIgnoreCase))
                orderedBenchmarkNames.Add(name);
        }

        var series = new List<ScalingGraphSeries>();
        foreach (string benchmarkName in orderedBenchmarkNames)
        {
            var benchmarkResults = grouped[benchmarkName];
            double? baseline = benchmarkResults
                .Where(x => x.Threads == 1)
                .OrderByDescending(x => x.ScorePerSecond)
                .Select(x => (double?)x.ScorePerSecond)
                .FirstOrDefault();

            var points = new List<ScalingGraphPoint>();
            foreach (var result in benchmarkResults
                .GroupBy(x => x.Threads)
                .OrderBy(g => g.Key))
            {
                var bestAtThread = result.OrderByDescending(x => x.ScorePerSecond).First();
                double scaling = 0.0;

                if (baseline.HasValue && baseline.Value > 0.0)
                    scaling = (bestAtThread.ScorePerSecond / baseline.Value) * 100.0;
                else if (bestAtThread.Threads == 1)
                    scaling = 100.0;
                else if (bestAtThread.ScalingPercent > 0.0)
                    scaling = bestAtThread.ScalingPercent;

                if (scaling > 0.0)
                    points.Add(new ScalingGraphPoint(bestAtThread.Threads, scaling));
            }

            if (points.Count == 0)
                continue;

            series.Add(new ScalingGraphSeries
            {
                Name = benchmarkName,
                ColorIndex = series.Count,
                Points = points
            });
        }

        if (series.Count == 0)
            return null;

        var threadTicks = series
            .SelectMany(x => x.Points)
            .Select(x => x.Threads)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        double maxScaling = series
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        string subtitle =
            $"Session: {sessionId}   |   System: {Environment.MachineName}   |   Preset: {presetLabel}   |   Placement: {placementLabel}   |   Profile: {report.CapabilitySummary}";

        return new ScalingGraphSnapshot
        {
            SessionId = sessionId,
            Title = $"Key benchmark scaling by thread count ({report.VisibleThreads} visible threads, best fit: {scoring.BestFitTitle})",
            Subtitle = subtitle,
            Series = series,
            ThreadTicks = threadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private static string SanitizeFileName(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "session";

        foreach (char invalid in Path.GetInvalidFileNameChars())
            value = value.Replace(invalid, '-');

        return value.Replace(' ', '-');
    }
}

internal static class ScalingGraphRenderer
{
    private static readonly Color[] SeriesColors =
    [
        Color.FromArgb(31, 119, 180),
        Color.FromArgb(255, 127, 14),
        Color.FromArgb(44, 160, 44),
        Color.FromArgb(214, 39, 40),
        Color.FromArgb(148, 103, 189),
        Color.FromArgb(140, 86, 75),
        Color.FromArgb(227, 119, 194),
        Color.FromArgb(127, 127, 127),
        Color.FromArgb(188, 189, 34),
        Color.FromArgb(23, 190, 207)
    ];

    public static Color GetSeriesColor(int seriesIndex)
    {
        if (seriesIndex < 0)
            seriesIndex = 0;

        return SeriesColors[seriesIndex % SeriesColors.Length];
    }

    public static Bitmap CreateBitmap(ScalingGraphSnapshot snapshot, Size size)
    {
        int width = Math.Max(1200, size.Width);
        int height = Math.Max(700, size.Height);

        var bitmap = new Bitmap(width, height);
        using var graphics = Graphics.FromImage(bitmap);
        Draw(graphics, new Rectangle(0, 0, width, height), snapshot);
        return bitmap;
    }

    public static void SavePng(ScalingGraphSnapshot snapshot, string path, Size size)
    {
        using var bitmap = CreateBitmap(snapshot, size);
        bitmap.Save(path, ImageFormat.Png);
    }

    public static void Draw(Graphics graphics, Rectangle bounds, ScalingGraphSnapshot snapshot)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        graphics.Clear(Color.FromArgb(245, 245, 245));

        using var titleFont = new Font("Segoe UI Semibold", 20F, FontStyle.Bold, GraphicsUnit.Point);
        using var subtitleFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var axisFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var tickFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        using var legendFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

        int titleTop = bounds.Top + 18;
        int subtitleTop = titleTop + 42;
        int leftMargin = bounds.Left + 92;
        int rightMargin = bounds.Right - 30;
        int topMargin = bounds.Top + 110;
        int bottomMargin = bounds.Bottom - 92;
        int legendWidth = 300;

        Rectangle plotRect = new(leftMargin, topMargin, Math.Max(300, rightMargin - leftMargin - legendWidth), Math.Max(260, bottomMargin - topMargin));
        Rectangle legendRect = new(plotRect.Right + 18, plotRect.Top + 8, Math.Max(200, rightMargin - (plotRect.Right + 18)), Math.Min(plotRect.Height - 16, 320));

        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
        using var subtitleBrush = new SolidBrush(Color.FromArgb(80, 80, 80));
        using var axisBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var gridPen = new Pen(Color.FromArgb(214, 214, 214), 1F);
        using var axisPen = new Pen(Color.FromArgb(60, 60, 60), 1.2F);

        var centerFormat = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        var rightFormat = new StringFormat { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center };

        graphics.DrawString(snapshot.Title, titleFont, titleBrush, new RectangleF(bounds.Left + 20, titleTop, bounds.Width - 40, 34), centerFormat);
        graphics.DrawString(snapshot.Subtitle, subtitleFont, subtitleBrush, new RectangleF(bounds.Left + 28, subtitleTop, bounds.Width - 56, 34), centerFormat);

        graphics.FillRectangle(Brushes.White, plotRect);
        graphics.DrawRectangle(Pens.LightGray, plotRect);

        int yTickCount = 6;
        double yMax = Math.Max(100.0, snapshot.MaxScalingPercent);
        for (int i = 0; i <= yTickCount; i++)
        {
            double value = yMax * i / yTickCount;
            int y = plotRect.Bottom - (int)Math.Round((value / yMax) * plotRect.Height);
            graphics.DrawLine(gridPen, plotRect.Left, y, plotRect.Right, y);
            graphics.DrawString($"{value:N0}", tickFont, axisBrush, new RectangleF(bounds.Left + 10, y - 12, leftMargin - bounds.Left - 18, 24), rightFormat);
        }

        int xCount = snapshot.ThreadTicks.Count;
        if (xCount == 1)
        {
            int x = plotRect.Left + plotRect.Width / 2;
            graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
            graphics.DrawString(snapshot.ThreadTicks[0].ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
        }
        else
        {
            for (int i = 0; i < xCount; i++)
            {
                int tick = snapshot.ThreadTicks[i];
                float ratio = xCount <= 1 ? 0.5F : (float)i / (xCount - 1);
                int x = plotRect.Left + (int)Math.Round(ratio * plotRect.Width);
                graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
                graphics.DrawString(tick.ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
            }
        }

        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Bottom, plotRect.Right, plotRect.Bottom);
        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Top, plotRect.Left, plotRect.Bottom);
        graphics.DrawString("Threads", axisFont, axisBrush, new RectangleF(plotRect.Left, plotRect.Bottom + 40, plotRect.Width, 22), centerFormat);

        graphics.TranslateTransform(bounds.Left + 24, plotRect.Top + (plotRect.Height / 2));
        graphics.RotateTransform(-90F);
        graphics.DrawString("Scaling vs 1-thread baseline (%)", axisFont, axisBrush, new RectangleF(-plotRect.Height / 2, -18, plotRect.Height, 22), centerFormat);
        graphics.ResetTransform();

        var threadIndex = snapshot.ThreadTicks
            .Select((value, index) => (value, index))
            .ToDictionary(x => x.value, x => x.index);

        for (int seriesIndex = 0; seriesIndex < snapshot.Series.Count; seriesIndex++)
        {
            var series = snapshot.Series[seriesIndex];
            Color color = GetSeriesColor(series.ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);
            using var labelBrush = new SolidBrush(color);

            PointF? previous = null;
            foreach (var point in series.Points.OrderBy(x => x.Threads))
            {
                if (!threadIndex.TryGetValue(point.Threads, out int index))
                    continue;

                float xRatio = xCount <= 1 ? 0.5F : (float)index / (xCount - 1);
                float x = plotRect.Left + (xRatio * plotRect.Width);
                float y = plotRect.Bottom - (float)((point.ScalingPercent / yMax) * plotRect.Height);
                var current = new PointF(x, y);

                if (previous.HasValue)
                    graphics.DrawLine(linePen, previous.Value, current);

                graphics.FillEllipse(pointBrush, x - 5, y - 5, 10, 10);
                previous = current;
            }
        }

        DrawLegend(graphics, legendRect, snapshot.Series, legendFont);
    }

    private static void DrawLegend(Graphics graphics, Rectangle legendRect, IReadOnlyList<ScalingGraphSeries> series, Font legendFont)
    {
        if (series.Count == 0)
            return;

        using var backgroundBrush = new SolidBrush(Color.FromArgb(246, 246, 246));
        using var borderPen = new Pen(Color.FromArgb(190, 190, 190), 1F);
        using var textBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));

        graphics.FillRectangle(backgroundBrush, legendRect);
        graphics.DrawRectangle(borderPen, legendRect);
        using var legendTitleFont = new Font(legendFont, FontStyle.Bold);
        graphics.DrawString("Benchmarks", legendTitleFont, titleBrush, legendRect.Left + 12, legendRect.Top + 12);

        int y = legendRect.Top + 42;
        for (int i = 0; i < series.Count; i++)
        {
            Color color = GetSeriesColor(series[i].ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);
            graphics.DrawLine(linePen, legendRect.Left + 14, y + 7, legendRect.Left + 42, y + 7);
            graphics.FillEllipse(pointBrush, legendRect.Left + 24, y + 2, 10, 10);
            graphics.DrawString(series[i].Name, legendFont, textBrush, new RectangleF(legendRect.Left + 50, y - 2, legendRect.Width - 60, 20));
            y += 28;
            if (y > legendRect.Bottom - 26)
                break;
        }
    }
}

internal sealed class DoubleBufferedPanel : Panel
{
    public DoubleBufferedPanel()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
    }
}

public sealed class ScalingGraphForm : Form
{
    private readonly ScalingGraphSnapshot _snapshot;
    private readonly DoubleBufferedPanel _graphPanel = new();
    private readonly FlowLayoutPanel _seriesButtonHost = new();
    private readonly Dictionary<string, Button> _seriesButtons = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _visibleSeries = new(StringComparer.OrdinalIgnoreCase);
    private readonly Label _selectionLabel = new();

    public ScalingGraphForm(ScalingGraphSnapshot snapshot)
    {
        _snapshot = snapshot;
        foreach (var series in snapshot.Series)
            _visibleSeries.Add(series.Name);

        Text = "Thread Scaling Graph";
        AppVisuals.TryApplyWindowIcon(this);
        StartPosition = FormStartPosition.CenterParent;
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1000, 700);
        BackColor = Color.White;
        KeyPreview = true;
        KeyDown += ScalingGraphForm_KeyDown;

        var headerHost = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.FromArgb(35, 41, 59),
            Padding = new Padding(14, 10, 14, 10),
            Margin = new Padding(0)
        };
        headerHost.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var topBar = new Panel
        {
            Dock = DockStyle.Top,
            Height = 36,
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };
        headerHost.Controls.Add(topBar, 0, 0);

        var closeButton = new Button
        {
            Text = "Close",
            Dock = DockStyle.Right,
            Width = 110,
            Height = 34,
            BackColor = Color.FromArgb(229, 77, 66),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0)
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (_, _) => Close();
        topBar.Controls.Add(closeButton);

        var hintLabel = new Label
        {
            Dock = DockStyle.Fill,
            Text = "Fullscreen scaling graph preview. Click a benchmark button to hide or show that line. Press Esc or use Close.",
            ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleLeft,
            AutoEllipsis = true
        };
        topBar.Controls.Add(hintLabel);

        var controlsHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 10, 0, 0),
            Padding = new Padding(0)
        };
        headerHost.Controls.Add(controlsHost, 0, 1);

        var showAllButton = CreateCommandButton("Show All", Color.FromArgb(37, 99, 235));
        showAllButton.Click += (_, _) => SetAllSeriesVisibility(true);
        controlsHost.Controls.Add(showAllButton);

        var hideAllButton = CreateCommandButton("Hide All", Color.FromArgb(71, 85, 105));
        hideAllButton.Click += (_, _) => SetAllSeriesVisibility(false);
        controlsHost.Controls.Add(hideAllButton);

        _selectionLabel.AutoSize = true;
        _selectionLabel.ForeColor = Color.White;
        _selectionLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
        _selectionLabel.Margin = new Padding(6, 9, 12, 0);
        controlsHost.Controls.Add(_selectionLabel);

        _seriesButtonHost.AutoSize = true;
        _seriesButtonHost.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        _seriesButtonHost.WrapContents = true;
        _seriesButtonHost.FlowDirection = FlowDirection.LeftToRight;
        _seriesButtonHost.BackColor = Color.Transparent;
        _seriesButtonHost.Margin = new Padding(0);
        _seriesButtonHost.Padding = new Padding(0);
        controlsHost.Controls.Add(_seriesButtonHost);

        BuildSeriesButtons();
        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();

        _graphPanel.Dock = DockStyle.Fill;
        _graphPanel.Paint += (_, e) => DrawGraphPanel(e.Graphics);
        Controls.Add(_graphPanel);
        Controls.Add(headerHost);
    }

    private static Button CreateCommandButton(string text, Color backColor)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Height = 34,
            Padding = new Padding(12, 4, 12, 4),
            FlatStyle = FlatStyle.Flat,
            BackColor = backColor,
            ForeColor = Color.White,
            Margin = new Padding(0, 0, 8, 8)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void BuildSeriesButtons()
    {
        _seriesButtonHost.Controls.Clear();
        _seriesButtons.Clear();

        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            var button = new Button
            {
                Text = series.Name,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Height = 34,
                Padding = new Padding(12, 4, 12, 4),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 0, 8, 8),
                UseVisualStyleBackColor = false
            };

            string seriesName = series.Name;
            button.Click += (_, _) => ToggleSeries(seriesName);
            _seriesButtonHost.Controls.Add(button);
            _seriesButtons[seriesName] = button;
        }
    }

    private void ToggleSeries(string seriesName)
    {
        if (_visibleSeries.Contains(seriesName))
            _visibleSeries.Remove(seriesName);
        else
            _visibleSeries.Add(seriesName);

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        _graphPanel.Invalidate();
    }

    private void SetAllSeriesVisibility(bool visible)
    {
        _visibleSeries.Clear();
        if (visible)
        {
            foreach (var series in _snapshot.Series)
                _visibleSeries.Add(series.Name);
        }

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        _graphPanel.Invalidate();
    }

    private void UpdateSelectionLabel()
    {
        _selectionLabel.Text = $"Shown: {_visibleSeries.Count} of {_snapshot.Series.Count}";
    }

    private void UpdateSeriesButtonStyles()
    {
        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            if (!_seriesButtons.TryGetValue(series.Name, out var button))
                continue;

            bool isVisible = _visibleSeries.Contains(series.Name);
            Color seriesColor = ScalingGraphRenderer.GetSeriesColor(series.ColorIndex);
            ApplySeriesButtonStyle(button, seriesColor, isVisible);
        }
    }

    private static void ApplySeriesButtonStyle(Button button, Color seriesColor, bool isVisible)
    {
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = seriesColor;

        if (isVisible)
        {
            button.BackColor = seriesColor;
            button.ForeColor = Color.White;
            button.Text = button.Text.StartsWith("✕ ", StringComparison.Ordinal) ? button.Text[2..] : button.Text;
        }
        else
        {
            button.BackColor = Color.FromArgb(245, 247, 250);
            button.ForeColor = Color.FromArgb(55, 65, 81);
            if (!button.Text.StartsWith("✕ ", StringComparison.Ordinal))
                button.Text = "✕ " + button.Text;
        }
    }

    private void DrawGraphPanel(Graphics graphics)
    {
        var snapshot = BuildVisibleSnapshot();
        if (snapshot.Series.Count == 0)
        {
            graphics.Clear(Color.White);
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            using var titleFont = new Font("Segoe UI Semibold", 22F, FontStyle.Bold, GraphicsUnit.Point);
            using var bodyFont = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
            using var bodyBrush = new SolidBrush(Color.FromArgb(90, 90, 90));
            var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };

            graphics.DrawString("No graph lines are currently visible", titleFont, titleBrush, _graphPanel.ClientRectangle, center);
            var subtitleRect = new RectangleF(0, (_graphPanel.ClientRectangle.Height / 2F) + 28F, _graphPanel.ClientRectangle.Width, 40F);
            graphics.DrawString("Use the buttons at the top to turn one or more benchmark series back on.", bodyFont, bodyBrush, subtitleRect, center);
            return;
        }

        ScalingGraphRenderer.Draw(graphics, _graphPanel.ClientRectangle, snapshot);
    }

    private ScalingGraphSnapshot BuildVisibleSnapshot()
    {
        var visibleSeries = _snapshot.Series
            .Where(series => _visibleSeries.Contains(series.Name))
            .ToArray();

        if (visibleSeries.Length == 0)
        {
            return new ScalingGraphSnapshot
            {
                SessionId = _snapshot.SessionId,
                Title = _snapshot.Title,
                Subtitle = _snapshot.Subtitle,
                Series = Array.Empty<ScalingGraphSeries>(),
                ThreadTicks = _snapshot.ThreadTicks,
                MaxScalingPercent = Math.Max(200.0, _snapshot.MaxScalingPercent)
            };
        }

        double maxScaling = visibleSeries
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        return new ScalingGraphSnapshot
        {
            SessionId = _snapshot.SessionId,
            Title = _snapshot.Title,
            Subtitle = _snapshot.Subtitle,
            Series = visibleSeries,
            ThreadTicks = _snapshot.ThreadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private void ScalingGraphForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            e.Handled = true;
            Close();
        }
    }
}
