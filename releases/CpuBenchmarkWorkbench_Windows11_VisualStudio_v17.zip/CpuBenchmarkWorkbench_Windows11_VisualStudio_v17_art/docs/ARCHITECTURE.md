# CPU Benchmark Workbench architecture notes

This document is meant to help people learn from the codebase, not just build it.

## Project layout

- `CpuBenchmarkWorkbench.sln`  
  Visual Studio solution file.

- `src/CpuBenchmarkWorkbench/CpuBenchmarkWorkbench.csproj`  
  Main WinForms project.

- `src/CpuBenchmarkWorkbench/Program.cs`  
  Application entry point and top-level exception handling.

- `src/CpuBenchmarkWorkbench/MainForm.cs`  
  Main window, layout, benchmark execution flow, result grid, CSV export, and UI commands.

- `src/CpuBenchmarkWorkbench/Benchmarks.cs`  
  Benchmark catalog, benchmark engine, and individual benchmark worker implementations.

- `src/CpuBenchmarkWorkbench/Models.cs`  
  Shared models, capability reporting, metric formatting, and system-info helpers.

- `src/CpuBenchmarkWorkbench/AboutForm.cs`  
  About dialog and MIT license text.

- `src/CpuBenchmarkWorkbench/HelpGuideForm.cs`  
  Built-in help system.

- `src/CpuBenchmarkWorkbench/StartupDiagnostics.cs`  
  Startup logging used when something goes wrong early.

- `src/CpuBenchmarkWorkbench/AppVisuals.cs`  
  Shared icon-loading helper so forms use the same branding.

- `src/CpuBenchmarkWorkbench/Assets/`  
  Icon and image assets.

## How the benchmark flow works

1. The app builds a machine capability report.
2. The benchmark catalog uses that report to decide which tests should appear.
3. The user chooses benchmarks, a preset, and a thread count.
4. The benchmark engine creates one worker per selected thread.
5. Each worker repeatedly performs a batch of work until the target time is reached.
6. The engine totals the work, divides by elapsed time, and formats the result.

## Why Smart Sweep exists

Many machines expose a high thread count. Running every thread value from 1 to the maximum can
turn a quick comparison into a very long session. Smart Sweep samples:

- 1 thread
- 25%
- 50%
- 75%
- 100%

That gives a useful scaling curve with far less waiting.

## Why some benchmarks appear only on some systems

This project uses feature-aware testing. If the runtime or hardware does not expose a capability,
the matching benchmark is hidden instead of being shown and then failing.

Examples:
- AVX2 / FMA benchmark only when AVX2 and FMA are both reported
- AVX-512 benchmark only when an AVX-512 family is reported
- AES benchmark only when AES acceleration is reported

## UI design goals

The UI was built to stay readable across:
- normal desktops
- gaming PCs
- high-DPI laptops
- workstations
- servers with lots of threads

That is why the left sidebar uses cards, auto-sizing layout, and a guarded splitter strategy.

## Asset design goals

The icon is intentionally simple:
- a CPU package for hardware identity
- chart bars for benchmarking
- strong contrast for Windows taskbar visibility

Contributors can swap the icon by replacing the primary `.ico` in `Assets` and keeping the same filename.
