# CPU Benchmark Workbench

CPU Benchmark Workbench is a Windows 11 / Visual Studio WinForms desktop app for comparing many different CPU behaviors instead of only one score.

## Highlights in v13

- clean left/right layout with visible controls
- dynamic benchmark catalog based on detected runtime CPU features
- scalar tests for integer, floating point, branches, primes, and mixed workloads
- memory tests for bandwidth and cache-latency style behavior
- SIMD test using portable `Vector<T>`
- AVX2/FMA benchmark when supported
- AVX-512 benchmark when supported
- AES benchmark when supported
- single-run mode, Smart Sweep mode, and Burn-In mode
- built-in Help Guide
- built-in About + MIT License dialog
- CSV export and copyable system capability report

## Included benchmark families

- Integer Mix
- Bit Twister
- Floating Point Mix
- Branch Chaos
- Cache Walker
- SIMD Vector Math
- AVX2 / FMA Float32 *(when supported)*
- AVX-512 Wide Float32 *(when supported)*
- AES Blocks *(when supported)*
- Memory Stream
- Matrix Multiply
- Prime Scan
- Mandelbrot

## Burn-In mode

Burn-In repeatedly cycles through the checked benchmarks for the selected number of minutes or until Stop is pressed. It is intended for longer thermal and stability testing.

## Open in Visual Studio

Open:
- `CpuBenchmarkWorkbench.sln`

Or directly open:
- `src/CpuBenchmarkWorkbench/CpuBenchmarkWorkbench.csproj`

## License

MIT License. See `LICENSE.txt`.


Compatibility note for v16: this build stays on the stable v14 layout/code path to avoid compiler-specific int/uint issues seen in a later UI polish pass.
