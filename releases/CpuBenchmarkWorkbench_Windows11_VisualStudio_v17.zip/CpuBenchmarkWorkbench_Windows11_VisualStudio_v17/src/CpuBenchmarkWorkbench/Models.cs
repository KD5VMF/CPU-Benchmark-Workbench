using System.Numerics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.X86;

namespace CpuBenchmarkWorkbench;

public enum BenchmarkPreset
{
    Quick,
    Standard,
    Heavy,
    Extreme
}

public enum MetricKind
{
    IntegerOps,
    FloatingOps,
    Bytes,
    Numbers,
    Pixels,
    Blocks,
    Accesses
}

public static class BenchmarkPresetExtensions
{
    public static string DisplayName(this BenchmarkPreset preset) => preset switch
    {
        BenchmarkPreset.Quick => "Quick",
        BenchmarkPreset.Standard => "Standard",
        BenchmarkPreset.Heavy => "Heavy",
        BenchmarkPreset.Extreme => "Extreme",
        _ => preset.ToString()
    };

    public static double TargetSeconds(this BenchmarkPreset preset) => preset switch
    {
        BenchmarkPreset.Quick => 1.25,
        BenchmarkPreset.Standard => 2.75,
        BenchmarkPreset.Heavy => 6.0,
        BenchmarkPreset.Extreme => 12.0,
        _ => 2.75
    };
}

public static class MetricFormatting
{
    public static string Format(MetricKind kind, double valuePerSecond)
    {
        return kind switch
        {
            MetricKind.IntegerOps => FormatScaled(valuePerSecond, "ops/s"),
            MetricKind.FloatingOps => FormatScaled(valuePerSecond, "FLOP/s"),
            MetricKind.Bytes => FormatBytesPerSecond(valuePerSecond),
            MetricKind.Numbers => FormatScaled(valuePerSecond, "nums/s"),
            MetricKind.Pixels => FormatScaled(valuePerSecond, "px/s"),
            MetricKind.Blocks => FormatScaled(valuePerSecond, "blocks/s"),
            MetricKind.Accesses => FormatScaled(valuePerSecond, "accesses/s"),
            _ => valuePerSecond.ToString("N2")
        };
    }

    private static string FormatScaled(double value, string unit)
    {
        string[] prefixes = ["", "K", "M", "G", "T"];
        int index = 0;
        while (value >= 1000.0 && index < prefixes.Length - 1)
        {
            value /= 1000.0;
            index++;
        }

        return $"{value:N2} {prefixes[index]}{unit}";
    }

    public static string FormatBytesPerSecond(double bytesPerSecond)
    {
        string[] units = ["B/s", "KB/s", "MB/s", "GB/s", "TB/s"];
        int index = 0;
        while (bytesPerSecond >= 1024.0 && index < units.Length - 1)
        {
            bytesPerSecond /= 1024.0;
            index++;
        }

        return $"{bytesPerSecond:N2} {units[index]}";
    }
}

public sealed class BenchmarkRunOptions
{
    public BenchmarkPreset Preset { get; init; } = BenchmarkPreset.Standard;
    public int Threads { get; init; } = Environment.ProcessorCount;
    public bool Warmup { get; init; } = true;
    public double? DurationOverrideSeconds { get; init; }
}

public sealed class BenchmarkResult
{
    public DateTime StartedAt { get; set; } = DateTime.Now;
    public string Benchmark { get; set; } = string.Empty;
    public int Threads { get; set; }
    public string Preset { get; set; } = string.Empty;
    public double DurationSeconds { get; set; }
    public double ScorePerSecond { get; set; }
    public MetricKind MetricKind { get; set; }
    public double Checksum { get; set; }
    public double ScalingPercent { get; set; }
    public string Notes { get; set; } = string.Empty;

    public string TimestampDisplay => StartedAt.ToString("HH:mm:ss");
    public string DurationDisplay => $"{DurationSeconds:N2} s";
    public string ScoreDisplay => MetricFormatting.Format(MetricKind, ScorePerSecond);
    public string ScalingDisplay => ScalingPercent > 0 ? $"{ScalingPercent:N1}%" : string.Empty;
}

public interface IBenchmarkWorker
{
    void RunBatch();
    double WorkCompleted { get; }
    double Checksum { get; }
}

public abstract class BenchmarkDefinition
{
    protected BenchmarkDefinition(
        string name,
        string category,
        string description,
        MetricKind metricKind,
        string notes,
        string detailedHelp,
        string availabilityNote)
    {
        Name = name;
        Category = category;
        Description = description;
        MetricKind = metricKind;
        Notes = notes;
        DetailedHelp = detailedHelp;
        AvailabilityNote = availabilityNote;
    }

    public string Name { get; }
    public string Category { get; }
    public string Description { get; }
    public MetricKind MetricKind { get; }
    public string Notes { get; }
    public string DetailedHelp { get; }
    public string AvailabilityNote { get; }

    public abstract IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset);

    public override string ToString() => Name;
}

public sealed class CpuCapabilityReport
{
    public required string OsDescription { get; init; }
    public required string FrameworkDescription { get; init; }
    public required string ProcessArchitecture { get; init; }
    public required int VisibleThreads { get; init; }
    public required int ProcessorGroups { get; init; }
    public required int NumaNodes { get; init; }
    public required ulong InstalledMemoryBytes { get; init; }
    public required string SimdSummary { get; init; }
    public required string ExtendedFeatureSummary { get; init; }
    public required string CapabilitySummary { get; init; }
    public required bool HasVector { get; init; }
    public required bool HasSse42 { get; init; }
    public required bool HasAvx { get; init; }
    public required bool HasAvx2 { get; init; }
    public required bool HasFma { get; init; }
    public required bool HasAes { get; init; }
    public required bool HasAvxVnni { get; init; }
    public required bool HasAvx512F { get; init; }
    public required bool HasAvx512DQ { get; init; }
    public required bool HasAvx512CD { get; init; }
    public required bool HasAvx512BW { get; init; }
    public required bool HasAvx512VL { get; init; }
    public required bool HasAvx512Vbmi { get; init; }
    public required bool HasAvx512Vbmi2 { get; init; }
    public required bool HasAvx512Vnni { get; init; }

    public bool HasAnyAvx512 => HasAvx512F || HasAvx512DQ || HasAvx512CD || HasAvx512BW || HasAvx512VL || HasAvx512Vbmi || HasAvx512Vbmi2 || HasAvx512Vnni;
}

public static class SystemInfoProvider
{
    public static CpuCapabilityReport GetReport()
    {
        List<string> simd = [];
        List<string> extra = [];

        bool hasVector = Vector.IsHardwareAccelerated;
        bool hasSse42 = Sse42.IsSupported;
        bool hasAvx = Avx.IsSupported;
        bool hasAvx2 = Avx2.IsSupported;
        bool hasFma = Fma.IsSupported;
        bool hasAes = Aes.IsSupported;
        bool hasAvxVnni = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.AvxVnni");
        bool hasAvx512F = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512F");
        bool hasAvx512DQ = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512DQ");
        bool hasAvx512CD = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512CD");
        bool hasAvx512BW = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512BW");
        bool hasAvx512VL = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512VL");
        bool hasAvx512Vbmi = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512Vbmi");
        bool hasAvx512Vbmi2 = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512Vbmi2");
        bool hasAvx512Vnni = GetIntrinsicSupport("System.Runtime.Intrinsics.X86.Avx512Vnni");

        AddIf(simd, hasVector, $"Vector<{Vector<float>.Count}>");
        AddIf(simd, Sse.IsSupported, "SSE");
        AddIf(simd, Sse2.IsSupported, "SSE2");
        AddIf(simd, Sse3.IsSupported, "SSE3");
        AddIf(simd, Ssse3.IsSupported, "SSSE3");
        AddIf(simd, Sse41.IsSupported, "SSE4.1");
        AddIf(simd, hasSse42, "SSE4.2");
        AddIf(simd, hasAvx, "AVX");
        AddIf(simd, hasAvx2, "AVX2");
        AddIf(simd, hasFma, "FMA");
        AddIf(simd, hasAvxVnni, "AVX-VNNI");
        AddIf(simd, hasAvx512F, "AVX512F");
        AddIf(simd, hasAvx512DQ, "AVX512DQ");
        AddIf(simd, hasAvx512CD, "AVX512CD");
        AddIf(simd, hasAvx512BW, "AVX512BW");
        AddIf(simd, hasAvx512VL, "AVX512VL");
        AddIf(simd, hasAvx512Vbmi, "AVX512VBMI");
        AddIf(simd, hasAvx512Vbmi2, "AVX512VBMI2");
        AddIf(simd, hasAvx512Vnni, "AVX512VNNI");

        AddIf(extra, hasAes, "AES");
        AddIf(extra, Pclmulqdq.IsSupported, "PCLMULQDQ");
        AddIf(extra, Popcnt.IsSupported, "POPCNT");
        AddIf(extra, Lzcnt.IsSupported, "LZCNT");
        AddIf(extra, Bmi1.IsSupported, "BMI1");
        AddIf(extra, Bmi2.IsSupported, "BMI2");
        AddIf(extra, X86Base.IsSupported, "x86 base intrinsics");
        AddIf(extra, X86Base.X64.IsSupported, "x64 intrinsics");

        ulong memory = GetTotalMemoryBytes();
        int numaNodes = GetNumaNodeCount();
        int processorGroups = GetProcessorGroupCount();

        string capabilitySummary = BuildCapabilitySummary(simd, extra, numaNodes, processorGroups);

        return new CpuCapabilityReport
        {
            OsDescription = RuntimeInformation.OSDescription,
            FrameworkDescription = RuntimeInformation.FrameworkDescription,
            ProcessArchitecture = RuntimeInformation.ProcessArchitecture.ToString(),
            VisibleThreads = Environment.ProcessorCount,
            ProcessorGroups = processorGroups,
            NumaNodes = numaNodes,
            InstalledMemoryBytes = memory,
            SimdSummary = simd.Count > 0 ? string.Join(", ", simd) : "Scalar path only",
            ExtendedFeatureSummary = extra.Count > 0 ? string.Join(", ", extra) : "No extra x86 feature flags exposed",
            CapabilitySummary = capabilitySummary,
            HasVector = hasVector,
            HasSse42 = hasSse42,
            HasAvx = hasAvx,
            HasAvx2 = hasAvx2,
            HasFma = hasFma,
            HasAes = hasAes,
            HasAvxVnni = hasAvxVnni,
            HasAvx512F = hasAvx512F,
            HasAvx512DQ = hasAvx512DQ,
            HasAvx512CD = hasAvx512CD,
            HasAvx512BW = hasAvx512BW,
            HasAvx512VL = hasAvx512VL,
            HasAvx512Vbmi = hasAvx512Vbmi,
            HasAvx512Vbmi2 = hasAvx512Vbmi2,
            HasAvx512Vnni = hasAvx512Vnni
        };
    }

    public static string BuildSummary(CpuCapabilityReport? cachedReport = null)
    {
        var report = cachedReport ?? GetReport();
        return string.Join(Environment.NewLine, new[]
        {
            $"OS: {report.OsDescription}",
            $".NET: {report.FrameworkDescription}",
            $"Process arch: {report.ProcessArchitecture}",
            $"Visible threads: {report.VisibleThreads}",
            $"Processor groups: {report.ProcessorGroups}",
            $"NUMA nodes: {report.NumaNodes}",
            $"Installed memory: {FormatBytes(report.InstalledMemoryBytes)}",
            $"SIMD / ISA: {report.SimdSummary}",
            $"Other CPU features: {report.ExtendedFeatureSummary}",
            $"Profile: {report.CapabilitySummary}"
        });
    }

    public static string BuildClipboardReport(CpuCapabilityReport? cachedReport = null)
    {
        var report = cachedReport ?? GetReport();
        return string.Join(Environment.NewLine, new[]
        {
            "CPU Benchmark Workbench - System Capability Report",
            $"Generated: {DateTime.Now:F}",
            string.Empty,
            $"OS: {report.OsDescription}",
            $".NET: {report.FrameworkDescription}",
            $"Process architecture: {report.ProcessArchitecture}",
            $"Visible threads: {report.VisibleThreads}",
            $"Processor groups: {report.ProcessorGroups}",
            $"NUMA nodes: {report.NumaNodes}",
            $"Installed memory: {FormatBytes(report.InstalledMemoryBytes)}",
            $"SIMD / ISA flags: {report.SimdSummary}",
            $"Other CPU feature flags: {report.ExtendedFeatureSummary}",
            $"Capability profile: {report.CapabilitySummary}",
            string.Empty,
            "Suggested tests:",
            "- Integer Mix + Bit Twister for scalar integer and bit handling",
            "- SIMD Vector Math + AVX2/FMA or AVX-512 when available for vector lanes",
            "- AES Blocks when AES-NI is exposed",
            "- Memory Stream + Cache Walker for bandwidth and cache behavior",
            "- Matrix Multiply + Floating Point Mix for sustained math throughput",
            "- Prime Scan + Branch Chaos for branch-heavy and irregular control flow",
            "- Burn-In Run for longer thermal and stability testing"
        });
    }

    public static string BuildFeatureHighlights(CpuCapabilityReport report)
    {
        List<string> highlights = [];
        if (report.HasAnyAvx512)
            highlights.Add("AVX-512 wide-vector benchmark available");
        else if (report.HasAvx2 && report.HasFma)
            highlights.Add("AVX2/FMA benchmark available");
        else if (report.HasAvx2)
            highlights.Add("AVX2-class machine detected");
        else if (report.HasAvx)
            highlights.Add("AVX-era machine detected");
        else if (report.HasSse42)
            highlights.Add("SSE4.2-era machine detected");
        else
            highlights.Add("legacy scalar-biased machine profile");

        if (report.HasAes)
            highlights.Add("AES-NI test available");
        if (report.NumaNodes > 1)
            highlights.Add($"multi-NUMA topology ({report.NumaNodes} nodes)");
        if (report.ProcessorGroups > 1)
            highlights.Add($"multiple processor groups ({report.ProcessorGroups})");
        highlights.Add($"{report.VisibleThreads} visible thread(s)");

        return string.Join(" | ", highlights);
    }

    private static string BuildCapabilitySummary(List<string> simd, List<string> extra, int numaNodes, int processorGroups)
    {
        bool hasAvx512 = simd.Any(x => x.StartsWith("AVX512", StringComparison.OrdinalIgnoreCase) || x.StartsWith("AVX-512", StringComparison.OrdinalIgnoreCase));
        bool hasAvx2 = simd.Any(x => x.Equals("AVX2", StringComparison.OrdinalIgnoreCase));
        bool hasAvx = simd.Any(x => x.Equals("AVX", StringComparison.OrdinalIgnoreCase));
        bool hasSse42 = simd.Any(x => x.Equals("SSE4.2", StringComparison.OrdinalIgnoreCase));

        string cpuTier = hasAvx512 ? "advanced wide-vector CPU" :
                         hasAvx2 ? "strong modern vector CPU" :
                         hasAvx ? "mid-generation AVX CPU" :
                         hasSse42 ? "older but capable SSE4-era CPU" :
                         "legacy / scalar-biased CPU";

        string topology = numaNodes > 1 ? $", multi-NUMA ({numaNodes} nodes)" : ", single NUMA domain";
        if (processorGroups > 1)
            topology += $", multi-group ({processorGroups} groups)";

        string extras = extra.Count > 0 ? $", extras: {string.Join('/', extra.Take(4))}" : string.Empty;
        return cpuTier + topology + extras;
    }

    private static void AddIf(List<string> list, bool condition, string name)
    {
        if (condition)
            list.Add(name);
    }

    private static bool GetIntrinsicSupport(string typeName)
    {
        try
        {
            Type? type = Type.GetType(typeName + ", System.Private.CoreLib", throwOnError: false);
            PropertyInfo? property = type?.GetProperty("IsSupported", BindingFlags.Public | BindingFlags.Static);
            return property?.GetValue(null) as bool? == true;
        }
        catch
        {
            return false;
        }
    }

    public static string FormatBytes(ulong value)
    {
        double scaled = value;
        string[] units = ["B", "KB", "MB", "GB", "TB"];
        int index = 0;
        while (scaled >= 1024.0 && index < units.Length - 1)
        {
            scaled /= 1024.0;
            index++;
        }
        return $"{scaled:N2} {units[index]}";
    }

    private static ulong GetTotalMemoryBytes()
    {
        MEMORYSTATUSEX status = new();
        status.dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>();
        return GlobalMemoryStatusEx(ref status) ? status.ullTotalPhys : 0;
    }

    private static int GetNumaNodeCount()
    {
        return GetNumaHighestNodeNumber(out uint highestNode) ? checked((int)highestNode + 1) : 1;
    }

    private static int GetProcessorGroupCount()
    {
        try
        {
            return GetActiveProcessorGroupCount();
        }
        catch
        {
            return 1;
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX status);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetNumaHighestNodeNumber(out uint highestNodeNumber);

    [DllImport("kernel32.dll")]
    private static extern ushort GetActiveProcessorGroupCount();
}
