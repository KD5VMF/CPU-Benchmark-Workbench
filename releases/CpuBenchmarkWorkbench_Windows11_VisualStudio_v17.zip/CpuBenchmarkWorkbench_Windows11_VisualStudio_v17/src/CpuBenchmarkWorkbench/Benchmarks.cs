using System.Collections.Concurrent;
using System.Diagnostics;
using System.Numerics;
using System.Runtime.Intrinsics;
using System.Runtime.Intrinsics.X86;

namespace CpuBenchmarkWorkbench;

public static class BenchmarkCatalog
{
    public static IReadOnlyList<BenchmarkDefinition> CreateAll(CpuCapabilityReport report)
    {
        var list = new List<BenchmarkDefinition>
        {
            new IntegerMixBenchmark(),
            new BitTwisterBenchmark(),
            new FloatingPointBenchmark(),
            new BranchChaosBenchmark(),
            new CacheWalkerBenchmark(),
            new SimdVectorBenchmark(),
            new MemoryStreamBenchmark(),
            new MatrixMultiplyBenchmark(),
            new PrimeScanBenchmark(),
            new MandelbrotBenchmark()
        };

        if (report.HasAvx2 && report.HasFma)
            list.Insert(6, new Avx2FmaBenchmark());

        if (report.HasAnyAvx512)
            list.Insert(report.HasAvx2 && report.HasFma ? 7 : 6, new Avx512WideBenchmark());

        if (report.HasAes)
            list.Insert(report.HasAnyAvx512 ? (report.HasAvx2 && report.HasFma ? 8 : 7) : (report.HasAvx2 && report.HasFma ? 7 : 6), new AesBlocksBenchmark());

        return list;
    }
}

public static class BenchmarkEngine
{
    public static Task<BenchmarkResult> RunAsync(
        BenchmarkDefinition definition,
        BenchmarkRunOptions options,
        Action<string>? log,
        CancellationToken cancellationToken)
    {
        return Task.Run(() => Run(definition, options, log, cancellationToken), cancellationToken);
    }

    private static BenchmarkResult Run(
        BenchmarkDefinition definition,
        BenchmarkRunOptions options,
        Action<string>? log,
        CancellationToken cancellationToken)
    {
        if (options.Threads < 1)
            throw new ArgumentOutOfRangeException(nameof(options.Threads));

        var startedAt = DateTime.Now;

        if (options.Warmup)
        {
            log?.Invoke($"Warmup: {definition.Name}");
            var warmup = definition.CreateWorker(0, BenchmarkPreset.Quick);
            for (int i = 0; i < 2; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                warmup.RunBatch();
            }
        }

        var workers = new IBenchmarkWorker[options.Threads];
        for (int i = 0; i < options.Threads; i++)
            workers[i] = definition.CreateWorker(i, options.Preset);

        using var startGate = new ManualResetEventSlim(false);
        var exceptions = new ConcurrentQueue<Exception>();
        double targetSeconds = options.DurationOverrideSeconds ?? options.Preset.TargetSeconds();

        var tasks = new Task[options.Threads];
        for (int i = 0; i < options.Threads; i++)
        {
            int localIndex = i;
            tasks[i] = Task.Factory.StartNew(() =>
            {
                try
                {
                    startGate.Wait(cancellationToken);
                    var sw = Stopwatch.StartNew();
                    while (!cancellationToken.IsCancellationRequested && sw.Elapsed.TotalSeconds < targetSeconds)
                    {
                        workers[localIndex].RunBatch();
                    }
                }
                catch (OperationCanceledException)
                {
                }
                catch (Exception ex)
                {
                    exceptions.Enqueue(ex);
                }
            }, cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        log?.Invoke($"Starting: {definition.Name} | Threads: {options.Threads} | Preset: {options.Preset.DisplayName()} | Target: {targetSeconds:N1}s");
        var stopwatch = Stopwatch.StartNew();
        startGate.Set();
        Task.WaitAll(tasks);
        stopwatch.Stop();

        if (!exceptions.IsEmpty)
            throw new AggregateException(exceptions);

        double totalWork = 0.0;
        double checksum = 0.0;
        foreach (var worker in workers)
        {
            totalWork += worker.WorkCompleted;
            checksum += worker.Checksum;
        }

        return new BenchmarkResult
        {
            StartedAt = startedAt,
            Benchmark = definition.Name,
            Threads = options.Threads,
            Preset = options.Preset.DisplayName(),
            DurationSeconds = stopwatch.Elapsed.TotalSeconds,
            ScorePerSecond = stopwatch.Elapsed.TotalSeconds > 0 ? totalWork / stopwatch.Elapsed.TotalSeconds : 0.0,
            MetricKind = definition.MetricKind,
            Checksum = checksum,
            Notes = definition.Notes
        };
    }
}

internal static class BenchmarkSizing
{
    public static int ByPreset(BenchmarkPreset preset, int quick, int standard, int heavy, int extreme) => preset switch
    {
        BenchmarkPreset.Quick => quick,
        BenchmarkPreset.Standard => standard,
        BenchmarkPreset.Heavy => heavy,
        BenchmarkPreset.Extreme => extreme,
        _ => standard
    };
}

internal sealed class IntegerMixBenchmark : BenchmarkDefinition
{
    public IntegerMixBenchmark() : base(
        "Integer Mix",
        "Scalar / ALU",
        "Integer-heavy arithmetic with 64-bit xor-shift style state churn.",
        MetricKind.IntegerOps,
        "Good for ALU throughput and simple thread scaling.",
        "This is a scalar integer benchmark. It keeps a small amount of hot state in registers and repeatedly mutates it with rotates, shifts, adds, multiplies, and xor patterns. It is useful when you want a baseline for ordinary integer execution without relying on special vector extensions. On gaming PCs it gives a good quick feel for general per-core snappiness. On servers and workstations it helps show how well many threads scale when the test is not bottlenecked by main memory.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private ulong _x;
        private ulong _y;
        private double _ops;

        public Worker(int workerIndex)
        {
            _x = 0x9E3779B97F4A7C15UL ^ (ulong)(workerIndex + 1);
            _y = 0xBF58476D1CE4E5B9UL + (ulong)(workerIndex * 31 + 7);
        }

        public double WorkCompleted => _ops;
        public double Checksum => _x + _y;

        public void RunBatch()
        {
            const int iterations = 300_000;
            ulong x = _x;
            ulong y = _y;
            for (int i = 0; i < iterations; i++)
            {
                x ^= x << 13;
                x ^= x >> 7;
                x ^= x << 17;
                y += 0x9E3779B97F4A7C15UL;
                y = (y * 0xBF58476D1CE4E5B9UL) ^ (x >> 3);
                x += y ^ (x << 9);
            }
            _x = x;
            _y = y;
            _ops += iterations * 12.0;
        }
    }
}

internal sealed class BitTwisterBenchmark : BenchmarkDefinition
{
    public BitTwisterBenchmark() : base(
        "Bit Twister",
        "Scalar / Bits",
        "Integer-heavy rotate, xor, popcount-style mixing over local state.",
        MetricKind.IntegerOps,
        "Useful for integer pipelines, bit manipulation, and older versus newer CPU comparisons outside pure SIMD math.",
        "This benchmark stresses bit operations more than general arithmetic. It performs rotates, xor mixing, shifts, multiplies, and popcount-friendly data churn over a local state array. It is useful when you care about tasks such as compression-style bit handling, hashing-like transforms, and branch-light integer work. It is also handy for comparing architectures where vector support differs but the scalar front end and bit-manipulation features are still important.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly ulong[] _state;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 8_192, 16_384, 32_768, 65_536);
            _state = new ulong[length];
            ulong seed = 0x9E3779B97F4A7C15UL ^ (ulong)(workerIndex + 1);
            for (int i = 0; i < _state.Length; i++)
            {
                seed ^= seed << 13;
                seed ^= seed >> 7;
                seed ^= seed << 17;
                _state[i] = seed + (ulong)i * 0xD6E8FEB86659FD93UL;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            ulong sum = 0UL;
            for (int i = 0; i < _state.Length; i++)
            {
                ulong x = _state[i];
                x ^= BitOperations.RotateLeft(x, 13);
                x += 0x9E3779B97F4A7C15UL;
                x ^= BitOperations.RotateRight(x, 7);
                x *= 0xBF58476D1CE4E5B9UL;
                x ^= x >> 29;
                x = BitOperations.RotateLeft(x, 31) ^ (x >> 11);
                _state[i] = x;
                sum ^= x;
                sum += (ulong)BitOperations.PopCount(x);
            }

            _checksum += sum;
            _work += _state.Length * 16.0;
        }
    }
}

internal sealed class FloatingPointBenchmark : BenchmarkDefinition
{
    public FloatingPointBenchmark() : base(
        "Floating Point Mix",
        "Scalar / FP",
        "Double-precision arithmetic chains for scalar floating-point throughput.",
        MetricKind.FloatingOps,
        "Useful for general FP throughput without SIMD specialization.",
        "This test stays in scalar floating point so it is a good complement to the SIMD and AVX-family tests. It chains dependent double-precision operations, which means the CPU cannot completely hide latencies by pure width alone. It is useful when comparing older CPUs, server chips, or machines where you want to see how the scalar floating-point pipelines behave under steady load.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private double _a;
        private double _b;
        private double _c;
        private double _d;
        private double _flops;

        public Worker(int workerIndex)
        {
            _a = 1.0 + workerIndex;
            _b = 0.5 + workerIndex * 0.013;
            _c = 2.0 + workerIndex * 0.017;
            _d = 3.0 + workerIndex * 0.019;
        }

        public double WorkCompleted => _flops;
        public double Checksum => _a + _b + _c + _d;

        public void RunBatch()
        {
            const int iterations = 300_000;
            double a = _a, b = _b, c = _c, d = _d;
            for (int i = 0; i < iterations; i++)
            {
                a = a * 1.000000119 + b * 0.999999713;
                b = b * 1.000000331 - c * 0.0000197;
                c = c + a * 0.000031 + d * 0.000027;
                d = d * 0.99999991 + a * b * 0.00000011 - c * 0.00000003;
            }
            _a = a; _b = b; _c = c; _d = d;
            _flops += iterations * 14.0;
        }
    }
}

internal sealed class BranchChaosBenchmark : BenchmarkDefinition
{
    public BranchChaosBenchmark() : base(
        "Branch Chaos",
        "Control Flow",
        "Irregular branch-heavy integer work across a changing control pattern.",
        MetricKind.Numbers,
        "Useful for branch predictor behavior and mixed instruction flow.",
        "This benchmark intentionally creates hard-to-predict branches over a local integer array. That makes it useful for testing branch predictors, front-end recovery behavior, and code with irregular control flow. It is a good partner for Prime Scan because both are branchy, but this one is less mathematical and more about unpredictable decision paths.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int[] _state;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 32_768, 65_536, 131_072, 262_144);
            _state = new int[length];
            uint seed = unchecked(0x12345678u + ((uint)workerIndex * 7919u));
            for (int i = 0; i < _state.Length; i++)
            {
                seed = 1664525u * seed + 1013904223u;
                _state[i] = unchecked((int)seed);
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            long sum = 0;
            for (int i = 0; i < _state.Length; i++)
            {
                int x = _state[i];
                if ((x & 1) == 0)
                    x = (x << 1) ^ 0x5A5A5A5A;
                else if ((x & 2) == 0)
                    x = (x >> 1) + 0x13579BDF;
                else if ((x & 4) == 0)
                    x = unchecked((int)BitOperations.RotateLeft((uint)x, 7)) ^ 0x2468ACE;
                else
                    x = unchecked(x * 1664525 + 1013904223);

                if ((x & 8) != 0)
                    x ^= unchecked((int)BitOperations.RotateRight((uint)x, 11));
                else
                    x += (x >> 5);

                _state[i] = x;
                sum += x;
            }

            _checksum += sum;
            _work += _state.Length;
        }
    }
}

internal sealed class CacheWalkerBenchmark : BenchmarkDefinition
{
    public CacheWalkerBenchmark() : base(
        "Cache Walker",
        "Memory / Cache",
        "Pointer-chasing style random access over a larger working set.",
        MetricKind.Accesses,
        "Useful for cache hierarchy, latency, and data-locality comparisons.",
        "This benchmark walks memory through an indirection table instead of a simple linear copy. That makes it much less friendly to caches and prefetchers than Memory Stream. It is useful when you want to compare CPUs or platforms for latency-sensitive work, irregular data structures, or cache-miss-heavy server-side logic. It is especially helpful next to Memory Stream because the two together show bandwidth versus latency behavior.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int[] _next;
        private readonly long[] _values;
        private int _index;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 1 << 18, 1 << 20, 1 << 21, 1 << 22);
            _next = new int[length];
            _values = new long[length];

            for (int i = 0; i < length; i++)
            {
                _next[i] = i;
                _values[i] = i * 17L + workerIndex;
            }

            uint seed = unchecked(((uint)workerIndex + 1u) * 2654435761u);
            for (int i = length - 1; i > 0; i--)
            {
                seed = 1664525u * seed + 1013904223u;
                int j = (int)(seed % (uint)(i + 1));
                (_next[i], _next[j]) = (_next[j], _next[i]);
            }

            for (int i = 0; i < length - 1; i++)
                _next[_next[i]] = _next[i + 1];
            _next[_next[length - 1]] = _next[0];
            _index = _next[0];
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            int idx = _index;
            long sum = 0;
            const int iterations = 300_000;
            for (int i = 0; i < iterations; i++)
            {
                idx = _next[idx];
                long value = _values[idx];
                value ^= idx;
                value += (value << 3);
                _values[idx] = value;
                sum += value;
            }

            _index = idx;
            _checksum += sum;
            _work += iterations;
        }
    }
}

internal sealed class SimdVectorBenchmark : BenchmarkDefinition
{
    public SimdVectorBenchmark() : base(
        "SIMD Vector Math",
        "SIMD / Portable",
        "Vectorized single-precision math using System.Numerics.Vector.",
        MetricKind.FloatingOps,
        "Shows how well the runtime's portable SIMD plus thread scaling work together.",
        "This benchmark uses the portable Vector<T> API instead of a fixed-width ISA-specific path. That means it adapts across different CPUs and is a good general SIMD reference even on machines that do not expose AVX2 or AVX-512. It is often the fairest cross-generation vector test in the whole app because it reflects what many high-level .NET workloads actually get from the runtime.",
        "Available whenever the runtime can execute the benchmark. It still runs on older systems, but results are strongest on hardware-accelerated SIMD paths.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly float[] _a;
        private readonly float[] _b;
        private readonly float[] _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 65_536, 131_072, 262_144, 524_288);
            _a = new float[length];
            _b = new float[length];
            _c = new float[length];
            for (int i = 0; i < length; i++)
            {
                _a[i] = 1.0f + workerIndex + (i % 97) * 0.01f;
                _b[i] = 0.5f + (i % 53) * 0.02f;
                _c[i] = 0.25f + (i % 29) * 0.03f;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            int vectorWidth = Vector<float>.Count;
            int i = 0;
            Vector<float> gain = new(1.00011f);
            Vector<float> blend = new(0.00017f);
            Vector<float> acc = Vector<float>.Zero;
            for (; i <= _a.Length - vectorWidth; i += vectorWidth)
            {
                var va = new Vector<float>(_a, i);
                var vb = new Vector<float>(_b, i);
                var vc = new Vector<float>(_c, i);
                va = va * gain + vb;
                vb = vb - vc * blend;
                vc = va + vb * new Vector<float>(0.5f);
                va.CopyTo(_a, i);
                vb.CopyTo(_b, i);
                vc.CopyTo(_c, i);
                acc += va + vb + vc;
            }

            float sum = 0f;
            for (int lane = 0; lane < Vector<float>.Count; lane++)
                sum += acc[lane];

            for (; i < _a.Length; i++)
            {
                _a[i] = _a[i] * 1.00011f + _b[i];
                _b[i] = _b[i] - _c[i] * 0.00017f;
                _c[i] = _a[i] + _b[i] * 0.5f;
                sum += _a[i] + _b[i] + _c[i];
            }

            _checksum += sum;
            _work += _a.Length * 9.0;
        }
    }
}

internal sealed class Avx2FmaBenchmark : BenchmarkDefinition
{
    public Avx2FmaBenchmark() : base(
        "AVX2 / FMA Float32",
        "SIMD / AVX2",
        "ISA-specific 256-bit fused multiply-add style float math.",
        MetricKind.FloatingOps,
        "Useful for modern desktop, workstation, and server CPUs that expose AVX2 plus FMA.",
        "This benchmark is more ISA-specific than the general SIMD Vector test. It uses 256-bit AVX registers together with FMA operations when the runtime exposes them. That makes it a strong indicator of how modern vector-capable CPUs handle dense float workloads such as media transforms, physics kernels, and some numerical code. Compare it against the generic SIMD result to see whether the machine gains a lot from wide explicit vector instructions.",
        "Shown only when AVX2 and FMA are detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector256<float> _a;
        private Vector256<float> _b;
        private Vector256<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            if (!Avx2.IsSupported || !Fma.IsSupported)
                throw new PlatformNotSupportedException("AVX2/FMA benchmark requires AVX2 and FMA support.");

            _a = Vector256.Create(1.0f + workerIndex, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f);
            _b = Vector256.Create(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.25f);
            _c = Vector256.Create(0.125f, 0.25f, 0.375f, 0.5f, 0.625f, 0.75f, 0.875f, 1.0f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var k1 = Vector256.Create(1.00017f);
            var k2 = Vector256.Create(0.50011f);
            var k3 = Vector256.Create(0.00031f);
            const int iterations = 250_000;

            for (int i = 0; i < iterations; i++)
            {
                a = Fma.MultiplyAdd(a, k1, b);
                b = Fma.MultiplyAdd(b, k2, c);
                c = Fma.MultiplyAdd(a, b, k3);
                a = Avx.Add(a, c);
                b = Avx.Subtract(b, k3);
            }

            Span<float> lanesA = stackalloc float[Vector256<float>.Count];
            Span<float> lanesB = stackalloc float[Vector256<float>.Count];
            Span<float> lanesC = stackalloc float[Vector256<float>.Count];
            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            double sum = 0.0;
            for (int lane = 0; lane < Vector256<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = a;
            _b = b;
            _c = c;
            _checksum += sum;
            _work += iterations * Vector256<float>.Count * 16.0;
        }
    }
}

internal sealed class Avx512WideBenchmark : BenchmarkDefinition
{
    public Avx512WideBenchmark() : base(
        "AVX-512 Wide Float32",
        "SIMD / AVX-512",
        "Wide 512-bit float vector math for CPUs that expose AVX-512 through the runtime.",
        MetricKind.FloatingOps,
        "Useful for high-end workstation and server chips with AVX-512 capability.",
        "This benchmark focuses on very wide 512-bit vector lanes. It is intended for CPUs where the runtime reports AVX-512 support. Results here can be much higher than portable SIMD, but behavior also depends on frequency limits, power budget, cooling, and how aggressively the CPU downclocks under AVX-512 load. That makes it a very good test for burn-in comparisons and for seeing whether a server or workstation really benefits from its wide-vector feature set.",
        "Shown only when an AVX-512 family capability is detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector512<float> _a;
        private Vector512<float> _b;
        private Vector512<float> _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex)
        {
            _a = Vector512.Create(
                1.0f + workerIndex, 2.0f, 3.0f, 4.0f,
                5.0f, 6.0f, 7.0f, 8.0f,
                9.0f, 10.0f, 11.0f, 12.0f,
                13.0f, 14.0f, 15.0f, 16.0f);
            _b = Vector512.Create(
                0.5f, 0.75f, 1.0f, 1.25f,
                1.5f, 1.75f, 2.0f, 2.25f,
                2.5f, 2.75f, 3.0f, 3.25f,
                3.5f, 3.75f, 4.0f, 4.25f);
            _c = Vector512.Create(0.125f);
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            var a = _a;
            var b = _b;
            var c = _c;
            var k1 = Vector512.Create(1.00007f);
            var k2 = Vector512.Create(0.50003f);
            var k3 = Vector512.Create(0.00017f);
            const int iterations = 220_000;

            for (int i = 0; i < iterations; i++)
            {
                a = (a * k1) + b;
                b = (b * k2) - c;
                c = (a + b) * k3 + c;
                a += c;
            }

            Span<float> lanesA = stackalloc float[Vector512<float>.Count];
            Span<float> lanesB = stackalloc float[Vector512<float>.Count];
            Span<float> lanesC = stackalloc float[Vector512<float>.Count];
            a.CopyTo(lanesA);
            b.CopyTo(lanesB);
            c.CopyTo(lanesC);
            double sum = 0.0;
            for (int lane = 0; lane < Vector512<float>.Count; lane++)
                sum += lanesA[lane] + lanesB[lane] + lanesC[lane];

            _a = a;
            _b = b;
            _c = c;
            _checksum += sum;
            _work += iterations * Vector512<float>.Count * 12.0;
        }
    }
}

internal sealed class AesBlocksBenchmark : BenchmarkDefinition
{
    public AesBlocksBenchmark() : base(
        "AES Blocks",
        "Crypto / AES-NI",
        "Repeated AES round-style block transforms using hardware AES instructions when exposed.",
        MetricKind.Blocks,
        "Useful for systems where AES acceleration matters for storage, networking, or security workloads.",
        "This benchmark targets hardware AES instructions rather than general-purpose arithmetic. It repeatedly transforms many 128-bit blocks with AES round operations, which makes it a useful indicator for encryption-heavy workloads, secure storage, VPNs, packet handling, and similar tasks. It is not meant to be a full cryptographic library benchmark, but it does clearly show whether the CPU's AES path is strong.",
        "Shown only when AES support is detected by the runtime.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private Vector128<byte>[] _blocks;
        private readonly Vector128<byte>[] _roundKeys;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            if (!Aes.IsSupported || !Sse2.IsSupported)
                throw new PlatformNotSupportedException("AES benchmark requires AES and SSE2 support.");

            int length = BenchmarkSizing.ByPreset(preset, 512, 1024, 2048, 4096);
            _blocks = new Vector128<byte>[length];
            _roundKeys = new[]
            {
                Vector128.Create((byte)(1 + workerIndex)),
                Vector128.Create((byte)0x11),
                Vector128.Create((byte)0x22),
                Vector128.Create((byte)0x33),
                Vector128.Create((byte)0x44),
                Vector128.Create((byte)0x55),
                Vector128.Create((byte)0x66),
                Vector128.Create((byte)0x77),
                Vector128.Create((byte)0x88),
                Vector128.Create((byte)0x99)
            };

            for (int i = 0; i < _blocks.Length; i++)
                _blocks[i] = Vector128.Create((byte)((i + workerIndex) & 0xFF));
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            double sum = 0.0;
            Span<ulong> lanes = stackalloc ulong[2];
            for (int i = 0; i < _blocks.Length; i++)
            {
                Vector128<byte> state = _blocks[i];
                for (int r = 0; r < _roundKeys.Length - 1; r++)
                    state = Aes.Encrypt(state, _roundKeys[r]);
                state = Aes.EncryptLast(state, _roundKeys[^1]);
                _blocks[i] = state;
                state.AsUInt64().CopyTo(lanes);
                sum += lanes[0];
            }

            _checksum += sum;
            _work += _blocks.Length;
        }
    }
}

internal sealed class MemoryStreamBenchmark : BenchmarkDefinition
{
    public MemoryStreamBenchmark() : base(
        "Memory Stream",
        "Memory / Bandwidth",
        "Sequential copy and write pressure across local worker buffers.",
        MetricKind.Bytes,
        "Useful for memory bandwidth and cache-friendly behavior comparisons.",
        "This benchmark is deliberately simple and bandwidth-oriented. It copies large buffers and performs a small amount of line-spaced mutation. It works well for comparing systems where main memory speed, cache-to-memory traffic, or sustained bandwidth are important. If Memory Stream is strong but Cache Walker is weaker, the platform likely has good raw bandwidth but less impressive latency behavior.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly byte[] _src;
        private readonly byte[] _dst;
        private double _bytes;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            int length = BenchmarkSizing.ByPreset(preset, 4 * 1024 * 1024, 8 * 1024 * 1024, 16 * 1024 * 1024, 32 * 1024 * 1024);
            _src = new byte[length];
            _dst = new byte[length];
            for (int i = 0; i < _src.Length; i++)
                _src[i] = (byte)((i + workerIndex) & 0xFF);
        }

        public double WorkCompleted => _bytes;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            Buffer.BlockCopy(_src, 0, _dst, 0, _src.Length);
            for (int i = 0; i < _dst.Length; i += 64)
            {
                _dst[i] ^= (byte)(i & 0xFF);
                _checksum += _dst[i];
            }
            _bytes += _src.Length * 2.0;
        }
    }
}

internal sealed class MatrixMultiplyBenchmark : BenchmarkDefinition
{
    public MatrixMultiplyBenchmark() : base(
        "Matrix Multiply",
        "Math / Dense",
        "Dense matrix multiplication using local worker matrices.",
        MetricKind.FloatingOps,
        "Useful for sustained compute with heavy cache reuse.",
        "This benchmark performs classic dense matrix multiplication. It is a good approximation for steady numerical throughput with a lot of arithmetic reuse. It is usually one of the most useful tests for comparing powerful workstations and servers because it reflects how well cores, caches, and memory cooperate during sustained numerical work. It also responds well to longer burn-in sessions.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int _n;
        private readonly double[] _a;
        private readonly double[] _b;
        private readonly double[] _c;
        private double _work;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            _n = BenchmarkSizing.ByPreset(preset, 72, 96, 128, 160);
            _a = new double[_n * _n];
            _b = new double[_n * _n];
            _c = new double[_n * _n];
            for (int i = 0; i < _a.Length; i++)
            {
                _a[i] = ((i + workerIndex) % 17) * 0.5;
                _b[i] = ((i + workerIndex * 3) % 23) * 0.25;
            }
        }

        public double WorkCompleted => _work;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            Array.Clear(_c, 0, _c.Length);
            for (int i = 0; i < _n; i++)
            {
                int inBase = i * _n;
                for (int k = 0; k < _n; k++)
                {
                    double aik = _a[inBase + k];
                    int knBase = k * _n;
                    for (int j = 0; j < _n; j++)
                        _c[inBase + j] += aik * _b[knBase + j];
                }
            }

            double sum = 0.0;
            for (int i = 0; i < _c.Length; i += Math.Max(1, _n / 3))
                sum += _c[i];
            _checksum += sum;
            _work += 2.0 * _n * _n * _n;
        }
    }
}

internal sealed class PrimeScanBenchmark : BenchmarkDefinition
{
    public PrimeScanBenchmark() : base(
        "Prime Scan",
        "Control Flow / Integer",
        "Trial division across rising odd integers.",
        MetricKind.Numbers,
        "Good for branch-heavy integer work and cache-light scaling tests.",
        "Prime Scan is a classic branch-heavy integer workload. It repeatedly tests odd integers for primality by trial division up to square root. That gives it many control-flow turns and less predictable work per candidate than the straight-line arithmetic tests. It is a good way to see how a machine behaves when each thread does a lot of small integer decisions rather than dense vector math.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex);

    private sealed class Worker : IBenchmarkWorker
    {
        private int _current;
        private double _numbers;
        private double _checksum;

        public Worker(int workerIndex)
        {
            _current = 100_000 + workerIndex * 10_000;
            if ((_current & 1) == 0)
                _current++;
        }

        public double WorkCompleted => _numbers;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            const int count = 4_000;
            int checkedCount = 0;
            int found = 0;
            while (checkedCount < count)
            {
                if (IsPrime(_current))
                {
                    found++;
                    _checksum += _current;
                }
                _current += 2;
                checkedCount++;
            }
            _numbers += count;
            _checksum += found;
        }

        private static bool IsPrime(int value)
        {
            if (value < 2) return false;
            if ((value & 1) == 0) return value == 2;
            int limit = (int)Math.Sqrt(value);
            for (int i = 3; i <= limit; i += 2)
            {
                if (value % i == 0)
                    return false;
            }
            return true;
        }
    }
}

internal sealed class MandelbrotBenchmark : BenchmarkDefinition
{
    public MandelbrotBenchmark() : base(
        "Mandelbrot",
        "Mixed / FP+Branch",
        "Escape-time fractal compute over a local tile.",
        MetricKind.Pixels,
        "Good for floating-point plus branch behavior on independent pixels.",
        "Mandelbrot mixes floating-point arithmetic with conditional escape checks over lots of independent pixels. That makes it useful as a mixed real-world-style compute benchmark. It is less synthetic than raw ALU or AES tests and often gives a good feel for how a CPU handles independent work items that still contain branch decisions. It is especially interesting when comparing many-core machines against mainstream desktops.",
        "Always available.")
    {
    }

    public override IBenchmarkWorker CreateWorker(int workerIndex, BenchmarkPreset preset) => new Worker(workerIndex, preset);

    private sealed class Worker : IBenchmarkWorker
    {
        private readonly int _width;
        private readonly int _height;
        private readonly int _maxIterations;
        private readonly int _workerIndex;
        private double _pixels;
        private double _checksum;

        public Worker(int workerIndex, BenchmarkPreset preset)
        {
            _workerIndex = workerIndex;
            _width = BenchmarkSizing.ByPreset(preset, 256, 384, 512, 768);
            _height = _width;
            _maxIterations = BenchmarkSizing.ByPreset(preset, 128, 192, 256, 384);
        }

        public double WorkCompleted => _pixels;
        public double Checksum => _checksum;

        public void RunBatch()
        {
            double sum = 0.0;
            double xOffset = (_workerIndex % 8) * 0.001;
            double yOffset = (_workerIndex % 5) * 0.001;
            for (int y = 0; y < _height; y++)
            {
                double cy = -1.2 + 2.4 * y / (_height - 1) + yOffset;
                for (int x = 0; x < _width; x++)
                {
                    double cx = -2.2 + 3.0 * x / (_width - 1) + xOffset;
                    double zx = 0.0;
                    double zy = 0.0;
                    int iter = 0;
                    while (zx * zx + zy * zy <= 4.0 && iter < _maxIterations)
                    {
                        double nextX = zx * zx - zy * zy + cx;
                        zy = 2.0 * zx * zy + cy;
                        zx = nextX;
                        iter++;
                    }
                    sum += iter;
                }
            }
            _pixels += (double)_width * _height;
            _checksum += sum;
        }
    }
}
