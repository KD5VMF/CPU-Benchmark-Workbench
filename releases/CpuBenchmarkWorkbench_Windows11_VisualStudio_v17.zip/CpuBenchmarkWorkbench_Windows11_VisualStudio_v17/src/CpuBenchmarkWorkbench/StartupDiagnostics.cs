using System.Text;

namespace CpuBenchmarkWorkbench;

internal static class StartupDiagnostics
{
    private static readonly object Sync = new();

    public static string LogFilePath
    {
        get
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CpuBenchmarkWorkbench");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "startup.log");
        }
    }

    public static void Log(string message)
    {
        try
        {
            lock (Sync)
            {
                File.AppendAllText(
                    LogFilePath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {message}{Environment.NewLine}",
                    Encoding.UTF8);
            }
        }
        catch
        {
        }
    }

    public static void Log(Exception ex, string context)
    {
        Log($"{context}: {ex}");
    }
}
