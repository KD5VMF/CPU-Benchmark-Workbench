using System.Text;

namespace CpuBenchmarkWorkbench;

public sealed class HelpGuideForm : Form
{
    public HelpGuideForm(IReadOnlyList<BenchmarkDefinition> definitions, CpuCapabilityReport report)
    {
        Text = "CPU Benchmark Workbench - Help Guide";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(900, 700);
        ClientSize = new Size(1020, 780);
        Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Padding = new Point(18, 6)
        };
        Controls.Add(tabs);

        tabs.TabPages.Add(CreatePage("Overview", BuildOverview(definitions, report)));
        tabs.TabPages.Add(CreatePage("Benchmarks", BuildBenchmarks(definitions)));
        tabs.TabPages.Add(CreatePage("Running & Burn-In", BuildRunningGuide()));
        tabs.TabPages.Add(CreatePage("How To Read Results", BuildInterpretationGuide()));
        tabs.TabPages.Add(CreatePage("Detected CPU", BuildDetectedCpuGuide(report, definitions)));
    }

    private static TabPage CreatePage(string title, string text)
    {
        var page = new TabPage(title);
        var box = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            DetectUrls = false,
            BorderStyle = BorderStyle.None,
            BackColor = Color.White,
            Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point),
            Text = text
        };
        page.Controls.Add(box);
        return page;
    }

    private static string BuildOverview(IReadOnlyList<BenchmarkDefinition> definitions, CpuCapabilityReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("CPU Benchmark Workbench Overview");
        sb.AppendLine();
        sb.AppendLine("This program is meant to compare many different kinds of CPUs, from older home PCs to gaming machines to high-end workstations and servers. Instead of using only one synthetic score, it offers a mix of tests so you can see where a machine is strong or weak.");
        sb.AppendLine();
        sb.AppendLine("What the app does:");
        sb.AppendLine("- Detects the CPU features the .NET runtime exposes, including SIMD, AVX-family support, AES acceleration, visible thread count, processor groups, and NUMA node count.");
        sb.AppendLine("- Builds a benchmark list that matches the detected machine. For example, AVX-512 and AES tests appear only when the runtime reports those features.");
        sb.AppendLine("- Lets you run one chosen thread count, use Smart Sweep that starts at 1 thread and then samples quarter-step thread counts up to your chosen maximum, or run a longer Burn-In cycle.");
        sb.AppendLine("- Stores results in the table, lets you save CSV output, and can copy a formatted system report.");
        sb.AppendLine();
        sb.AppendLine($"Current system summary: {report.CapabilitySummary}");
        sb.AppendLine($"Detected feature highlights: {SystemInfoProvider.BuildFeatureHighlights(report)}");
        sb.AppendLine();
        sb.AppendLine($"Benchmarks available on this machine right now: {definitions.Count}");
        foreach (var definition in definitions)
            sb.AppendLine($"- {definition.Name} ({definition.Category})");
        return sb.ToString();
    }

    private static string BuildBenchmarks(IReadOnlyList<BenchmarkDefinition> definitions)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Benchmark Reference");
        sb.AppendLine();
        foreach (var definition in definitions)
        {
            sb.AppendLine(definition.Name);
            sb.AppendLine(new string('-', definition.Name.Length));
            sb.AppendLine($"Category: {definition.Category}");
            sb.AppendLine($"Measures: {definition.Description}");
            sb.AppendLine($"Useful for: {definition.Notes}");
            sb.AppendLine($"Availability: {definition.AvailabilityNote}");
            sb.AppendLine();
            sb.AppendLine(definition.DetailedHelp);
            sb.AppendLine();
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string BuildRunningGuide()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Running Benchmarks and Burn-In");
        sb.AppendLine();
        sb.AppendLine("Run Selected");
        sb.AppendLine("Runs the checked benchmarks once at the exact thread count shown in the Threads field.");
        sb.AppendLine();
        sb.AppendLine("Run Smart Sweep");
        sb.AppendLine("Runs each checked benchmark at a smaller set of smart thread counts instead of every single thread value. It always starts at 1 thread, then uses quarter-step points up to the selected maximum. For example, a 48-thread system becomes 1, 12, 24, 36, and 48. This is the best mode for seeing scaling without wasting time on dozens of nearly redundant thread counts.");
        sb.AppendLine();
        sb.AppendLine("Burn-In Run");
        sb.AppendLine("Repeats the checked benchmarks for the chosen number of minutes or until Stop is pressed. Burn-In is intended for longer thermal, stability, and sustained-load checks. It is especially useful for workstations and servers where frequency, cooling, and NUMA behavior may change over time under load.");
        sb.AppendLine();
        sb.AppendLine("Presets");
        sb.AppendLine("- Quick: short, fast check.");
        sb.AppendLine("- Standard: balanced everyday comparison.");
        sb.AppendLine("- Heavy: longer, stronger stress.");
        sb.AppendLine("- Extreme: longest regular per-test run.");
        sb.AppendLine();
        sb.AppendLine("Warmup");
        sb.AppendLine("When enabled, each benchmark does a short pre-run before timing starts. This reduces the chance that a result is distorted by one-time startup effects.");
        sb.AppendLine();
        sb.AppendLine("Priority");
        sb.AppendLine("The app can raise its process priority. Higher priority may reduce interference from background tasks, but it can also make the machine feel less responsive while testing.");
        return sb.ToString();
    }

    private static string BuildInterpretationGuide()
    {
        var sb = new StringBuilder();
        sb.AppendLine("How To Read Results");
        sb.AppendLine();
        sb.AppendLine("Score");
        sb.AppendLine("The score column shows the test's throughput using a unit appropriate for that benchmark, such as operations per second, floating-point operations per second, bytes per second, numbers per second, or pixels per second.");
        sb.AppendLine();
        sb.AppendLine("Scaling");
        sb.AppendLine("In sweep mode, scaling is shown relative to the single-thread result for the same benchmark and preset. 200% means roughly twice the 1-thread result. Lower-than-expected scaling can point to memory pressure, cache contention, synchronization overhead, power limits, or NUMA effects.");
        sb.AppendLine();
        sb.AppendLine("Compare families of tests");
        sb.AppendLine("- Strong Integer Mix but weak SIMD usually means the machine is better at scalar work than vector-heavy math.");
        sb.AppendLine("- Strong Memory Stream but weaker Cache Walker often suggests good bandwidth but less impressive latency behavior.");
        sb.AppendLine("- Very strong AVX-512 with modest all-core scaling may suggest frequency drop under wide-vector load.");
        sb.AppendLine("- Strong AES Blocks means the CPU is likely good for encryption-heavy storage and networking tasks.");
        sb.AppendLine("- Branch-heavy tests such as Prime Scan and Branch Chaos can reveal differences hidden by dense math kernels.");
        sb.AppendLine();
        sb.AppendLine("Burn-In interpretation");
        sb.AppendLine("Watch whether scores drift downward over time. That may indicate thermal throttling, power limits, or unstable sustained clocks.");
        return sb.ToString();
    }

    private static string BuildDetectedCpuGuide(CpuCapabilityReport report, IReadOnlyList<BenchmarkDefinition> definitions)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Detected CPU / Runtime Information");
        sb.AppendLine();
        sb.AppendLine(SystemInfoProvider.BuildSummary(report));
        sb.AppendLine();
        sb.AppendLine("Benchmarks currently shown because of detection:");
        foreach (var definition in definitions)
            sb.AppendLine($"- {definition.Name}: {definition.AvailabilityNote}");
        sb.AppendLine();
        sb.AppendLine("Important note:");
        sb.AppendLine("The app reports what the current .NET runtime exposes. In some cases the physical CPU may support more than the runtime is using, or BIOS / OS settings may affect what appears here.");
        return sb.ToString();
    }
}
