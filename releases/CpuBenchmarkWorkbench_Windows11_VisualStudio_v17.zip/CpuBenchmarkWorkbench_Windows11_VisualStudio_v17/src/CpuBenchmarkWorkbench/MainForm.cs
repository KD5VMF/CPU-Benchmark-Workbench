using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace CpuBenchmarkWorkbench;

public sealed class MainForm : Form
{
    private readonly CheckedListBox _benchmarkList = new();
    private readonly ComboBox _presetCombo = new();
    private readonly NumericUpDown _threadsUpDown = new();
    private readonly ComboBox _priorityCombo = new();
    private readonly CheckBox _warmupCheck = new();
    private readonly NumericUpDown _burnInMinutesUpDown = new();
    private readonly Button _runSelectedButton = new();
    private readonly Button _runSweepButton = new();
    private readonly Button _burnInButton = new();
    private readonly Button _stopButton = new();
    private readonly Button _clearButton = new();
    private readonly Button _saveCsvButton = new();
    private readonly Button _copySystemReportButton = new();
    private readonly Button _helpButton = new();
    private readonly Button _aboutButton = new();
    private readonly Button _selectAllButton = new();
    private readonly Button _selectNoneButton = new();
    private readonly Label _systemInfoLabel = new();
    private readonly Label _statusLabel = new();
    private readonly Label _notesLabel = new();
    private readonly ProgressBar _progressBar = new();
    private readonly DataGridView _resultsGrid = new();
    private readonly TextBox _logBox = new();
    private readonly SplitContainer _mainSplit = new();

    private readonly BindingList<BenchmarkResult> _results = new();
    private readonly Dictionary<string, double> _singleThreadBaselines = new(StringComparer.OrdinalIgnoreCase);
    private readonly CpuCapabilityReport _capabilityReport;
    private readonly IReadOnlyList<BenchmarkDefinition> _definitions;

    private CancellationTokenSource? _runCts;
    private bool _isRunning;

    public MainForm()
    {
        StartupDiagnostics.Log("MainForm constructor entered.");

        try
        {
            Text = "CPU Benchmark Workbench";
            StartPosition = FormStartPosition.CenterScreen;
            MinimumSize = new Size(1380, 920);
            ClientSize = new Size(1580, 980);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            AutoScaleMode = AutoScaleMode.Dpi;

            _capabilityReport = SystemInfoProvider.GetReport();
            _definitions = BenchmarkCatalog.CreateAll(_capabilityReport);

            BuildUi();
            PopulateControls();
            _systemInfoLabel.Text = SystemInfoProvider.BuildSummary(_capabilityReport);
            UpdateNotes();
            UpdateRunUiState(false);

            Load += (_, _) =>
            {
                StartupDiagnostics.Log("MainForm load.");
                ApplySidebarLayoutSafely();
            };
            Shown += (_, _) =>
            {
                StartupDiagnostics.Log("MainForm shown.");
                ApplySidebarLayoutSafely();
            };
            Resize += (_, _) =>
            {
                if (WindowState != FormWindowState.Minimized)
                    ApplySidebarLayoutSafely();
            };

            StartupDiagnostics.Log("MainForm constructor finished.");
        }
        catch (Exception ex)
        {
            StartupDiagnostics.Log(ex, "MainForm constructor failed");
            throw;
        }
    }

    private void ApplySidebarLayoutSafely()
    {
        try
        {
            if (_mainSplit.IsDisposed || _mainSplit.Width <= 0)
                return;

            const int desiredLeftWidth = 430;
            const int minimumLeftWidth = 360;
            const int minimumRightWidth = 760;

            int availableWidth = _mainSplit.ClientSize.Width;
            if (availableWidth <= 0)
                return;

            int absoluteMaxLeft = Math.Max(minimumLeftWidth, availableWidth - minimumRightWidth - _mainSplit.SplitterWidth);
            int chosenLeft = Math.Min(desiredLeftWidth, absoluteMaxLeft);

            if (chosenLeft < minimumLeftWidth)
                chosenLeft = Math.Max(260, availableWidth / 3);

            _mainSplit.Panel1MinSize = Math.Min(chosenLeft, Math.Max(120, availableWidth - _mainSplit.SplitterWidth - 120));
            _mainSplit.Panel2MinSize = Math.Max(120, availableWidth - chosenLeft - _mainSplit.SplitterWidth);

            int maxSplitterDistance = Math.Max(0, availableWidth - _mainSplit.Panel2MinSize - _mainSplit.SplitterWidth);
            int minSplitterDistance = Math.Min(_mainSplit.Panel1MinSize, maxSplitterDistance);
            int splitterDistance = Math.Max(minSplitterDistance, Math.Min(chosenLeft, maxSplitterDistance));

            if (splitterDistance >= 0)
                _mainSplit.SplitterDistance = splitterDistance;
        }
        catch (Exception ex)
        {
            StartupDiagnostics.Log(ex, "ApplySidebarLayoutSafely failed");
        }
    }

    private void BuildUi()
    {
        BackColor = Color.WhiteSmoke;

        _mainSplit.Dock = DockStyle.Fill;
        _mainSplit.FixedPanel = FixedPanel.Panel1;
        _mainSplit.IsSplitterFixed = false;
        _mainSplit.Panel1MinSize = 120;
        _mainSplit.Panel2MinSize = 120;
        _mainSplit.SplitterWidth = 6;
        Controls.Add(_mainSplit);

        BuildLeftSidebar();
        BuildRightPanel();
    }

    private void BuildLeftSidebar()
    {
        var leftHost = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(12),
            BackColor = Color.FromArgb(243, 246, 251),
            AutoScroll = true
        };
        _mainSplit.Panel1.Controls.Add(leftHost);

        var leftLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 9,
            BackColor = Color.Transparent,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        leftLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        for (int i = 0; i < 9; i++)
            leftLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        leftHost.Controls.Add(leftLayout);

        var title = new Label
        {
            Text = "CPU Benchmark Workbench",
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold),
            ForeColor = Color.FromArgb(24, 31, 54),
            Margin = new Padding(0, 0, 0, 4)
        };
        leftLayout.Controls.Add(title, 0, 0);

        var subtitle = new Label
        {
            Text = "Choose benchmarks, match tests to the detected CPU features, run one exact thread count, use Smart Sweep from 1 thread through quarter steps up to your selected maximum, or start a longer burn-in run. Help and About are built in.",
            Dock = DockStyle.Top,
            AutoSize = true,
            MaximumSize = new Size(392, 0),
            ForeColor = Color.FromArgb(70, 77, 99),
            Margin = new Padding(0, 0, 0, 10)
        };
        leftLayout.Controls.Add(subtitle, 0, 1);

        var benchmarksHeader = CreateSectionHeader("Benchmarks");
        benchmarksHeader.Margin = new Padding(0, 0, 0, 6);
        leftLayout.Controls.Add(benchmarksHeader, 0, 2);

        _benchmarkList.CheckOnClick = true;
        _benchmarkList.IntegralHeight = false;
        _benchmarkList.Dock = DockStyle.Fill;
        _benchmarkList.BorderStyle = BorderStyle.FixedSingle;
        _benchmarkList.HorizontalScrollbar = true;
        _benchmarkList.ScrollAlwaysVisible = true;
        _benchmarkList.Height = 170;
        _benchmarkList.SelectedIndexChanged += (_, _) => UpdateNotes();

        var benchmarkPanel = CreateCardPanel();
        benchmarkPanel.Height = 192;
        benchmarkPanel.MinimumSize = new Size(0, 192);
        benchmarkPanel.Margin = new Padding(0, 0, 0, 8);
        benchmarkPanel.Controls.Add(_benchmarkList);
        leftLayout.Controls.Add(benchmarkPanel, 0, 3);

        _selectAllButton.Text = "Select All";
        _selectAllButton.Size = new Size(184, 34);
        _selectAllButton.Click += (_, _) =>
        {
            for (int i = 0; i < _benchmarkList.Items.Count; i++)
                _benchmarkList.SetItemChecked(i, true);
        };

        _selectNoneButton.Text = "Select None";
        _selectNoneButton.Size = new Size(184, 34);
        _selectNoneButton.Click += (_, _) =>
        {
            for (int i = 0; i < _benchmarkList.Items.Count; i++)
                _benchmarkList.SetItemChecked(i, false);
        };

        var benchmarkButtons = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            ColumnCount = 2,
            RowCount = 1,
            Height = 40,
            Margin = new Padding(0, 0, 0, 10)
        };
        benchmarkButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        benchmarkButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        benchmarkButtons.Controls.Add(_selectAllButton, 0, 0);
        benchmarkButtons.Controls.Add(_selectNoneButton, 1, 0);
        leftLayout.Controls.Add(benchmarkButtons, 0, 4);

        ConfigureSettingsControls();
        var settingsCard = CreateCardPanel();
        settingsCard.Height = 278;
        settingsCard.MinimumSize = new Size(0, 278);
        settingsCard.Margin = new Padding(0, 0, 0, 10);
        settingsCard.Controls.Add(CreateSettingsPanel());
        leftLayout.Controls.Add(settingsCard, 0, 5);

        ConfigureActionButtons();
        var actionsCard = CreateCardPanel();
        actionsCard.Height = 252;
        actionsCard.MinimumSize = new Size(0, 252);
        actionsCard.Margin = new Padding(0, 0, 0, 10);
        actionsCard.Controls.Add(CreateActionsPanel());
        leftLayout.Controls.Add(actionsCard, 0, 6);

        _systemInfoLabel.Dock = DockStyle.Fill;
        _systemInfoLabel.AutoSize = false;
        _systemInfoLabel.ForeColor = Color.FromArgb(50, 55, 73);
        _systemInfoLabel.Padding = new Padding(2);

        var systemCard = CreateCardPanel();
        systemCard.Height = 182;
        systemCard.MinimumSize = new Size(0, 182);
        systemCard.Margin = new Padding(0, 0, 0, 10);
        systemCard.Controls.Add(_systemInfoLabel);
        leftLayout.Controls.Add(systemCard, 0, 7);

        _notesLabel.Dock = DockStyle.Fill;
        _notesLabel.AutoSize = false;
        _notesLabel.ForeColor = Color.FromArgb(57, 62, 80);
        _notesLabel.Padding = new Padding(2);

        var notesCard = CreateCardPanel();
        notesCard.Height = 188;
        notesCard.MinimumSize = new Size(0, 188);
        notesCard.Controls.Add(_notesLabel);
        leftLayout.Controls.Add(notesCard, 0, 8);
    }

    private void ConfigureSettingsControls()
    {
        _presetCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _presetCombo.Width = 220;

        _threadsUpDown.Minimum = 1;
        _threadsUpDown.Maximum = Math.Max(1, Environment.ProcessorCount);
        _threadsUpDown.Value = Math.Max(1, Environment.ProcessorCount);
        _threadsUpDown.Width = 120;

        _priorityCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        _priorityCombo.Width = 220;

        _warmupCheck.Text = "Warm up each benchmark before timing";
        _warmupCheck.AutoSize = true;
        _warmupCheck.Checked = true;

        _burnInMinutesUpDown.Minimum = 1;
        _burnInMinutesUpDown.Maximum = 1440;
        _burnInMinutesUpDown.Value = 15;
        _burnInMinutesUpDown.Width = 120;
    }

    private Control CreateSettingsPanel()
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 8,
            Padding = new Padding(0),
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 104F));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        for (int i = 0; i < 8; i++)
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        AddSettingRow(layout, 0, "Preset", _presetCombo);
        AddSettingRow(layout, 1, "Threads", _threadsUpDown);
        AddSettingRow(layout, 2, "Priority", _priorityCombo);
        AddSettingRow(layout, 3, "Burn-In min", _burnInMinutesUpDown);

        var warmupHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            WrapContents = false,
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Padding(0, 4, 0, 6)
        };
        warmupHost.Controls.Add(_warmupCheck);
        layout.Controls.Add(warmupHost, 1, 4);

        var sectionTitle = new Label
        {
            Text = "Run Settings",
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold),
            ForeColor = Color.FromArgb(26, 34, 61),
            Margin = new Padding(0, 0, 0, 8)
        };
        layout.Controls.Add(sectionTitle, 0, 5);
        layout.SetColumnSpan(sectionTitle, 2);

        var helpText = new Label
        {
            Text = "",
            Dock = DockStyle.Top,
            AutoSize = true,
            MaximumSize = new Size(360, 0),
            ForeColor = Color.FromArgb(85, 90, 110),
            Margin = new Padding(0, 0, 0, 6)
        };
        layout.Controls.Add(helpText, 0, 6);
        layout.SetColumnSpan(helpText, 2);

        var featureText = new Label
        {
            Text = SystemInfoProvider.BuildFeatureHighlights(_capabilityReport),
            Dock = DockStyle.Top,
            AutoSize = true,
            MaximumSize = new Size(360, 0),
            ForeColor = Color.FromArgb(46, 84, 133),
            Margin = new Padding(0, 0, 0, 0)
        };
        layout.Controls.Add(featureText, 0, 7);
        layout.SetColumnSpan(featureText, 2);

        return layout;
    }

    private static void AddSettingRow(TableLayoutPanel layout, int row, string labelText, Control control)
    {
        var label = new Label
        {
            Text = labelText,
            AutoSize = true,
            Margin = new Padding(0, 8, 8, 8),
            ForeColor = Color.FromArgb(35, 41, 59),
            TextAlign = ContentAlignment.MiddleLeft
        };
        layout.Controls.Add(label, 0, row);

        control.Dock = DockStyle.Left;
        control.Margin = new Padding(0, 4, 0, 4);
        layout.Controls.Add(control, 1, row);
    }

    private void ConfigureActionButtons()
    {
        _runSelectedButton.Text = "Run Selected";
        _runSelectedButton.Dock = DockStyle.Fill;
        _runSelectedButton.Height = 36;
        _runSelectedButton.Click += async (_, _) => await RunBenchmarksAsync(false);

        _runSweepButton.Text = "Run Smart Sweep";
        _runSweepButton.Dock = DockStyle.Fill;
        _runSweepButton.Height = 36;
        _runSweepButton.Click += async (_, _) => await RunBenchmarksAsync(true);

        _burnInButton.Text = "Burn-In Run";
        _burnInButton.Dock = DockStyle.Fill;
        _burnInButton.Height = 36;
        _burnInButton.Click += async (_, _) => await RunBurnInAsync();

        _stopButton.Text = "Stop";
        _stopButton.Dock = DockStyle.Fill;
        _stopButton.Height = 36;
        _stopButton.Click += (_, _) => _runCts?.Cancel();

        _saveCsvButton.Text = "Save CSV";
        _saveCsvButton.Dock = DockStyle.Fill;
        _saveCsvButton.Height = 34;
        _saveCsvButton.Click += (_, _) => SaveCsv();

        _copySystemReportButton.Text = "Copy System Report";
        _copySystemReportButton.Dock = DockStyle.Fill;
        _copySystemReportButton.Height = 34;
        _copySystemReportButton.Click += (_, _) =>
        {
            try
            {
                Clipboard.SetText(SystemInfoProvider.BuildClipboardReport(_capabilityReport));
                AppendLog("System capability report copied to clipboard.");
                _statusLabel.Text = "System report copied to clipboard.";
            }
            catch (Exception ex)
            {
                AppendLog("Copy report failed: " + ex.Message);
                MessageBox.Show(this, ex.Message, "Copy failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };

        _helpButton.Text = "Help Guide";
        _helpButton.Dock = DockStyle.Fill;
        _helpButton.Height = 34;
        _helpButton.Click += (_, _) =>
        {
            using var dialog = new HelpGuideForm(_definitions, _capabilityReport);
            dialog.ShowDialog(this);
        };

        _aboutButton.Text = "About + MIT";
        _aboutButton.Dock = DockStyle.Fill;
        _aboutButton.Height = 34;
        _aboutButton.Click += (_, _) =>
        {
            using var dialog = new AboutForm();
            dialog.ShowDialog(this);
        };

        _clearButton.Text = "Clear Results";
        _clearButton.Dock = DockStyle.Fill;
        _clearButton.Height = 34;
        _clearButton.Click += (_, _) =>
        {
            _results.Clear();
            _singleThreadBaselines.Clear();
            AppendLog("Results cleared.");
            _statusLabel.Text = "Results cleared.";
            UpdateRunUiState(false);
        };
    }

    private Control CreateActionsPanel()
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 5,
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));

        layout.Controls.Add(_runSelectedButton, 0, 0);
        layout.Controls.Add(_runSweepButton, 1, 0);
        layout.Controls.Add(_burnInButton, 0, 1);
        layout.Controls.Add(_stopButton, 1, 1);
        layout.Controls.Add(_saveCsvButton, 0, 2);
        layout.Controls.Add(_copySystemReportButton, 1, 2);
        layout.Controls.Add(_helpButton, 0, 3);
        layout.Controls.Add(_aboutButton, 1, 3);
        layout.Controls.Add(_clearButton, 0, 4);
        layout.SetColumnSpan(_clearButton, 2);

        return layout;
    }

    private void BuildRightPanel()
    {
        var rightLayout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            Padding = new Padding(10, 12, 12, 12)
        };
        rightLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        rightLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 116F));
        rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        _mainSplit.Panel2.Controls.Add(rightLayout);

        var statusCard = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(12),
            BackColor = Color.FromArgb(245, 247, 252),
            Margin = new Padding(0, 0, 0, 10)
        };
        rightLayout.Controls.Add(statusCard, 0, 0);

        var statusTitle = new Label
        {
            Text = "Run Status",
            Dock = DockStyle.Top,
            Height = 24,
            Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold),
            ForeColor = Color.FromArgb(26, 34, 61)
        };
        statusCard.Controls.Add(statusTitle);

        _statusLabel.Text = "Ready. Choose benchmarks, choose a preset, then run one exact thread count, use Smart Sweep, or launch a burn-in cycle.";
        _statusLabel.Dock = DockStyle.Top;
        _statusLabel.Height = 48;
        _statusLabel.ForeColor = Color.FromArgb(50, 55, 73);
        _statusLabel.Padding = new Padding(0, 6, 0, 0);
        statusCard.Controls.Add(_statusLabel);

        _progressBar.Dock = DockStyle.Bottom;
        _progressBar.Height = 10;
        statusCard.Controls.Add(_progressBar);

        var tabs = new TabControl
        {
            Dock = DockStyle.Fill,
            Appearance = TabAppearance.Normal
        };
        rightLayout.Controls.Add(tabs, 0, 1);

        var resultsTab = new TabPage("Results");
        var logTab = new TabPage("Live Log");
        tabs.TabPages.Add(resultsTab);
        tabs.TabPages.Add(logTab);

        BuildResultsGrid();
        resultsTab.Controls.Add(_resultsGrid);

        _logBox.Multiline = true;
        _logBox.ReadOnly = true;
        _logBox.ScrollBars = ScrollBars.Both;
        _logBox.WordWrap = false;
        _logBox.Font = new Font("Consolas", 10F, FontStyle.Regular, GraphicsUnit.Point);
        _logBox.Dock = DockStyle.Fill;
        logTab.Controls.Add(_logBox);
    }

    private void BuildResultsGrid()
    {
        _resultsGrid.Dock = DockStyle.Fill;
        _resultsGrid.ReadOnly = true;
        _resultsGrid.AutoGenerateColumns = false;
        _resultsGrid.AllowUserToAddRows = false;
        _resultsGrid.AllowUserToDeleteRows = false;
        _resultsGrid.AllowUserToResizeRows = false;
        _resultsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _resultsGrid.MultiSelect = false;
        _resultsGrid.RowHeadersVisible = false;
        _resultsGrid.BackgroundColor = Color.White;
        _resultsGrid.BorderStyle = BorderStyle.FixedSingle;
        _resultsGrid.DataSource = _results;

        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Time", DataPropertyName = nameof(BenchmarkResult.TimestampDisplay), Width = 76 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Benchmark", DataPropertyName = nameof(BenchmarkResult.Benchmark), Width = 188 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Threads", DataPropertyName = nameof(BenchmarkResult.Threads), Width = 70 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Preset", DataPropertyName = nameof(BenchmarkResult.Preset), Width = 86 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Duration", DataPropertyName = nameof(BenchmarkResult.DurationDisplay), Width = 92 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Score", DataPropertyName = nameof(BenchmarkResult.ScoreDisplay), Width = 168 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Scaling", DataPropertyName = nameof(BenchmarkResult.ScalingDisplay), Width = 84 });
        _resultsGrid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Notes", DataPropertyName = nameof(BenchmarkResult.Notes), AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill });
    }

    private static Label CreateSectionHeader(string text)
    {
        return new Label
        {
            Text = text,
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold),
            ForeColor = Color.FromArgb(26, 34, 61)
        };
    }

    private static Panel CreateCardPanel()
    {
        return new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(10),
            BackColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle
        };
    }

    private void PopulateControls()
    {
        foreach (var definition in _definitions)
            _benchmarkList.Items.Add(definition, true);

        if (_benchmarkList.Items.Count > 0)
            _benchmarkList.SelectedIndex = 0;

        foreach (BenchmarkPreset preset in Enum.GetValues(typeof(BenchmarkPreset)))
            _presetCombo.Items.Add(preset);
        _presetCombo.SelectedItem = BenchmarkPreset.Standard;

        _priorityCombo.Items.AddRange(new object[]
        {
            ProcessPriorityClass.Normal,
            ProcessPriorityClass.AboveNormal,
            ProcessPriorityClass.High
        });
        _priorityCombo.SelectedItem = ProcessPriorityClass.AboveNormal;
    }

    private void UpdateNotes()
    {
        if (_benchmarkList.SelectedItem is BenchmarkDefinition definition)
        {
            _notesLabel.Text =
                $"{definition.Category}{Environment.NewLine}{Environment.NewLine}" +
                $"{definition.Description}{Environment.NewLine}{Environment.NewLine}" +
                $"Why it matters: {definition.Notes}{Environment.NewLine}{Environment.NewLine}" +
                $"Availability: {definition.AvailabilityNote}{Environment.NewLine}{Environment.NewLine}" +
                $"Detected platform summary:{Environment.NewLine}{_capabilityReport.CapabilitySummary}";
        }
        else
        {
            _notesLabel.Text = "Select any benchmark to see what it measures, when it is available, and what it is useful for comparing.";
        }
    }

    private async Task RunBenchmarksAsync(bool sweep)
    {
        if (_isRunning)
            return;

        var selected = GetSelectedBenchmarks();
        if (selected.Count == 0)
        {
            MessageBox.Show(this, "Select at least one benchmark first.", "Nothing selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (_presetCombo.SelectedItem is not BenchmarkPreset preset)
        {
            MessageBox.Show(this, "Select a workload preset first.", "Preset required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        int requestedThreads = (int)_threadsUpDown.Value;
        int availableThreads = Math.Max(1, Environment.ProcessorCount);
        int maxThreads = Math.Max(1, Math.Min(requestedThreads, availableThreads));
        var sequence = sweep ? BuildSmartSweepSequence(maxThreads) : new List<int> { maxThreads };

        _runCts = new CancellationTokenSource();
        _isRunning = true;
        UpdateRunUiState(true);
        _progressBar.Style = ProgressBarStyle.Continuous;
        _progressBar.Value = 0;
        _progressBar.Maximum = Math.Max(1, selected.Count * sequence.Count);

        try
        {
            AppendLog($"=== New run started at {DateTime.Now:G} ===");
            AppendLog($"Benchmarks: {string.Join(", ", selected.Select(x => x.Name))}");
            AppendLog($"Preset: {preset.DisplayName()} | Threads: {(sweep ? string.Join(", ", sequence) : maxThreads.ToString())}");
            if (sweep)
                AppendLog($"Smart Sweep thread sequence: {string.Join(", ", sequence)} (available: {availableThreads}, selected max: {requestedThreads})");
            ApplyProcessPriority();

            int completed = 0;
            foreach (var definition in selected)
            {
                foreach (int threads in sequence)
                {
                    _runCts.Token.ThrowIfCancellationRequested();
                    await RunOneBenchmarkAsync(definition, preset, threads, completed, selected.Count * sequence.Count, _runCts.Token);
                    completed++;
                    _progressBar.Value = Math.Min(completed, _progressBar.Maximum);
                }
            }

            AppendLog("=== Run complete ===");
            _statusLabel.Text = "Run complete.";
        }
        catch (OperationCanceledException)
        {
            AppendLog("Run canceled.");
            _statusLabel.Text = "Run canceled.";
        }
        catch (Exception ex)
        {
            AppendLog("ERROR: " + ex.Message);
            MessageBox.Show(this, ex.ToString(), "Benchmark error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _statusLabel.Text = "Error during benchmark run.";
        }
        finally
        {
            FinishRun();
        }
    }

    private static List<int> BuildSmartSweepSequence(int maxThreads)
    {
        maxThreads = Math.Max(1, maxThreads);

        var sequence = new SortedSet<int>
        {
            1,
            maxThreads
        };

        if (maxThreads > 1)
        {
            for (int quarter = 1; quarter <= 3; quarter++)
            {
                int value = (int)Math.Round(maxThreads * (quarter / 4.0), MidpointRounding.AwayFromZero);
                value = Math.Clamp(value, 1, maxThreads);
                sequence.Add(value);
            }
        }

        return sequence.ToList();
    }

    private async Task RunBurnInAsync()
    {
        if (_isRunning)
            return;

        var selected = GetSelectedBenchmarks();
        if (selected.Count == 0)
        {
            MessageBox.Show(this, "Select at least one benchmark first.", "Nothing selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (_presetCombo.SelectedItem is not BenchmarkPreset preset)
        {
            MessageBox.Show(this, "Select a workload preset first.", "Preset required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        int availableThreads = Math.Max(1, Environment.ProcessorCount);
        int threads = Math.Max(1, Math.Min((int)_threadsUpDown.Value, availableThreads));
        int minutes = (int)_burnInMinutesUpDown.Value;
        DateTime endsAt = DateTime.Now.AddMinutes(minutes);

        _runCts = new CancellationTokenSource();
        _isRunning = true;
        UpdateRunUiState(true);
        _progressBar.Style = ProgressBarStyle.Marquee;
        _progressBar.MarqueeAnimationSpeed = 25;

        try
        {
            AppendLog($"=== Burn-In started at {DateTime.Now:G} ===");
            AppendLog($"Benchmarks: {string.Join(", ", selected.Select(x => x.Name))}");
            AppendLog($"Preset: {preset.DisplayName()} | Threads: {threads} | Requested burn-in: {minutes} minute(s)");
            AppendLog("Burn-In repeats the selected tests until the requested time expires or Stop is pressed.");
            ApplyProcessPriority();

            int cycle = 0;
            while (DateTime.Now < endsAt)
            {
                _runCts.Token.ThrowIfCancellationRequested();
                cycle++;
                AppendLog($"--- Burn-In cycle {cycle} ---");
                foreach (var definition in selected)
                {
                    _runCts.Token.ThrowIfCancellationRequested();
                    double remainingSeconds = Math.Max(1.0, (endsAt - DateTime.Now).TotalSeconds);
                    if (remainingSeconds <= 0)
                        break;

                    _statusLabel.Text = $"Burn-In cycle {cycle}: {definition.Name} on {threads} thread(s)...";
                    var options = new BenchmarkRunOptions
                    {
                        Preset = preset,
                        Threads = threads,
                        Warmup = _warmupCheck.Checked,
                        DurationOverrideSeconds = Math.Min(preset.TargetSeconds(), remainingSeconds)
                    };

                    var result = await BenchmarkEngine.RunAsync(definition, options, AppendLog, _runCts.Token);
                    ApplyScaling(result);
                    _results.Add(result);
                    AppendLog($"Burn-In result: {result.Benchmark} | {result.Threads} thread(s) | {result.ScoreDisplay} | checksum {result.Checksum:N2}");
                }
            }

            AppendLog("=== Burn-In complete ===");
            _statusLabel.Text = "Burn-In complete.";
        }
        catch (OperationCanceledException)
        {
            AppendLog("Burn-In canceled.");
            _statusLabel.Text = "Burn-In canceled.";
        }
        catch (Exception ex)
        {
            AppendLog("ERROR: " + ex.Message);
            MessageBox.Show(this, ex.ToString(), "Burn-In error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            _statusLabel.Text = "Error during burn-in run.";
        }
        finally
        {
            FinishRun();
        }
    }

    private async Task RunOneBenchmarkAsync(BenchmarkDefinition definition, BenchmarkPreset preset, int threads, int completed, int total, CancellationToken cancellationToken)
    {
        _statusLabel.Text = $"Running {definition.Name} with {threads} thread(s)...";
        var options = new BenchmarkRunOptions
        {
            Preset = preset,
            Threads = threads,
            Warmup = _warmupCheck.Checked
        };

        var result = await BenchmarkEngine.RunAsync(definition, options, AppendLog, cancellationToken);
        ApplyScaling(result);
        _results.Add(result);

        AppendLog($"Finished ({completed + 1}/{total}): {result.Benchmark} | {result.Threads} thread(s) | {result.ScoreDisplay} | checksum {result.Checksum:N2}");
        _statusLabel.Text = $"Last result: {result.Benchmark} @ {result.Threads} thread(s) -> {result.ScoreDisplay}";
    }

    private List<BenchmarkDefinition> GetSelectedBenchmarks()
    {
        return _benchmarkList.CheckedItems.Cast<object>().OfType<BenchmarkDefinition>().ToList();
    }

    private void ApplyProcessPriority()
    {
        try
        {
            Process.GetCurrentProcess().PriorityClass = (ProcessPriorityClass)_priorityCombo.SelectedItem!;
        }
        catch (Exception ex)
        {
            AppendLog("Priority change skipped: " + ex.Message);
        }
    }

    private void FinishRun()
    {
        _isRunning = false;
        _progressBar.Style = ProgressBarStyle.Continuous;
        _progressBar.MarqueeAnimationSpeed = 0;
        UpdateRunUiState(false);
        _runCts?.Dispose();
        _runCts = null;
    }

    private void ApplyScaling(BenchmarkResult result)
    {
        string key = $"{result.Benchmark}|{result.Preset}";
        if (result.Threads == 1)
        {
            _singleThreadBaselines[key] = result.ScorePerSecond;
            result.ScalingPercent = 100.0;
            return;
        }

        if (_singleThreadBaselines.TryGetValue(key, out double baseline) && baseline > 0.0)
            result.ScalingPercent = result.ScorePerSecond / baseline * 100.0;
    }

    private void UpdateRunUiState(bool running)
    {
        _runSelectedButton.Enabled = !running;
        _runSweepButton.Enabled = !running;
        _burnInButton.Enabled = !running;
        _stopButton.Enabled = running;
        _saveCsvButton.Enabled = !running && _results.Count > 0;
        _copySystemReportButton.Enabled = !running;
        _helpButton.Enabled = !running;
        _aboutButton.Enabled = !running;
        _clearButton.Enabled = !running;
        _selectAllButton.Enabled = !running;
        _selectNoneButton.Enabled = !running;
        _presetCombo.Enabled = !running;
        _threadsUpDown.Enabled = !running;
        _priorityCombo.Enabled = !running;
        _warmupCheck.Enabled = !running;
        _burnInMinutesUpDown.Enabled = !running;
        _benchmarkList.Enabled = !running;
    }

    private void SaveCsv()
    {
        if (_results.Count == 0)
        {
            MessageBox.Show(this, "There are no results to save yet.", "Nothing to save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var dialog = new SaveFileDialog
        {
            Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*",
            FileName = $"cpu-benchmark-results-{DateTime.Now:yyyyMMdd-HHmmss}.csv"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
            return;

        var sb = new StringBuilder();
        sb.AppendLine("Time,Benchmark,Threads,Preset,DurationSeconds,ScorePerSecond,MetricKind,ScalingPercent,Checksum,Notes");
        foreach (var result in _results)
        {
            sb.AppendLine(string.Join(',',
                Csv(result.TimestampDisplay),
                Csv(result.Benchmark),
                result.Threads.ToString(),
                Csv(result.Preset),
                result.DurationSeconds.ToString("F4"),
                result.ScorePerSecond.ToString("F4"),
                Csv(result.MetricKind.ToString()),
                result.ScalingPercent.ToString("F2"),
                result.Checksum.ToString("F4"),
                Csv(result.Notes)));
        }

        File.WriteAllText(dialog.FileName, sb.ToString(), Encoding.UTF8);
        AppendLog("Saved CSV: " + dialog.FileName);
        _statusLabel.Text = "Saved CSV.";
    }

    private static string Csv(string value)
    {
        value ??= string.Empty;
        if (value.Contains('"'))
            value = value.Replace("\"", "\"\"");

        if (value.Contains(',') || value.Contains('"') || value.Contains('\n') || value.Contains('\r'))
            return $"\"{value}\"";

        return value;
    }

    private void AppendLog(string message)
    {
        if (IsDisposed)
            return;

        if (InvokeRequired)
        {
            BeginInvoke(new Action<string>(AppendLog), message);
            return;
        }

        _logBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
    }
}
