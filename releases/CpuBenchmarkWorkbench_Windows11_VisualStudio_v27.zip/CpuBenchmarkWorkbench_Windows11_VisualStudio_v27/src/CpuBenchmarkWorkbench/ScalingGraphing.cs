using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace CpuBenchmarkWorkbench;

public sealed class ScalingGraphSnapshot
{
    public string SessionId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Subtitle { get; init; } = string.Empty;
    public IReadOnlyList<ScalingGraphSeries> Series { get; init; } = Array.Empty<ScalingGraphSeries>();
    public IReadOnlyList<int> ThreadTicks { get; init; } = Array.Empty<int>();
    public double MaxScalingPercent { get; init; }
}

public sealed class ScalingGraphSeries
{
    public string Name { get; init; } = string.Empty;
    public int ColorIndex { get; init; }
    public IReadOnlyList<ScalingGraphPoint> Points { get; init; } = Array.Empty<ScalingGraphPoint>();
}

public readonly record struct ScalingGraphPoint(int Threads, double ScalingPercent);

internal readonly record struct ScalingGraphExport(string FilePath, ScalingGraphSnapshot Snapshot);

internal static class ScalingGraphBuilder
{
    private static readonly string[] PreferredBenchmarks =
    [
        "Integer Mix",
        "AVX-512 Wide Float32",
        "AVX2 / FMA Float32",
        "Memory Stream",
        "Memory Stream (Sustained)",
        "AES Blocks",
        "Matrix Multiply",
        "Prime Scan",
        "Mandelbrot"
    ];

    public static string? GetPreviewSessionId(IEnumerable<BenchmarkResult> results, BenchmarkResult? selectedResult)
    {
        if (selectedResult is not null && !string.IsNullOrWhiteSpace(selectedResult.SessionId))
            return selectedResult.SessionId;

        return results
            .Where(x => !string.IsNullOrWhiteSpace(x.SessionId))
            .OrderByDescending(x => x.StartedAt)
            .Select(x => x.SessionId)
            .FirstOrDefault();
    }

    public static IReadOnlyList<ScalingGraphExport> BuildExports(IEnumerable<BenchmarkResult> results, CpuCapabilityReport report)
    {
        var exports = new List<ScalingGraphExport>();
        var sessions = results
            .Where(x => x.ScorePerSecond > 0.0 && !string.IsNullOrWhiteSpace(x.SessionId))
            .GroupBy(x => x.SessionId, StringComparer.OrdinalIgnoreCase)
            .OrderBy(g => g.Min(x => x.StartedAt))
            .ToList();

        if (sessions.Count == 0)
            return exports;

        string? singleSessionId = sessions.Count == 1 ? sessions[0].Key : null;
        foreach (var session in sessions)
        {
            var snapshot = BuildForSession(results, report, session.Key);
            if (snapshot is null)
                continue;

            string suffix = singleSessionId is not null
                ? "-thread-scaling.png"
                : $"-session-{SanitizeFileName(session.Key)}-thread-scaling.png";

            exports.Add(new ScalingGraphExport(suffix, snapshot));
        }

        return exports;
    }

    public static ScalingGraphSnapshot? BuildForSession(IEnumerable<BenchmarkResult> allResults, CpuCapabilityReport report, string sessionId)
    {
        var sessionResults = allResults
            .Where(x => x.ScorePerSecond > 0.0)
            .Where(x => string.Equals(x.SessionId, sessionId, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Threads)
            .ThenBy(x => x.StartedAt)
            .ToList();

        if (sessionResults.Count == 0)
            return null;

        var presetLabel = sessionResults
            .Select(x => x.Preset)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var placementLabel = sessionResults
            .Select(x => x.Placement)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .GroupBy(x => x, StringComparer.OrdinalIgnoreCase)
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Key)
            .FirstOrDefault() ?? "Mixed";

        var scoring = BenchmarkScoringEngine.Evaluate(sessionResults, sessionId);
        var grouped = sessionResults
            .GroupBy(x => x.Benchmark, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Threads).ThenBy(x => x.StartedAt).ToList(), StringComparer.OrdinalIgnoreCase);

        var orderedBenchmarkNames = new List<string>();
        foreach (string name in PreferredBenchmarks)
        {
            if (grouped.ContainsKey(name))
                orderedBenchmarkNames.Add(name);
        }

        foreach (string name in grouped.Keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            if (!orderedBenchmarkNames.Contains(name, StringComparer.OrdinalIgnoreCase))
                orderedBenchmarkNames.Add(name);
        }

        var series = new List<ScalingGraphSeries>();
        foreach (string benchmarkName in orderedBenchmarkNames)
        {
            var benchmarkResults = grouped[benchmarkName];
            double? baseline = benchmarkResults
                .Where(x => x.Threads == 1)
                .OrderByDescending(x => x.ScorePerSecond)
                .Select(x => (double?)x.ScorePerSecond)
                .FirstOrDefault();

            var points = new List<ScalingGraphPoint>();
            foreach (var result in benchmarkResults
                .GroupBy(x => x.Threads)
                .OrderBy(g => g.Key))
            {
                var bestAtThread = result.OrderByDescending(x => x.ScorePerSecond).First();
                double scaling = 0.0;

                if (baseline.HasValue && baseline.Value > 0.0)
                    scaling = (bestAtThread.ScorePerSecond / baseline.Value) * 100.0;
                else if (bestAtThread.Threads == 1)
                    scaling = 100.0;
                else if (bestAtThread.ScalingPercent > 0.0)
                    scaling = bestAtThread.ScalingPercent;

                if (scaling > 0.0)
                    points.Add(new ScalingGraphPoint(bestAtThread.Threads, scaling));
            }

            if (points.Count == 0)
                continue;

            series.Add(new ScalingGraphSeries
            {
                Name = benchmarkName,
                ColorIndex = series.Count,
                Points = points
            });
        }

        if (series.Count == 0)
            return null;

        var threadTicks = series
            .SelectMany(x => x.Points)
            .Select(x => x.Threads)
            .Distinct()
            .OrderBy(x => x)
            .ToArray();

        double maxScaling = series
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        string subtitle =
            $"Session: {sessionId}   |   System: {Environment.MachineName}   |   Preset: {presetLabel}   |   Placement: {placementLabel}   |   Profile: {report.CapabilitySummary}";

        return new ScalingGraphSnapshot
        {
            SessionId = sessionId,
            Title = $"Key benchmark scaling by thread count ({report.VisibleThreads} visible threads, best fit: {scoring.BestFitTitle})",
            Subtitle = subtitle,
            Series = series,
            ThreadTicks = threadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private static string SanitizeFileName(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "session";

        foreach (char invalid in Path.GetInvalidFileNameChars())
            value = value.Replace(invalid, '-');

        return value.Replace(' ', '-');
    }
}

internal readonly record struct ScalingGraphLayout(Rectangle PlotRect, Rectangle LegendRect, Rectangle InsightRect);

internal static class ScalingGraphRenderer
{
    private static readonly Color[] SeriesColors =
    [
        Color.FromArgb(31, 119, 180),
        Color.FromArgb(255, 127, 14),
        Color.FromArgb(44, 160, 44),
        Color.FromArgb(214, 39, 40),
        Color.FromArgb(148, 103, 189),
        Color.FromArgb(140, 86, 75),
        Color.FromArgb(227, 119, 194),
        Color.FromArgb(127, 127, 127),
        Color.FromArgb(188, 189, 34),
        Color.FromArgb(23, 190, 207)
    ];

    public static Color GetSeriesColor(int seriesIndex)
    {
        if (seriesIndex < 0)
            seriesIndex = 0;

        return SeriesColors[seriesIndex % SeriesColors.Length];
    }

    public static Bitmap CreateBitmap(ScalingGraphSnapshot snapshot, Size size)
    {
        int width = Math.Max(1200, size.Width);
        int height = Math.Max(700, size.Height);

        var bitmap = new Bitmap(width, height);
        using var graphics = Graphics.FromImage(bitmap);
        Draw(graphics, new Rectangle(0, 0, width, height), snapshot);
        return bitmap;
    }

    public static void SavePng(ScalingGraphSnapshot snapshot, string path, Size size)
    {
        using var bitmap = CreateBitmap(snapshot, size);
        bitmap.Save(path, ImageFormat.Png);
    }

    internal static ScalingGraphLayout GetLayout(Rectangle bounds, int seriesCount)
    {
        int leftMargin = bounds.Left + 92;
        int rightMargin = bounds.Right - 30;
        int topMargin = bounds.Top + 110;
        int bottomMargin = bounds.Bottom - 92;
        int sidePanelWidth = 320;

        Rectangle plotRect = new(leftMargin, topMargin, Math.Max(300, rightMargin - leftMargin - sidePanelWidth), Math.Max(260, bottomMargin - topMargin));
        int sidePanelLeft = plotRect.Right + 18;
        int sidePanelWidthActual = Math.Max(220, rightMargin - sidePanelLeft);
        int legendDesiredHeight = 52 + (Math.Max(0, seriesCount) * 28);
        int legendHeight = Math.Min(Math.Max(82, legendDesiredHeight), Math.Max(90, plotRect.Height - 140));
        Rectangle legendRect = new(sidePanelLeft, plotRect.Top + 8, sidePanelWidthActual, legendHeight);
        Rectangle insightRect = new(sidePanelLeft, legendRect.Bottom + 12, sidePanelWidthActual, Math.Max(120, plotRect.Bottom - (legendRect.Bottom + 12)));
        return new ScalingGraphLayout(plotRect, legendRect, insightRect);
    }

    internal static string BuildFocusedAnalysisText(ScalingGraphSnapshot snapshot)
    {
        if (snapshot.Series.Count != 1)
            return $"Show just one benchmark line and this box will explain that test in plain language, tell you what the shape usually should look like, and comment on the current run. Right now {snapshot.Series.Count} lines are visible.";

        var series = snapshot.Series[0];
        var insight = BuildInsight(series);
        return string.Join(Environment.NewLine + Environment.NewLine,
        [
            $"Status: {insight.StatusTitle}",
            series.Name,
            $"Headline{Environment.NewLine}{insight.Headline}",
            $"What this test is really measuring{Environment.NewLine}{insight.WhatItTests}",
            $"What a healthy graph often looks like{Environment.NewLine}{insight.WhatToExpect}",
            $"What this current run says{Environment.NewLine}{insight.CurrentResult}"
        ]);
    }

    public static void Draw(Graphics graphics, Rectangle bounds, ScalingGraphSnapshot snapshot)
    {
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        graphics.Clear(Color.FromArgb(245, 245, 245));

        using var titleFont = new Font("Segoe UI Semibold", 20F, FontStyle.Bold, GraphicsUnit.Point);
        using var subtitleFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var axisFont = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        using var tickFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        using var legendFont = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);

        int titleTop = bounds.Top + 18;
        int subtitleTop = titleTop + 42;
        var layout = GetLayout(bounds, snapshot.Series.Count);
        Rectangle plotRect = layout.PlotRect;
        Rectangle legendRect = layout.LegendRect;
        Rectangle insightRect = layout.InsightRect;
        int leftMargin = plotRect.Left;

        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
        using var subtitleBrush = new SolidBrush(Color.FromArgb(80, 80, 80));
        using var axisBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var gridPen = new Pen(Color.FromArgb(214, 214, 214), 1F);
        using var axisPen = new Pen(Color.FromArgb(60, 60, 60), 1.2F);

        var centerFormat = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        var rightFormat = new StringFormat { Alignment = StringAlignment.Far, LineAlignment = StringAlignment.Center };

        graphics.DrawString(snapshot.Title, titleFont, titleBrush, new RectangleF(bounds.Left + 20, titleTop, bounds.Width - 40, 34), centerFormat);
        graphics.DrawString(snapshot.Subtitle, subtitleFont, subtitleBrush, new RectangleF(bounds.Left + 28, subtitleTop, bounds.Width - 56, 34), centerFormat);

        graphics.FillRectangle(Brushes.White, plotRect);
        graphics.DrawRectangle(Pens.LightGray, plotRect);

        int yTickCount = 6;
        double yMax = Math.Max(100.0, snapshot.MaxScalingPercent);
        for (int i = 0; i <= yTickCount; i++)
        {
            double value = yMax * i / yTickCount;
            int y = plotRect.Bottom - (int)Math.Round((value / yMax) * plotRect.Height);
            graphics.DrawLine(gridPen, plotRect.Left, y, plotRect.Right, y);
            graphics.DrawString($"{value:N0}", tickFont, axisBrush, new RectangleF(bounds.Left + 10, y - 12, leftMargin - bounds.Left - 18, 24), rightFormat);
        }

        int xCount = snapshot.ThreadTicks.Count;
        if (xCount == 1)
        {
            int x = plotRect.Left + plotRect.Width / 2;
            graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
            graphics.DrawString(snapshot.ThreadTicks[0].ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
        }
        else
        {
            for (int i = 0; i < xCount; i++)
            {
                int tick = snapshot.ThreadTicks[i];
                float ratio = xCount <= 1 ? 0.5F : (float)i / (xCount - 1);
                int x = plotRect.Left + (int)Math.Round(ratio * plotRect.Width);
                graphics.DrawLine(gridPen, x, plotRect.Top, x, plotRect.Bottom);
                graphics.DrawString(tick.ToString(), tickFont, axisBrush, new RectangleF(x - 30, plotRect.Bottom + 10, 60, 22), centerFormat);
            }
        }

        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Bottom, plotRect.Right, plotRect.Bottom);
        graphics.DrawLine(axisPen, plotRect.Left, plotRect.Top, plotRect.Left, plotRect.Bottom);
        graphics.DrawString("Threads", axisFont, axisBrush, new RectangleF(plotRect.Left, plotRect.Bottom + 40, plotRect.Width, 22), centerFormat);

        graphics.TranslateTransform(bounds.Left + 24, plotRect.Top + (plotRect.Height / 2));
        graphics.RotateTransform(-90F);
        graphics.DrawString("Scaling vs 1-thread baseline (%)", axisFont, axisBrush, new RectangleF(-plotRect.Height / 2, -18, plotRect.Height, 22), centerFormat);
        graphics.ResetTransform();

        var threadIndex = snapshot.ThreadTicks
            .Select((value, index) => (value, index))
            .ToDictionary(x => x.value, x => x.index);

        for (int seriesIndex = 0; seriesIndex < snapshot.Series.Count; seriesIndex++)
        {
            var series = snapshot.Series[seriesIndex];
            Color color = GetSeriesColor(series.ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);

            PointF? previous = null;
            foreach (var point in series.Points.OrderBy(x => x.Threads))
            {
                if (!threadIndex.TryGetValue(point.Threads, out int index))
                    continue;

                float xRatio = xCount <= 1 ? 0.5F : (float)index / (xCount - 1);
                float x = plotRect.Left + (xRatio * plotRect.Width);
                float y = plotRect.Bottom - (float)((point.ScalingPercent / yMax) * plotRect.Height);
                var current = new PointF(x, y);

                if (previous.HasValue)
                    graphics.DrawLine(linePen, previous.Value, current);

                graphics.FillEllipse(pointBrush, x - 5, y - 5, 10, 10);
                previous = current;
            }
        }

        DrawLegend(graphics, legendRect, snapshot.Series, legendFont);
        DrawInsightPanel(graphics, insightRect, snapshot, legendFont);
    }

    private static void DrawLegend(Graphics graphics, Rectangle legendRect, IReadOnlyList<ScalingGraphSeries> series, Font legendFont)
    {
        if (series.Count == 0)
            return;

        using var backgroundBrush = new SolidBrush(Color.FromArgb(246, 246, 246));
        using var borderPen = new Pen(Color.FromArgb(190, 190, 190), 1F);
        using var textBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));

        graphics.FillRectangle(backgroundBrush, legendRect);
        graphics.DrawRectangle(borderPen, legendRect);
        using var legendTitleFont = new Font(legendFont, FontStyle.Bold);
        graphics.DrawString(series.Count == 1 ? "Selected benchmark" : "Benchmarks shown", legendTitleFont, titleBrush, legendRect.Left + 12, legendRect.Top + 12);

        int y = legendRect.Top + 42;
        for (int i = 0; i < series.Count; i++)
        {
            Color color = GetSeriesColor(series[i].ColorIndex);
            using var linePen = new Pen(color, 3F);
            using var pointBrush = new SolidBrush(color);
            graphics.DrawLine(linePen, legendRect.Left + 14, y + 7, legendRect.Left + 42, y + 7);
            graphics.FillEllipse(pointBrush, legendRect.Left + 24, y + 2, 10, 10);
            graphics.DrawString(series[i].Name, legendFont, textBrush, new RectangleF(legendRect.Left + 50, y - 2, legendRect.Width - 60, 20));
            y += 28;
            if (y > legendRect.Bottom - 26)
                break;
        }
    }

    private static void DrawInsightPanel(Graphics graphics, Rectangle insightRect, ScalingGraphSnapshot snapshot, Font legendFont)
    {
        if (insightRect.Width < 160 || insightRect.Height < 90)
            return;

        using var backgroundBrush = new SolidBrush(Color.FromArgb(252, 252, 252));
        using var borderPen = new Pen(Color.FromArgb(190, 190, 190), 1F);
        using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
        using var bodyBrush = new SolidBrush(Color.FromArgb(60, 60, 60));
        using var sectionBrush = new SolidBrush(Color.FromArgb(45, 45, 45));
        using var titleFont = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        using var sectionFont = new Font("Segoe UI", 8.75F, FontStyle.Bold, GraphicsUnit.Point);
        using var bodyFont = new Font("Segoe UI", 8.75F, FontStyle.Regular, GraphicsUnit.Point);
        using var nameFont = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point);
        using var statusFont = new Font("Segoe UI", 8.5F, FontStyle.Bold, GraphicsUnit.Point);

        graphics.FillRectangle(backgroundBrush, insightRect);
        graphics.DrawRectangle(borderPen, insightRect);

        float x = insightRect.Left + 12F;
        float y = insightRect.Top + 12F;
        float width = insightRect.Width - 24F;
        float bottom = insightRect.Bottom - 12F;

        graphics.DrawString("Focused analysis", titleFont, titleBrush, new RectangleF(x, y, width, 18F));
        y += 24F;

        if (snapshot.Series.Count != 1)
        {
            string text = $"Show just one benchmark line and this box will explain that test in plain language, tell you what the shape usually should look like, and comment on the current run. Right now {snapshot.Series.Count} lines are visible.";
            DrawWrappedText(graphics, text, bodyFont, bodyBrush, new RectangleF(x, y, width, bottom - y));
            return;
        }

        var series = snapshot.Series[0];
        var insight = BuildInsight(series);
        Color seriesColor = GetSeriesColor(series.ColorIndex);

        SizeF pillSize = graphics.MeasureString(insight.StatusTitle, statusFont);
        var pillRect = new RectangleF(x, y, Math.Min(width, pillSize.Width + 18F), 22F);
        using (var pillBrush = new SolidBrush(insight.StatusColor))
        using (var pillTextBrush = new SolidBrush(Color.White))
        {
            graphics.FillRectangle(pillBrush, pillRect);
            graphics.DrawString(insight.StatusTitle, statusFont, pillTextBrush, new RectangleF(pillRect.Left + 9F, pillRect.Top + 3F, pillRect.Width - 10F, 16F));
        }

        y += 30F;
        using (var seriesBrush = new SolidBrush(seriesColor))
            graphics.DrawString(series.Name, nameFont, seriesBrush, new RectangleF(x, y, width, 22F));
        y += 24F;

        y += DrawSection(graphics, x, y, width, bottom - y, "Headline", insight.Headline, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        y += DrawSection(graphics, x, y, width, bottom - y, "What this test is really measuring", insight.WhatItTests, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        y += DrawSection(graphics, x, y, width, bottom - y, "What a healthy graph often looks like", insight.WhatToExpect, sectionFont, bodyFont, sectionBrush, bodyBrush) + 8F;
        DrawSection(graphics, x, y, width, bottom - y, "What this current run says", insight.CurrentResult, sectionFont, bodyFont, sectionBrush, bodyBrush);
    }

    private static ScalingInsight BuildInsight(ScalingGraphSeries series)
    {
        var points = series.Points
            .OrderBy(x => x.Threads)
            .ToArray();

        if (points.Length == 0)
        {
            return new ScalingInsight(
                "No data",
                Color.FromArgb(71, 85, 105),
                "This series does not have enough plotted data to analyze yet.",
                "Run the benchmark again so the graph has at least one valid scaling point.",
                "A useful scaling line needs a baseline and at least one measured thread count.",
                "There is not enough data here to comment on the current run.");
        }

        var peak = points
            .OrderByDescending(x => x.ScalingPercent)
            .ThenBy(x => x.Threads)
            .First();

        var last = points[^1];
        int maxThreads = last.Threads;
        double retention = peak.ScalingPercent > 0.0 ? last.ScalingPercent / peak.ScalingPercent : 1.0;
        double retentionPercent = retention * 100.0;
        double fullThreadMultiplier = last.ScalingPercent / 100.0;
        double idealLinearPercent = maxThreads * 100.0;
        double linearEfficiencyPercent = idealLinearPercent > 0.0 ? (last.ScalingPercent / idealLinearPercent) * 100.0 : 100.0;

        var guide = GetBenchmarkGuide(series.Name);
        var status = EvaluateStatus(guide.Family, maxThreads, peak, last, retention);
        string observedBehavior = BuildObservedBehavior(guide.Family, peak, last, retention);

        string currentResult = $"Peak was {peak.ScalingPercent:N0}% at {peak.Threads} threads. The last point at {last.Threads} threads is {last.ScalingPercent:N0}%, which keeps {retentionPercent:N0}% of the peak and lands at about {fullThreadMultiplier:N2}x the 1-thread baseline.";

        if (guide.Family is not BenchmarkInsightFamily.MemoryBandwidth and not BenchmarkInsightFamily.CachePressure)
            currentResult += $" Against a perfect linear target of {idealLinearPercent:N0}% at {last.Threads} threads, this run finishes at roughly {linearEfficiencyPercent:N0}% of ideal.";

        currentResult += " " + observedBehavior;

        return new ScalingInsight(status.StatusTitle, status.StatusColor, status.Headline, guide.WhatItTests, guide.WhatToExpect, currentResult);
    }

    private static (BenchmarkInsightFamily Family, string WhatItTests, string WhatToExpect) GetBenchmarkGuide(string benchmarkName)
    {
        if (benchmarkName.Contains("Memory Stream", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.MemoryBandwidth,
                "This is mostly a memory-path test. It stresses data movement, memory channels, cache reuse, and NUMA locality much more than raw arithmetic speed.",
                "Healthy memory graphs usually climb hard at low thread counts, then flatten once bandwidth is full. On bigger dual-socket or multi-NUMA systems, some drop-off after the first wall can be normal.");
        }

        if (benchmarkName.Contains("Cache", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.CachePressure,
                "This test is trying to expose cache and latency behavior by walking memory with poor locality. It is sensitive to cache contention and memory hierarchy pressure.",
                "Healthy cache-sensitive graphs often improve early, then level off or wobble when extra threads start fighting over shared cache and memory resources.");
        }

        if (benchmarkName.Contains("AES", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.Crypto,
                "This measures hardware-assisted AES block processing. On modern CPUs it leans on AES instructions, throughput, and how well the machine keeps many workers fed.",
                "Healthy crypto graphs usually scale fairly well and should not collapse badly at higher thread counts unless frequency, placement, or memory feeding becomes the bottleneck.");
        }

        if (benchmarkName.Contains("Matrix", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.DenseCompute,
                "This is dense math over reusable data. It rewards vector throughput, arithmetic horsepower, and cache reuse, with memory bandwidth becoming important at larger sizes.",
                "Healthy dense-compute graphs usually keep climbing deeper into the thread sweep than pure memory tests. Some flattening near the top is normal, but a sharp early fall is less desirable.");
        }

        if (benchmarkName.Contains("AVX", StringComparison.OrdinalIgnoreCase) ||
            benchmarkName.Contains("SIMD", StringComparison.OrdinalIgnoreCase) ||
            benchmarkName.Contains("Floating", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.VectorCompute,
                "This is mostly floating-point or vector-unit throughput. It reflects how well the CPU can keep its wide math hardware busy across many workers.",
                "Healthy vector graphs usually continue rising as more real cores join. Mild flattening is normal; a sharp early peak can suggest frequency drop, shared-resource pressure, or cross-node overhead.");
        }

        if (benchmarkName.Contains("Prime", StringComparison.OrdinalIgnoreCase) ||
            benchmarkName.Contains("Integer", StringComparison.OrdinalIgnoreCase) ||
            benchmarkName.Contains("Bit", StringComparison.OrdinalIgnoreCase) ||
            benchmarkName.Contains("Branch", StringComparison.OrdinalIgnoreCase))
        {
            return (
                BenchmarkInsightFamily.IntegerBranch,
                "This is an integer and control-flow heavy workload. It says more about branch handling, general throughput, and core efficiency than about raw memory bandwidth.",
                "Healthy integer-heavy graphs usually keep gaining as more cores join, although branch-heavy work can flatten sooner than perfectly regular math kernels.");
        }

        return (
            BenchmarkInsightFamily.MixedCompute,
            "This is a mixed workload with both compute and control behavior. It can be influenced by vector width, caches, thread scheduling, and memory traffic together.",
            "Healthy mixed-workload graphs generally rise through the sweep, though they may flatten once shared resources or memory traffic start to dominate.");
    }

    private static (string StatusTitle, Color StatusColor, string Headline) EvaluateStatus(BenchmarkInsightFamily family, int maxThreads, ScalingGraphPoint peak, ScalingGraphPoint last, double retention)
    {
        bool peakAtEnd = peak.Threads == last.Threads;
        bool peakEarly = peak.Threads <= Math.Max(2, maxThreads / 3);

        return family switch
        {
            BenchmarkInsightFamily.MemoryBandwidth when peakAtEnd && retention >= 0.90 =>
                ("Strong memory scaling", Color.FromArgb(34, 139, 94), "This line keeps gaining almost all the way to the end, which is strong for a bandwidth-heavy test."),

            BenchmarkInsightFamily.MemoryBandwidth when peakEarly && retention < 0.70 =>
                ("Bandwidth saturation visible", Color.FromArgb(217, 119, 6), "The memory path fills early here, so later threads mainly add contention instead of more throughput."),

            BenchmarkInsightFamily.MemoryBandwidth =>
                ("Normal memory plateau", Color.FromArgb(180, 83, 9), "This looks like a classic memory-limited curve: strong early gain followed by a flatter top end."),

            BenchmarkInsightFamily.CachePressure when peakEarly && retention < 0.70 =>
                ("Cache pressure visible", Color.FromArgb(217, 119, 6), "Higher thread counts are clearly fighting for cache or memory-side resources on this one."),

            BenchmarkInsightFamily.Crypto when peakAtEnd && retention >= 0.90 =>
                ("Good crypto scaling", Color.FromArgb(34, 139, 94), "This one keeps climbing well, which is what you want from an AES-heavy throughput test."),

            BenchmarkInsightFamily.DenseCompute or BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.IntegerBranch or BenchmarkInsightFamily.MixedCompute when peakAtEnd && retention >= 0.90 =>
                ("Good scaling", Color.FromArgb(34, 139, 94), "The line keeps climbing through the sweep, so higher thread counts are still paying off."),

            BenchmarkInsightFamily.DenseCompute or BenchmarkInsightFamily.VectorCompute or BenchmarkInsightFamily.IntegerBranch or BenchmarkInsightFamily.MixedCompute when peakEarly && retention < 0.65 =>
                ("Worth a closer look", Color.FromArgb(220, 38, 38), "This benchmark peaks quite early and then gives back a lot, which is not ideal for a compute-heavy test."),

            _ =>
                ("Partial scaling", Color.FromArgb(202, 138, 4), "The benchmark does scale, but it is clearly running into a wall before the full thread count is finished.")
        };
    }

    private static string BuildObservedBehavior(BenchmarkInsightFamily family, ScalingGraphPoint peak, ScalingGraphPoint last, double retention)
    {
        if (peak.Threads == last.Threads)
            return "The line is still climbing at the far right, so the machine has not obviously run out of room yet for this workload.";

        if (retention >= 0.90)
            return "The line peaks before the end but holds most of that gain, so full-load behavior still looks fairly stable.";

        if (retention >= 0.70)
        {
            return family switch
            {
                BenchmarkInsightFamily.MemoryBandwidth or BenchmarkInsightFamily.CachePressure => "The line peaks before the end and gives back a noticeable chunk, which usually means the memory side is saturated beyond the best point.",
                _ => "The line peaks before the end and then softens, suggesting shared-resource pressure, frequency drop, or placement overhead at higher load."
            };
        }

        return family switch
        {
            BenchmarkInsightFamily.MemoryBandwidth or BenchmarkInsightFamily.CachePressure => "The line peaks early and then drops hard, which usually means the memory or cache path is already full and extra threads are mostly adding traffic.",
            _ => "The line peaks early and then drops hard, so this is a good place to inspect placement, NUMA behavior, frequency limits, or other full-load bottlenecks."
        };
    }

    private static float DrawSection(Graphics graphics, float x, float y, float width, float availableHeight, string heading, string body, Font headingFont, Font bodyFont, Brush headingBrush, Brush bodyBrush)
    {
        if (availableHeight <= 0F)
            return 0F;

        float used = 0F;
        using var headingFormat = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Near, Trimming = StringTrimming.Word };
        var headingRect = new RectangleF(x, y, width, Math.Min(availableHeight, 18F));
        graphics.DrawString(heading, headingFont, headingBrush, headingRect, headingFormat);
        used += 18F;
        used += 4F;

        float bodyHeight = DrawWrappedText(graphics, body, bodyFont, bodyBrush, new RectangleF(x, y + used, width, Math.Max(0F, availableHeight - used)));
        used += bodyHeight;
        return used;
    }

    private static float DrawWrappedText(Graphics graphics, string text, Font font, Brush brush, RectangleF rect)
    {
        if (string.IsNullOrWhiteSpace(text) || rect.Width <= 0F || rect.Height <= 0F)
            return 0F;

        using var format = new StringFormat
        {
            Alignment = StringAlignment.Near,
            LineAlignment = StringAlignment.Near,
            Trimming = StringTrimming.Word
        };

        SizeF measured = graphics.MeasureString(text, font, new SizeF(rect.Width, rect.Height), format);
        float height = Math.Min(rect.Height, measured.Height + 2F);
        graphics.DrawString(text, font, brush, new RectangleF(rect.Left, rect.Top, rect.Width, height), format);
        return height;
    }

    private enum BenchmarkInsightFamily
    {
        MemoryBandwidth,
        CachePressure,
        Crypto,
        DenseCompute,
        VectorCompute,
        IntegerBranch,
        MixedCompute
    }

    private sealed record ScalingInsight(
        string StatusTitle,
        Color StatusColor,
        string Headline,
        string WhatItTests,
        string WhatToExpect,
        string CurrentResult);
}

internal sealed class DoubleBufferedPanel : Panel
{
    public DoubleBufferedPanel()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
    }
}

public sealed class ScalingGraphForm : Form
{
    private readonly ScalingGraphSnapshot _snapshot;
    private readonly DoubleBufferedPanel _graphPanel = new();
    private readonly FlowLayoutPanel _seriesButtonHost = new();
    private readonly Dictionary<string, Button> _seriesButtons = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _visibleSeries = new(StringComparer.OrdinalIgnoreCase);
    private readonly Label _selectionLabel = new();
    private readonly Panel _focusedAnalysisOverlay = new();
    private readonly Label _focusedAnalysisTitleLabel = new();
    private readonly TextBox _focusedAnalysisTextBox = new();

    public ScalingGraphForm(ScalingGraphSnapshot snapshot)
    {
        _snapshot = snapshot;
        foreach (var series in snapshot.Series)
            _visibleSeries.Add(series.Name);

        Text = "Thread Scaling Graph";
        AppVisuals.TryApplyWindowIcon(this);
        StartPosition = FormStartPosition.CenterParent;
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1000, 700);
        BackColor = Color.White;
        KeyPreview = true;
        KeyDown += ScalingGraphForm_KeyDown;

        var headerHost = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 2,
            BackColor = Color.FromArgb(35, 41, 59),
            Padding = new Padding(14, 10, 14, 10),
            Margin = new Padding(0)
        };
        headerHost.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        headerHost.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        var topBar = new Panel
        {
            Dock = DockStyle.Top,
            Height = 36,
            Margin = new Padding(0),
            BackColor = Color.Transparent
        };
        headerHost.Controls.Add(topBar, 0, 0);

        var closeButton = new Button
        {
            Text = "Close",
            Dock = DockStyle.Right,
            Width = 110,
            Height = 34,
            BackColor = Color.FromArgb(229, 77, 66),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0)
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (_, _) => Close();
        topBar.Controls.Add(closeButton);

        var hintLabel = new Label
        {
            Dock = DockStyle.Fill,
            Text = "Fullscreen scaling graph preview. Click a benchmark button to hide or show that line. When only one line is visible, the right side explains that test and your current result. Press Esc or use Close.",
            ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleLeft,
            AutoEllipsis = true
        };
        topBar.Controls.Add(hintLabel);

        var controlsHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 10, 0, 0),
            Padding = new Padding(0)
        };
        headerHost.Controls.Add(controlsHost, 0, 1);

        var showAllButton = CreateCommandButton("Show All", Color.FromArgb(37, 99, 235));
        showAllButton.Click += (_, _) => SetAllSeriesVisibility(true);
        controlsHost.Controls.Add(showAllButton);

        var hideAllButton = CreateCommandButton("Hide All", Color.FromArgb(71, 85, 105));
        hideAllButton.Click += (_, _) => SetAllSeriesVisibility(false);
        controlsHost.Controls.Add(hideAllButton);

        _selectionLabel.AutoSize = true;
        _selectionLabel.ForeColor = Color.White;
        _selectionLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
        _selectionLabel.Margin = new Padding(6, 9, 12, 0);
        controlsHost.Controls.Add(_selectionLabel);

        _seriesButtonHost.AutoSize = true;
        _seriesButtonHost.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        _seriesButtonHost.WrapContents = true;
        _seriesButtonHost.FlowDirection = FlowDirection.LeftToRight;
        _seriesButtonHost.BackColor = Color.Transparent;
        _seriesButtonHost.Margin = new Padding(0);
        _seriesButtonHost.Padding = new Padding(0);
        controlsHost.Controls.Add(_seriesButtonHost);

        BuildSeriesButtons();
        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();

        _graphPanel.Dock = DockStyle.Fill;
        _graphPanel.Paint += (_, e) => DrawGraphPanel(e.Graphics);
        _graphPanel.Resize += (_, _) => UpdateFocusedAnalysisOverlay();
        BuildFocusedAnalysisOverlay();
        Controls.Add(_graphPanel);
        Controls.Add(headerHost);
        UpdateFocusedAnalysisOverlay();
    }

    private static Button CreateCommandButton(string text, Color backColor)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            Height = 34,
            Padding = new Padding(12, 4, 12, 4),
            FlatStyle = FlatStyle.Flat,
            BackColor = backColor,
            ForeColor = Color.White,
            Margin = new Padding(0, 0, 8, 8)
        };
        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private void BuildFocusedAnalysisOverlay()
    {
        _focusedAnalysisOverlay.Visible = false;
        _focusedAnalysisOverlay.BackColor = Color.FromArgb(252, 252, 252);
        _focusedAnalysisOverlay.BorderStyle = BorderStyle.FixedSingle;
        _focusedAnalysisOverlay.Padding = new Padding(12);
        _focusedAnalysisOverlay.Anchor = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Bottom;

        _focusedAnalysisTitleLabel.Dock = DockStyle.Top;
        _focusedAnalysisTitleLabel.Height = 20;
        _focusedAnalysisTitleLabel.Text = "Focused analysis";
        _focusedAnalysisTitleLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        _focusedAnalysisTitleLabel.ForeColor = Color.FromArgb(35, 35, 35);

        _focusedAnalysisTextBox.Dock = DockStyle.Fill;
        _focusedAnalysisTextBox.Multiline = true;
        _focusedAnalysisTextBox.ReadOnly = true;
        _focusedAnalysisTextBox.ScrollBars = ScrollBars.Vertical;
        _focusedAnalysisTextBox.BorderStyle = BorderStyle.None;
        _focusedAnalysisTextBox.BackColor = Color.FromArgb(252, 252, 252);
        _focusedAnalysisTextBox.ForeColor = Color.FromArgb(45, 45, 45);
        _focusedAnalysisTextBox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
        _focusedAnalysisTextBox.WordWrap = true;
        _focusedAnalysisTextBox.ShortcutsEnabled = true;
        _focusedAnalysisTextBox.TabStop = false;

        _focusedAnalysisOverlay.Controls.Add(_focusedAnalysisTextBox);
        _focusedAnalysisOverlay.Controls.Add(_focusedAnalysisTitleLabel);
        _graphPanel.Controls.Add(_focusedAnalysisOverlay);
    }

    private void BuildSeriesButtons()
    {
        _seriesButtonHost.Controls.Clear();
        _seriesButtons.Clear();

        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            var button = new Button
            {
                Text = series.Name,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Height = 34,
                Padding = new Padding(12, 4, 12, 4),
                FlatStyle = FlatStyle.Flat,
                Margin = new Padding(0, 0, 8, 8),
                UseVisualStyleBackColor = false
            };

            string seriesName = series.Name;
            button.Click += (_, _) => ToggleSeries(seriesName);
            _seriesButtonHost.Controls.Add(button);
            _seriesButtons[seriesName] = button;
        }
    }

    private void ToggleSeries(string seriesName)
    {
        if (_visibleSeries.Contains(seriesName))
            _visibleSeries.Remove(seriesName);
        else
            _visibleSeries.Add(seriesName);

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        UpdateFocusedAnalysisOverlay();
        _graphPanel.Invalidate();
    }

    private void SetAllSeriesVisibility(bool visible)
    {
        _visibleSeries.Clear();
        if (visible)
        {
            foreach (var series in _snapshot.Series)
                _visibleSeries.Add(series.Name);
        }

        UpdateSeriesButtonStyles();
        UpdateSelectionLabel();
        UpdateFocusedAnalysisOverlay();
        _graphPanel.Invalidate();
    }

    private void UpdateSelectionLabel()
    {
        if (_visibleSeries.Count == 1)
        {
            string focusedName = _snapshot.Series
                .FirstOrDefault(series => _visibleSeries.Contains(series.Name))?
                .Name ?? "Focused";

            _selectionLabel.Text = $"Shown: 1 of {_snapshot.Series.Count}  |  Focus: {focusedName}";
            return;
        }

        _selectionLabel.Text = $"Shown: {_visibleSeries.Count} of {_snapshot.Series.Count}";
    }


    private void UpdateFocusedAnalysisOverlay()
    {
        var snapshot = BuildVisibleSnapshot();
        if (snapshot.Series.Count == 0 || _graphPanel.ClientSize.Width <= 0 || _graphPanel.ClientSize.Height <= 0)
        {
            _focusedAnalysisOverlay.Visible = false;
            return;
        }

        var layout = ScalingGraphRenderer.GetLayout(_graphPanel.ClientRectangle, snapshot.Series.Count);
        var insightRect = layout.InsightRect;
        if (insightRect.Width < 160 || insightRect.Height < 90)
        {
            _focusedAnalysisOverlay.Visible = false;
            return;
        }

        _focusedAnalysisOverlay.Visible = true;
        _focusedAnalysisOverlay.Bounds = insightRect;
        _focusedAnalysisTextBox.Text = ScalingGraphRenderer.BuildFocusedAnalysisText(snapshot);
        _focusedAnalysisTextBox.SelectionStart = 0;
        _focusedAnalysisTextBox.SelectionLength = 0;
    }

    private void UpdateSeriesButtonStyles()
    {
        for (int i = 0; i < _snapshot.Series.Count; i++)
        {
            var series = _snapshot.Series[i];
            if (!_seriesButtons.TryGetValue(series.Name, out var button))
                continue;

            bool isVisible = _visibleSeries.Contains(series.Name);
            Color seriesColor = ScalingGraphRenderer.GetSeriesColor(series.ColorIndex);
            ApplySeriesButtonStyle(button, seriesColor, isVisible);
        }
    }

    private static void ApplySeriesButtonStyle(Button button, Color seriesColor, bool isVisible)
    {
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = seriesColor;

        if (isVisible)
        {
            button.BackColor = seriesColor;
            button.ForeColor = Color.White;
            button.Text = button.Text.StartsWith("✕ ", StringComparison.Ordinal) ? button.Text[2..] : button.Text;
        }
        else
        {
            button.BackColor = Color.FromArgb(245, 247, 250);
            button.ForeColor = Color.FromArgb(55, 65, 81);
            if (!button.Text.StartsWith("✕ ", StringComparison.Ordinal))
                button.Text = "✕ " + button.Text;
        }
    }

    private void DrawGraphPanel(Graphics graphics)
    {
        var snapshot = BuildVisibleSnapshot();
        if (snapshot.Series.Count == 0)
        {
            graphics.Clear(Color.White);
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;

            using var titleFont = new Font("Segoe UI Semibold", 22F, FontStyle.Bold, GraphicsUnit.Point);
            using var bodyFont = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            using var titleBrush = new SolidBrush(Color.FromArgb(35, 35, 35));
            using var bodyBrush = new SolidBrush(Color.FromArgb(90, 90, 90));
            var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };

            graphics.DrawString("No graph lines are currently visible", titleFont, titleBrush, _graphPanel.ClientRectangle, center);
            var subtitleRect = new RectangleF(0, (_graphPanel.ClientRectangle.Height / 2F) + 28F, _graphPanel.ClientRectangle.Width, 40F);
            graphics.DrawString("Use the buttons at the top to turn one or more benchmark series back on.", bodyFont, bodyBrush, subtitleRect, center);
            return;
        }

        ScalingGraphRenderer.Draw(graphics, _graphPanel.ClientRectangle, snapshot);
    }

    private ScalingGraphSnapshot BuildVisibleSnapshot()
    {
        var visibleSeries = _snapshot.Series
            .Where(series => _visibleSeries.Contains(series.Name))
            .ToArray();

        if (visibleSeries.Length == 0)
        {
            return new ScalingGraphSnapshot
            {
                SessionId = _snapshot.SessionId,
                Title = _snapshot.Title,
                Subtitle = _snapshot.Subtitle,
                Series = Array.Empty<ScalingGraphSeries>(),
                ThreadTicks = _snapshot.ThreadTicks,
                MaxScalingPercent = Math.Max(200.0, _snapshot.MaxScalingPercent)
            };
        }

        double maxScaling = visibleSeries
            .SelectMany(x => x.Points)
            .Select(x => x.ScalingPercent)
            .DefaultIfEmpty(100.0)
            .Max();

        double roundedMaxScaling = RoundUp(maxScaling * 1.05, 50.0);
        if (roundedMaxScaling < 200.0)
            roundedMaxScaling = 200.0;

        return new ScalingGraphSnapshot
        {
            SessionId = _snapshot.SessionId,
            Title = _snapshot.Title,
            Subtitle = _snapshot.Subtitle,
            Series = visibleSeries,
            ThreadTicks = _snapshot.ThreadTicks,
            MaxScalingPercent = roundedMaxScaling
        };
    }

    private static double RoundUp(double value, double multiple)
    {
        if (multiple <= 0.0)
            return value;

        return Math.Ceiling(value / multiple) * multiple;
    }

    private void ScalingGraphForm_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            e.Handled = true;
            Close();
        }
    }
}
